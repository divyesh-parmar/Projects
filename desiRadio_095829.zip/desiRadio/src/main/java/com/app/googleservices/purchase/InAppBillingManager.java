package com.app.googleservices.purchase;

import android.app.Activity;
import android.content.Context;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.anjlab.android.iab.v3.BillingProcessor;
import com.anjlab.android.iab.v3.PurchaseInfo;
import com.app.utility.Debugger;


public class InAppBillingManager implements BillingProcessor.IBillingHandler {

    BillingProcessor bp;
    String TAG = getClass().getSimpleName();
    IInAppBillingInitializeListener initializeListener;
    IInAppBillingPurchaseListener purchaseListener;
    static InAppBillingManager sharedInstance;
    Context context;

    public enum InAppBillingError {
        NOT_CONNECTED,
        LIBRARY_ERROR,
        ALREADY_PURCHASED,
        ALREADY_SUBSCRIBED,
        PURCHASE_FAILED
    }

    ;

    public static synchronized InAppBillingManager getSharedInstance() {
        return sharedInstance;
    }

    public InAppBillingManager(Context context, String licenseKey, String merchantId) {
        bp = new BillingProcessor(context, licenseKey, merchantId, this);
        sharedInstance = this;
        this.context = context;
    }

    public void initInAppBilling(IInAppBillingInitializeListener initializeListener) {
        this.initializeListener = initializeListener;
        bp.initialize();
    }

    public void purchase(Activity activity, String productSku, IInAppBillingPurchaseListener purchaseListener) {

        this.purchaseListener = purchaseListener;
        if (bp.isConnected()) {
            Debugger.debugI(TAG ,"purchase: connected");

            if (bp.isPurchased(productSku)) {
                Debugger.debugI(TAG ,"purchase: already purchase");

                sendPurchaseError(productSku, InAppBillingError.ALREADY_PURCHASED, "Already purchased.");
            } else {
                Debugger.debugI(TAG ,"purchase: purchase function");
                bp.purchase(activity, productSku);

            }
        } else {
            sendPurchaseError(productSku, InAppBillingError.NOT_CONNECTED, "Billing library not available.");
        }
    }

    public void subscribe(Activity activity, String productSku, IInAppBillingPurchaseListener purchaseListener) {
        this.purchaseListener = purchaseListener;
        if (bp.isConnected()) {
            if (bp.isSubscribed(productSku))
                sendPurchaseError(productSku, InAppBillingError.ALREADY_SUBSCRIBED, "Already subscribed.");
            else
                bp.subscribe(activity, productSku);
        } else {
            sendPurchaseError(productSku, InAppBillingError.NOT_CONNECTED, "Billing library not available.");
        }
    }

    public boolean isConnecting() {
        return bp.isConnected();
    }

    public boolean isPurchased(String sku) {
        return bp.isPurchased(sku);
    }

    public boolean isSubscribed(String sku) {
        return bp.isSubscribed(sku);
    }

    private void sendInitializeError(InAppBillingError errorCode, String error) {
        if (this.initializeListener != null)
            this.initializeListener.onInitializeFailed(errorCode, error);
    }

    private void sendInitializePurchaseLoaded() {
        if (this.initializeListener != null)
            this.initializeListener.onInitializePurchaseLoaded();
    }

    private void sendInitializeSuccess() {
        if (this.initializeListener != null)
            this.initializeListener.onInitializeSuccess();
    }

    private void sendPurchaseError(String sku, InAppBillingError errorCode, String error) {
        if (this.purchaseListener != null)
            this.purchaseListener.onPurchaseFailed(sku, errorCode, error);
    }

    private void sendPurchaseSuccess(String productSku, PurchaseInfo purchaseInfo) {
        if (this.purchaseListener != null)
            this.purchaseListener.onPurchaseSuccess(productSku, purchaseInfo);
    }

    @Override
    public void onProductPurchased(@NonNull String productId, @Nullable PurchaseInfo details) {
        Debugger.debugI(TAG , productId);
        if (details != null) {
            sendPurchaseSuccess(productId, details);
        } else {
            sendPurchaseError(productId, InAppBillingError.PURCHASE_FAILED, "Purchase failed.");
        }

    }

    @Override
    public void onPurchaseHistoryRestored() {
        Debugger.debugI(TAG ,"Purchase History Restored");
    }

    @Override
    public void onBillingError(int errorCode, @Nullable Throwable error) {
        Debugger.debugI(TAG ,"onBillingError: "+ errorCode);
    }

    @Override
    public void onBillingInitialized() {
        // Billing library initialized. Now load own purchased list.
        // If we loaded this then it could be easy to check whether purchase is do or not at any point of application
        Debugger.debugI(TAG ,"-----onBillingInitialized------- ");

        bp.loadOwnedPurchasesFromGoogleAsync(new BillingProcessor.IPurchasesResponseListener() {
            @Override
            public void onPurchasesSuccess() {
                // Don't do anything here as everything is stored under BillingProcessor

                sendInitializePurchaseLoaded();     //  added for purchaseLoaded and check purchase or not
            }

            @Override
            public void onPurchasesError() {

            }
        });
    }

    public interface IInAppBillingInitializeListener {
        public void onInitializeSuccess();

        public void onInitializePurchaseLoaded();

        public void onInitializeFailed(InAppBillingError errorCode, String error);
    }

    public interface IInAppBillingPurchaseListener {
        public void onPurchaseSuccess(String sku, PurchaseInfo purchaseInfo);


        public void onPurchaseFailed(String sku, InAppBillingError errorCode, String error);
    }

    public boolean checkPurchased(String sku) {

        if (bp.getPurchaseInfo(sku) != null) {
            return true;
        } else {
            return false;
        }

    }
}

package com.app.genre;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.app.ads.NativeAdsUtils;
import com.app.firebase.FirebaseRemoteConfigUtils;
import com.app.parser.Language;
import com.app.utility.Constant;
import com.app.utility.Debugger;
import com.app.utility.Globals;
import com.app.utility.Utils;
import com.google.android.ads.nativetemplates.TemplateView;
import com.indianradio.R;

public class LanguageListAdapter extends BaseAdapter {

    private Activity activity;
    private ArrayList<Language> data;
    private static LayoutInflater inflater = null;
    OnItemClickListener itemClickListener;
    Globals globals;

    public LanguageListAdapter(Activity a, OnItemClickListener itemClickListener) {
        activity = a;
        globals = ((Globals) activity.getApplicationContext());
        this.itemClickListener = itemClickListener;
        inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public void updateResults(Activity activity, ArrayList<Language> d) {
        this.data = d;
        //Triggers the list update
        notifyDataSetChanged();
    }

    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    public long getItemId(int position) {
        return position;
    }

    public Language getselectedLanguage(int position) {
        return ((Language) getItem(position));
    }

    public static class ViewHolder {
        public TextView name;
        public TextView count;
        public LinearLayout isNew;
        public LinearLayout my_item;
        public LinearLayout div1;
        LinearLayout templateView;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        View vi = convertView;
        ViewHolder holder;
        if (convertView == null) {
            vi = inflater.inflate(R.layout.language_item, null);
            holder = new ViewHolder();
            holder.name = (TextView) vi.findViewById(R.id.txt_language_name);
            holder.count = (TextView) vi.findViewById(R.id.txt_channel_count);
            holder.isNew = (LinearLayout) vi.findViewById(R.id.isNew);
            holder.my_item = (LinearLayout) vi.findViewById(R.id.my_item);
            holder.div1 = (LinearLayout) vi.findViewById(R.id.div1);
            holder.templateView = vi.findViewById(R.id.templateView);
            vi.setTag(holder);
        } else
            holder = (ViewHolder) vi.getTag();



        if (position == LanguageListFragment.random &&  FirebaseRemoteConfigUtils.getInstance().getNativeType() == Constant.NativeEnum.ADMOB.ordinal()) {
            if (Utils.getInt(activity, activity.getResources().getString(R.string.In_app_product_ads_id), 0) == 0) {
                Debugger.debugI("LanguageAdapter", "getView: " + position);
                holder.templateView.setVisibility(View.VISIBLE);
                holder.div1.setVisibility(View.VISIBLE);
                if (holder.templateView != null) {
                    NativeAdsUtils.getInstance().showNative(activity, holder.templateView);
                }
            }else {
                holder.templateView.setVisibility(View.GONE);
                holder.div1.setVisibility(View.GONE);
            }

        }else {
            holder.templateView.setVisibility(View.GONE);
            holder.div1.setVisibility(View.GONE);
        }

        Language info = getselectedLanguage(position);
        if (Integer.parseInt(info.LanguageIsNew) == 1)
            holder.isNew.setVisibility(View.VISIBLE);
        else
            holder.isNew.setVisibility(View.GONE);

        holder.name.setText(info.LanguageName);
        holder.count.setText(info.TotalChannels + " stations");

        holder.my_item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                itemClickListener.onItemClick(position);
            }
        });
        return vi;
    }


}
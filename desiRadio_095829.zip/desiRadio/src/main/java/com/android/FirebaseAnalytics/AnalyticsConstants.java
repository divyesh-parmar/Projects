package com.android.FirebaseAnalytics;

/**
 * Created by on 15/06/17.
 */
public class AnalyticsConstants {


    public static final String SCREEN_NAME                                              = "SCREEN_NAME";
    public static final String EVENT_CATEGORY                                           = "EVENT_CATEGORY";
    public static final String EVENT_ACTION                                             = "EVENT_ACTION";

    //SCREEN_NAME for Google Analytics
    public static final String SN_category                                              = "Category";
    public static final String SN_subCategory                                           = "Category_List";
    public static final String SN_channel                                               = "Channel_List";
    public static final String SN_player                                                = "PlayerView";
    public static final String SN_videolist                                             = "Video_List";
    public static final String SN_video                                                 = "Video";
    public static final String SN_top100                                                = "Top_100";
    public static final String SN_search                                                = "Search";
    public static final String SN_favorites                                             = "Favorites";
    public static final String SN_more                                                  = "More";
    public static final String SN_lockplayer                                            = "Lock_screen";
    public static final String SN_addOwnStation                                         = "Add_Own_Station";
    public static final String SN_bottomPlayer                                          = "Bottom_Player";
    public static final String SN_start                                                 = "Start";

    //new 1
    public static final String SN_recorded                                              = "Recorded";

    //new 2
    public static final String SN_history                                               = "History";
    public static final String SN_class_name                                            = "Class_Name";


    //Event Category for Google Analytics
    public static final String EC_category                                              = "CATEGORY";
    public static final String EC_subcategory                                           = "SUBCATEGORY";
    public static final String EC_channel_list                                          = "CHANNEL_LIST";
    public static final String EC_player                                                = "PLAYER";
    public static final String EC_videolist                                             = "VIDEO_LIST";
    public static final String EC_top100                                                = "TOP100";
    public static final String EC_search                                                = "SEARCH";
    public static final String EC_favorites                                             = "FAVORITES";
    public static final String EC_more                                                  = "MORE";
    public static final String EC_REMOVE_ADS                                            = "REMOVE_ADS";
    public static final String EC_lockplayer                                            = "LOCK_SCREEN";
    public static final String EC_add_own_station                                       = "ADD_OEN_STATION";
    public static final String EC_bottom_player                                         = "BOTTOM_PLAYER";

    //new 1
    public static final String EC_START                                                 = "START";
    public static final String EC_BANNER_ADVT_SUCCESS                                   = "BANNER_ADVT_SUCCESS";
    public static final String EC_BANNER_ADVT_FAIL                                      = "BANNER_ADVT_FAIL";
    public static final String EC_recorded                                              = "RECORDED";
    public static final String EC_RecordingUpgrade                                      = "RECORDING_UPGRADE";
    public static final String EC_PURCHASE_fail                                         = "PURCHASE_FAIL";
    public static final String EC_Recording_purchase_success                            = "RECORDING_PURCHASE_SUCCESS";
    public static final String EC_NoAds_purchase_success                                = "NO_ADS_PURCHASE_SUCCESS";
    public static final String EC_FULL_SCREEN_ADVT_SUCCESS                              = "FULL_SCREEN_ADVT_SUCCESS";
    public static final String EC_FULL_SCREEN_ADVT_FAIL                                 = "FULL_SCREEN_ADVT_FAIL";
    public static final String EC_FULL_SCREEN_ADVT_TOUCH                                = "FULL_SCREEN_ADVT_TOUCH";

    //new 2
    public static final String EC_BANNER_ADVT_TOUCH                                     = "BANNER_ADVT_TOUCH";
    public static final String EC_history                                               = "HISTORY";

    //new 3
    public static final String EC_NATIVE_ADVT_SUCCESS                                   = "NATIVE_ADVT_SUCCESS";
    public static final String EC_NATIVE_ADVT_FAIL                                      = "NATIVE_ADVT_FAIL";
    public static final String EC_NATIVE_ADVT_TOUCH                                     = "NATIVE_ADVT_TOUCH";

    public static final String EC_STARTAPP_NATIVE_ADVT_SUCCESS                          = "STARTAPP_NATIVE_ADVT_SUCCESS";
    public static final String EC_STARTAPP_NATIVE_ADVT_FAIL                             = "STARTAPP_NATIVE_ADVT_FAIL";
    public static final String EC_STARTAPP_NATIVE_ADVT_TOUCH                            = "STARTAPP_NATIVE_ADVT_TOUCH";

    public static final String EC_FACEBOOK_NATIVE_ADVT_SUCCESS                          = "FACEBOOK_NATIVE_ADVT_SUCCESS";
    public static final String EC_FACEBOOK_NATIVE_ADVT_FAIL                             = "FACEBOOK_NATIVE_ADVT_FAIL";
    public static final String EC_FACEBOOK_NATIVE_ADVT_TOUCH                            = "FACEBOOK_NATIVE_ADVT_TOUCH";

    public static final String EC_ADMOB_NATIVE_ADVT_SUCCESS                             = "ADMOB_NATIVE_ADVT_SUCCESS";
    public static final String EC_ADMOB_NATIVE_ADVT_FAIL                                = "ADMOB_NATIVE_ADVT_FAIL";
    public static final String EC_ADMOB_NATIVE_ADVT_TOUCH                               = "ADMOB_NATIVE_ADVT_TOUCH";

    public static final String EA_NATIVE_ADVT_SUCCESS                                   = "NATIVE_ADVT_SUCCESS";
    public static final String EA_NATIVE_ADVT_FAIL                                      = "NATIVE_ADVT_FAIL";
    public static final String EA_NATIVE_ADVT_TOUCH                                     = "NATIVE_ADVT_TOUCH";

    public static final String EA_STARTAPP_NATIVE_ADVT_SUCCESS                          = "STARTAPP_NATIVE_ADVT_SUCCESS";
    public static final String EA_STARTAPP_NATIVE_ADVT_FAIL                             = "STARTAPP_NATIVE_ADVT_FAIL";
    public static final String EA_STARTAPP_NATIVE_ADVT_TOUCH                            = "STARTAPP_NATIVE_ADVT_TOUCH";

    public static final String EA_ADMOB_NATIVE_ADVT_SUCCESS                             = "EA_ADMOB_NATIVE_ADVT_SUCCESS";
    public static final String EA_ADMOB_NATIVE_ADVT_FAIL                                = "EA_ADMOB_NATIVE_ADVT_FAIL";
    public static final String EA_ADMOB_NATIVE_ADVT_TOUCH                               = "EA_ADMOB_NATIVE_ADVT_TOUCH";

    public static final String EA_FACEBOOK_NATIVE_ADVT_SUCCESS                          = "FACEBOOK_NATIVE_ADVT_SUCCESS";
    public static final String EA_FACEBOOK_NATIVE_ADVT_FAIL                             = "FACEBOOK_NATIVE_ADVT_FAIL";
    public static final String EA_FACEBOOK_NATIVE_ADVT_TOUCH                            = "FACEBOOK_NATIVE_ADVT_TOUCH";

    public static final String EC_COUNTRY                                               = "COUNTRY";


    //Event Action for Google Analytics
    public static final String EA_DRAWER_SELECT_ITEM                                    = "DRAWER_SELECT_ITEM";

    public static final String EA_play                                                  = "NOW_PLAYING";
    public static final String EA_play_channel                                          = "PLAY_CHANNEL";
    public static final String EA_stop_channel                                          = "STOP_CHANNEL";
    public static final String EA_next_channel                                          = "NEXT_CHANNEL";
    public static final String EA_select_channel                                        = "SELECT_CHANNEL";
    public static final String EA_previous_channel                                      = "PREVIOUS_CHANNEL";
    public static final String EA_add_favorite                                          = "ADD_FAVORITE_STATION";
    public static final String EA_remove_favorite                                       = "REMOVE_FAVORITE_STATION";
    public static final String EA_edit_playlist                                         = "EDIT_PLAYLIST";
    public static final String EA_done_playlist                                         = "DONE_PLAYLIST";
    public static final String EA_clear_playlist                                        = "CLEAR_PLAYLIST";
    public static final String EA_video_button                                          = "VIDEO_BUTTON";
    public static final String EA_set_timer                                             = "SET_TIMER";
    public static final String EA_sharing_button                                        = "ACTION_BUTTON";
    public static final String EA_facebook                                              = "FACEBOOK_BUTTON";
    public static final String EA_twitter                                               = "TWITTER_BUTTON";
    public static final String EA_mail                                                  = "EMAIL_BUTTON";
    public static final String EA_sms                                                   = "SMS_BUTTON";
    public static final String EA_select_video                                          = "SELECT_VIDEO";
    public static final String EA_search_op                                             = "SEARCH_STATION";
    public static final String EA_more_apps                                             = "MORE_APPS";
    public static final String EA_about_us                                              = "ABOUT_US";
    public static final String EA_contact_us                                            = "CONTACT_US";
    public static final String EA_tell_a_friend                                         = "TELL_A_FRIENDS";
    public static final String EA_rate_app                                              = "RATE_THIS_APP";
    public static final String EA_settings                                              = "SETTINGS";
    public static final String EA_select_category                                       = "SELECT_CATEGORY";
    public static final String EA_select_subcategory                                    = "SELECT_SUBCATEGORY";
    public static final String EA_remove_own_st_channel                                 = "REMOVE_OWN_CHANNEL";
    public static final String EA_remove_fav_st_channel                                 = "REMOVE_FAV_CHANNEL";



    //new 1
    public static final String EA_UPDATE_DIALOG                                         = "UPDATE_DIALOG";
    public static final String EA_UPDATE_NOW_BUTTON                                     = "UPDATE_NOW_BUTTON";

    public static final String EA_NOTIFICATION_DIALOG                                   = "NOTIFICATION_DIALOG";
    public static final String EA_LINK_BUTTON                                           = "LINK_BUTTON";

    public static final String EA_whatsapp                                              = "WHATSAPP_BUTTON";

    public static final String EA_NOTIFICATION_ON                                       = "NOTIFICATION_ON";
    public static final String EA_NOTIFICATION_OFF                                      = "NOTIFICATION_OFF";

    public static final String EA_Record_button                                         = "RECORD_BUTTON";

    //new 2
    public static final String EA_USER_ADDED_STATION                                    = "SAVE_USER_ADDED_STATION";

    public static final String SELECT_STATION_NAME                                      = "SELECT_ST_NAME";
    public static final String REMOVE_OWN_STATION_NAME                                  = "REMOVE_OWN_STATION";
    public static final String REMOVE_FAV_STATION_NAME                                  = "REMOVE_FAV_STATION";



}

package com.app.recorded;

import android.view.View;

public interface OnItemRecordLongClickListener {

    void onItemClicker(View view, int position);

    void onItemLongClick(View view,int position);
}

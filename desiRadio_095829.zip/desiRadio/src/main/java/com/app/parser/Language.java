package com.app.parser;

import java.util.ArrayList;

public class Language implements Comparable<Language> {
    public String LanguageId;
    public String LanguageName;
    public int LanguageSortOrder;
    public int TotalChannels;
    public String LanguageIsNew;
    public ArrayList<Channel> channels;

    public Language(String LanguageId, String LanguageName,
                    int LanguageSortOrder, int TotalChannels, String LanguageIsNew,
                    ArrayList<Channel> channels) {
        this.LanguageId = LanguageId;
        this.LanguageName = LanguageName;
        this.LanguageSortOrder = LanguageSortOrder;
        this.TotalChannels = TotalChannels;
        this.LanguageIsNew = LanguageIsNew;
        this.channels = channels;
    }

    @Override
    public int compareTo(Language sp) {
        return this.LanguageId.compareTo(sp.LanguageId);
    }

    @Override
    public String toString() {
        return "name: " + LanguageName + " size: " + TotalChannels + " sort: " + LanguageSortOrder + "<";
    }
}
package com.android.youtube;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.ViewSwitcher;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NavUtils;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.FirebaseAnalytics.AnalyticsConstants;
import com.android.Utility.Classes.ProgressIndicator;
import com.android.Utility.Classes.UnCaughtException;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.app.auto.RMusicService;
import com.app.desiradio.PrepareDrawerList;
import com.app.desiradio.SplashScreenActivity;
import com.app.http.ConnectionDetector;
import com.app.parser.Parser;
import com.app.player.PlaylistManager;
import com.app.player.RadioPlayerActivity;
import com.app.player.showRecordingInterruptDialogActivity;
import com.app.recorded.RecordedManager;
import com.app.recorded.RecordedPlayerService;
import com.app.utility.Constant;
import com.app.utility.Debugger;
import com.app.utility.Globals;
import com.app.utility.Utils;
import com.google.android.gms.ads.AdRequest;

import com.indianradio.R;
import com.jakewharton.processphoenix.ProcessPhoenix;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;

public class YoutubeListActivity extends AppCompatActivity {

    Globals globals;

    YoutubeListRAdapter adapter;
    ProgressIndicator mProgress;
    ArrayList<HashMap<String, String>> videos = null;
    public String songName;
    EditText sTxt;
    //Button clear;
    ImageView clear;
    TextView mTxt;
    ViewSwitcher switcher;
    public static ArrayList<HashMap<String, String>> itemList;

    RecyclerView rvVideos;
    LinearLayout contentLayout;

    int tempPosition = -99;
    boolean onActivityResultCalled = false;
    int counter = 0;

    public static String TAG;
    String idYt;
    int positionYt;

    protected Configuration mPrevConfig;

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        configurationChanged(newConfig);
        mPrevConfig = new Configuration(newConfig);
    }

    protected void configurationChanged(Configuration newConfig) {
        if (Utils.getInt(this, "mode", 0) == 2)
            ProcessPhoenix.triggerRebirth(YoutubeListActivity.this, new Intent(this, SplashScreenActivity.class));

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TAG = getClass().getName();
        Thread.setDefaultUncaughtExceptionHandler(new UnCaughtException(YoutubeListActivity.this));
        setContentView(R.layout.youtube_videolist_layout);

        mPrevConfig = new Configuration(getResources().getConfiguration());

        adapter = new YoutubeListRAdapter(YoutubeListActivity.this, new com.app.genre.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {

                if (RecordedPlayerService.rPlayer != null && RecordedPlayerService.rPlayer.isPlaying()){

                    RecordedPlayerService.stopPLaying();
                    RecordedManager.init();
                }

                if (!checkIsRecording(Constant.MM_ActionID_onSelectVideo)) {
                    if (ConnectionDetector.internetCheck(YoutubeListActivity.this))
                        onSelectVideo(position);
                } else {
                    tempPosition = position;
                }
            }
        });
        globals = ((Globals) YoutubeListActivity.this.getApplicationContext());

        clear = (ImageView) findViewById(R.id.btn_clear);
        clear.setVisibility(View.INVISIBLE);
        clear.setClickable(false);

        clear.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                clear.setVisibility(View.INVISIBLE);
                clear.setClickable(false);
                sTxt.setText(null);
            }
        });

        songName = RMusicService.currentPlayingName.trim();
        sTxt = (EditText) findViewById(R.id.search_txt);

        getSupportActionBar().setDisplayShowTitleEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Video List");

        sTxt.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(v.getWindowToken(), 0);

                    performSearch();
                    return true;
                }
                return false;
            }
        });

        sTxt.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if (sTxt.getText().toString().length() > 0) {
                    clear.setVisibility(View.VISIBLE);
                    clear.setClickable(true);
                } else {
                    clear.setVisibility(View.INVISIBLE);
                    clear.setClickable(false);
                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        sTxt.setText(songName);

        rvVideos = findViewById(R.id.rv_videos);
        rvVideos.setLayoutManager(new GridLayoutManager(this, 1));

        switcher = (ViewSwitcher) findViewById(R.id.playlistSwitcher);

        contentLayout = (LinearLayout) findViewById(R.id.contentLayout);

        if (songName.trim().length() > 0)
            downloadTask();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);

        //StartAnalytics(YoutubeListActivity.this);
        Bundle bundle = new Bundle();
        bundle.putString(AnalyticsConstants.SCREEN_NAME, AnalyticsConstants.SN_videolist);
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
            return true;
        }

        return true;
    }

    public void onSelectVideo(int position) {
        String videoLink = itemList.get(position).get("title") + " -> http://www.youtube.com/watch?v=" + itemList.get(position).get("youtubeID");
        Bundle bundle = new Bundle();
        bundle.putString(AnalyticsConstants.EVENT_CATEGORY, AnalyticsConstants.EC_videolist);
        bundle.putString("Video_Link", videoLink);

        if (PlaylistManager.isPlaying()) {
            globals.radioServiceActivity = YoutubeListActivity.this;
            RMusicService.stopStation(globals.radioServiceActivity);

        }
        String youtube_id = itemList.get(position).get("youtubeID").trim();
        idYt = youtube_id;
        positionYt = position;

        // Intent startPlaying = new Intent(YoutubeListActivity.this, videoplayerActivity.class);
        Intent startPlaying = new Intent(YoutubeListActivity.this, FullscreenDemoActivity.class);
        startPlaying.putExtra("ID", idYt);
        startPlaying.putExtra("index", positionYt);
        startPlaying.putExtra("title",itemList.get(position).get("title"));
        startActivity(startPlaying);

    }

    ActivityResultLauncher<Intent> someActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        // There are no request codes
                        Intent data = result.getData();
                        switch (data.getIntExtra("actionID", 0)) {
                            case Constant.MM_ActionID_onSelectVideo:
                                onActivityResultCalled = true;
                                counter = 0;

                                globals.radioServiceActivity = YoutubeListActivity.this;
                                RMusicService.stopStation(globals.radioServiceActivity);

                                break;
                        }
                    }
                }
            });

    public void openInterruptActivity(Bundle bundle) {
        // Start the activity whose result we want to retrieve.
        // The result will come back with request code GET_CODE.
        Intent intent = new Intent(YoutubeListActivity.this, showRecordingInterruptDialogActivity.class);
        intent.putExtras(bundle);
        // startActivityForResult(intent, requestCode);
        someActivityResultLauncher.launch(intent);
    }

    public boolean checkIsRecording(int actionCode) {
        if (PlaylistManager.isRecording()) {
            Bundle bundle = new Bundle();
            bundle.putInt("actionID", actionCode);
            openInterruptActivity(bundle);
            return true;
        } else {
            return false;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        Globals.activityPaused();
    }

    @SuppressLint("SuspiciousIndentation")
    @Override
    public void onResume() {
        super.onResume();
        Debugger.debugI(TAG, "onResume called");
        Globals.activityResumed();
        globals.radioServiceActivity = YoutubeListActivity.this;
        if (onActivityResultCalled)
            counter++;
        Debugger.debugI(TAG, "" + counter);
        if (counter == 2 && tempPosition != -99) {
            onSelectVideo(tempPosition);
            tempPosition = -99;
            counter = 0;
            onActivityResultCalled = false;
        }

    }

    private void performSearch() {
        if (sTxt.getText().toString().length() > 0) {
            downloadTask();
        }
    }

    public void downloadTask() {
        // check for Internet status
        if (ConnectionDetector.internetCheck(YoutubeListActivity.this)) {
            String URL = null;
            try {
                String s = Constant.Youtube_GET_ID_API; // + globals.getYouTubeSafeSearch();
                Debugger.debugI(TAG, "SafeSearch : " + s);
                URL = String.format(s, URLEncoder.encode(sTxt.getText().toString().trim(), "US-ASCII"), Constant.Browser_Appkey);
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }

            if (URL != null) {
                execute(URL);
            }
        }
    }

    private void execute(String url) {
        mProgress = ProgressIndicator.show(YoutubeListActivity.this, "Loading...",true,false);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Debugger.debugI(TAG, "API response : " + response.toString().trim());
                mProgress.dismiss();
                if (!response.toString().trim().equalsIgnoreCase("error_in_response")) {
                    int total;
                    try {
                        JSONObject main = new JSONObject(response.trim());

                        JSONObject jPageInfo = main.getJSONObject("pageInfo");
                        total = Integer.parseInt(jPageInfo.getString("totalResults"));

                        if (total > 0) {
                            String IDs = Parser.getVideoID(main.getJSONArray("items"));

                            if (IDs != null && !IDs.isEmpty()) {
                                getVideoDetails(IDs);
                            } else {
                                noVideoFound();
                            }
                        } else {
                            noVideoFound();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        noVideoFound();
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                problemWithApiResponse();
            }
        });

        globals.addToRequestQueue(stringRequest);
    }

    public void getVideoDetails(String IDs) {
        if (ConnectionDetector.internetCheck(YoutubeListActivity.this)) {
            String URL = String.format(Constant.Youtube_GET_VIDEO_DETAIL_API, IDs, Constant.Youtube_Appkey);
            executeData(URL);
        }
    }


    private void executeData(String url) {
        mProgress = ProgressIndicator.show(YoutubeListActivity.this, "Loading...",true,false);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Debugger.debugI(TAG, "API response : " + response.toString().trim());
                mProgress.dismiss();
                if (!response.toString().trim().equalsIgnoreCase("error_in_response")) {
                    int total;
                    try {
                        JSONObject main = new JSONObject(response.trim());

                        JSONObject jPageInfo = main.getJSONObject("pageInfo");
                        total = Integer.parseInt(jPageInfo.getString("totalResults"));
                        if (total > 0) {
                            itemList = Parser.getVideoList(main.getJSONArray("items"));
                            if (itemList.size() > 0) {
                                switcher.setDisplayedChild(1);
                                adapter.updateResults(itemList);
                                rvVideos.setAdapter(adapter);
                            } else {
                                noVideoFound();
                            }
                        } else {
                            noVideoFound();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        noVideoFound();
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                problemWithApiResponse();


            }
        });
        globals.addToRequestQueue(stringRequest);
    }

    public void noVideoFound() {
        if (mProgress != null && mProgress.isShowing())
            mProgress.dismiss();
        ProgressIndicator.showCustomMessageOK(YoutubeListActivity.this, Constant.MM_ALERT_TITLE_ERROR, Constant.no_video_found);
        switcher.setDisplayedChild(0);
    }

    public void problemWithApiResponse() {
        if (mProgress != null && mProgress.isShowing())
            mProgress.dismiss();
        ConnectionDetector.showAlertDialog(YoutubeListActivity.this, Constant.MM_ALERT_TITLE_ERROR, Constant.MM_NO_INTERNET_RESPOND_MSG, true);
    }

}
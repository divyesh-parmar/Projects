package com.app.utility;

public class InAppBillingActivity extends BaseActionBarActivity /*implements PurchasesUpdatedListener*/ {

}
package com.android.drawerlistview;

public class EntryItem implements Item{

	public final String title;
	public final Group group;
	public final int img_Normal, img_selected;
	
	public EntryItem(String title, Group group, int img_Normal, int img_selected) {
		this.title = title;
		this.group = group;
		this.img_Normal = img_Normal;
		this.img_selected = img_selected;
	}
	
	@Override
	public boolean isSection() {
		return false;
	}
}

package com.app.favorites;

import static com.app.utility.Utils.selectedPlayListCategory;

import java.util.ArrayList;
import java.util.HashMap;

import android.app.Activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import android.util.Log;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ViewSwitcher;


import com.android.section.listview.AmazingListView;
import com.app.ads.InterstitialAdManager;
import com.app.ads.InterstitialUtils;
import com.app.ads.interfaces.InterstitialDismissListener;
import com.app.auto.RMusicService;
import com.app.desiradio.MainActivity;
import com.app.desiradio.PrepareDrawerList;
import com.app.parser.Channel;
import com.app.parser.Language;
import com.app.player.PlaylistManager;
import com.app.player.showRecordingInterruptDialogActivity;
import com.app.recorded.RecordedManager;
import com.app.recorded.RecordedPlayerService;
import com.app.utility.Constant;
import com.app.utility.Debugger;
import com.app.utility.Globals;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.indianradio.R;

public class FavoritesFragment extends Fragment implements OnItemClickListener, OnItemLongClickListener {

    Globals globals;
    View view;

    Menu mOptionsMenu;
    MenuInflater mMenuInflater;

    public static AmazingListView fList;
    public static ViewSwitcher switcher;
    public static FavoriteSectionListAdapter adapter;
    public static ArrayList<Channel> PlayerChannelList;
    public static ArrayList<Channel> savedFevoList;
    public static ArrayList<HashMap<String, String>> ownStationList;
    FirebaseCrashlytics crashlytics;

    LinearLayout contentLayout;

    public static String TAG;

    int tempPosition = -99;
    boolean onActivityResultCalled = false;
    int counter = 0;
    int pos;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        TAG = getClass().getName();
        globals = ((Globals) getActivity().getApplicationContext());
        setHasOptionsMenu(true);
        crashlytics = FirebaseCrashlytics.getInstance();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.favorites_layout, container, false);

        ((MainActivity) getActivity()).actionbar.setTitle(PrepareDrawerList.dw_entry_Favorites);
        globals.hideKeyboard(getActivity());

        switcher = (ViewSwitcher) view.findViewById(R.id.playlistSwitcher);

        fList = (AmazingListView) view.findViewById(R.id.FavoListView);
        fList.setOnItemClickListener(this);
        fList.setOnItemLongClickListener(this);

        contentLayout = (LinearLayout) view.findViewById(R.id.contentLayout);

        FetchList(getActivity());

        if (onActivityResultCalled)
            counter++;

        if (counter == 2 && tempPosition != -99) {
            playFavoriteStation(tempPosition);
            tempPosition = -99;
            counter = 0;
            onActivityResultCalled = false;
        }


        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        Debugger.debugI(TAG, "on resume called");

        globals.radioServiceActivity = getActivity();


    }

    public void openInterruptActivity(Bundle bundle) {
        // Start the activity whose result we want to retrieve.
        // The result will come back with request code GET_CODE.
        Intent intent = new Intent(getActivity(), showRecordingInterruptDialogActivity.class);
        intent.putExtras(bundle);
        // startActivityForResult(intent, Constant.MM_Recording_Favorites_list_Interrupt);
        someActivityResultLauncher.launch(intent);
    }

    ActivityResultLauncher<Intent> someActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        // There are no request codes
                        Intent data = result.getData();
                        switch (data.getIntExtra("actionID", 0)) {
                            case Constant.MM_ActionID_onSelectStation:
                                onActivityResultCalled = true;
                                counter = 0;

                                globals.radioServiceActivity = getActivity();
                                RMusicService.stopStation(getActivity());

                                break;
                        }
                    }
                }
            });

    public boolean checkIsRecording(int actionCode, int position) {
        if (PlaylistManager.isRecording() /*&& PlaylistManager.isIntentFromActivity((PlayerChannelList.get(position)))*/) {
            Bundle bundle = new Bundle();
            bundle.putInt("actionID", actionCode);
            openInterruptActivity(bundle);
            return true;
        } else {
            return false;
        }
    }

    public void invalidOptionsMenuHelper() {
        if (mOptionsMenu != null && mMenuInflater != null) {
            mOptionsMenu.clear();
            onCreateOptionsMenu(mOptionsMenu, mMenuInflater);
        }
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        mOptionsMenu = menu;
        mMenuInflater = inflater;
        inflater.inflate(R.menu.history_menu, menu);

        if ((savedFevoList != null && savedFevoList.size() > 0) || (ownStationList != null && ownStationList.size() > 0)) {
            menu.findItem(R.id.action_delete_all).setVisible(true);
        } else {
            menu.findItem(R.id.action_delete_all).setVisible(false);
        }

//        if (!RecordedManager.isPlaying() && Constant.mStationArrayList != null && Constant.mStationArrayList.size() > 0) {
//            menu.findItem(R.id.now_playing).setVisible(true);
//        } else {
//            menu.findItem(R.id.now_playing).setVisible(false);
//        }
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.action_delete_all:
                showDeleteAllDialog(getResources().getString(R.string.app_name), Constant.favorite_clear_all);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void FetchList(Context activity) {
        savedFevoList = globals.fetchFavoriteList(activity);
        ownStationList = globals.fetchUserAddedStationList(activity);
        if (savedFevoList.size() == 0 && ownStationList.size() == 0) {
            switcher.setDisplayedChild(0);
        } else {
            switcher.setDisplayedChild(1);
            LoadFavoriteList(activity,globals);
        }
        invalidOptionsMenuHelper();
    }

    public static void LoadFavoriteList(Context activity, Globals globals) {
        if (fList.getAdapter() == null) {
            adapter = new FavoriteSectionListAdapter(activity, createSectionList(globals));
            fList.setPinnedHeaderView(LayoutInflater.from(activity).inflate(R.layout.item_composer_header, fList, false));
            fList.setAdapter(adapter);
        } else {
            adapter.RefreshList(createSectionList(globals));
        }
    }

    public static ArrayList<Pair<String, ArrayList<Channel>>> createSectionList(Globals globals) {

        ArrayList<Pair<String, ArrayList<Channel>>> res = new ArrayList<Pair<String, ArrayList<Channel>>>();
        PlayerChannelList = new ArrayList<Channel>();
        ArrayList<Language> languages = globals.getLanguageList();
        if (languages.size() > 0) {

            for (int i = 0; i < languages.size(); i++) {
                ArrayList<Channel> tempChannelList = new ArrayList<Channel>();
                boolean isAnyChannelFound = false;
                int languageID = Integer.parseInt(languages.get(i).LanguageId);

                for (int j = 0; j < savedFevoList.size(); j++) {
                    Debugger.debugI(TAG, "favourite added == " + savedFevoList.get(j).ChannelTitle);
                    if (languageID == Integer.parseInt(savedFevoList.get(j).LanguageId)) {
                        isAnyChannelFound = true;

                        tempChannelList.add(savedFevoList.get(j));
                        PlayerChannelList.add(savedFevoList.get(j));
                    }
                }

                if (isAnyChannelFound) {
                    res.add(new Pair<String, ArrayList<Channel>>(languages.get(i).LanguageName, tempChannelList));
                }
            }
        }

        int count = ownStationList.size();
        if (count > 0) {
            ArrayList<Channel> tempOwnChannelList = new ArrayList<Channel>();
            for (int i = 0; i < count; i++) {
                HashMap<String, String> ownStation = ownStationList.get(i);

                Channel ownChannel = new Channel(ownStation.get(Constant.MM_OWN_STATION_RANDOM_ID).toString(), ownStation.get(Constant.MM_OWN_STATION_NAME).toString(), ownStation.get(Constant.MM_OWN_STATION_URL).toString(), ownStation.get(Constant.MM_OWN_STATION_URL).toString(), "", 0, "", "", "", 0);
                Debugger.debugI(TAG, "Added channel == " + ownChannel.ChannelTitle);
                tempOwnChannelList.add(ownChannel);
                PlayerChannelList.add(ownChannel);
            }

            if (tempOwnChannelList.size() > 0) {
                res.add(new Pair<String, ArrayList<Channel>>("User Added", tempOwnChannelList));
            }
        }
        return res;
    }

    @Override
    public void onItemClick(AdapterView<?> arg0, View view, int position, long arg3) {
        if (RecordedPlayerService.rPlayer != null && RecordedPlayerService.rPlayer.isPlaying()){
           // RecordedManager.setIsPlayingFlag(false);
            RecordedPlayerService.stopPLaying();
            RecordedManager.init();
        }

        selectedPlayListCategory = 1;
        if (!checkIsRecording(Constant.MM_ActionID_onSelectStation, position)) {
            playFavoriteStation(position);
        } else {
            tempPosition = position;
        }
    }

    public void playFavoriteStation(int position) {
        pos = position;
        Constant.mStationArrayList = PlayerChannelList;

        if (InterstitialAdManager.getInstance().showInterstitial(getActivity()) && InterstitialUtils.getInstance().interstitialAd != null) {
            InterstitialUtils.getInstance().displayInterstitialAd(getActivity(), new InterstitialDismissListener() {
                @Override
                public void onInterstitialDismissListener(Activity activity, int ButtonId) {
                    PlaylistManager.setStationType("favorites");
                    PlaylistManager.setPlayerDetail(getActivity(), pos, PlayerChannelList);
                }
            }, 616263);
        } else {
            PlaylistManager.setStationType("favorites");
            PlaylistManager.setPlayerDetail(getActivity(), pos, PlayerChannelList);
        }
    }

    @Override
    public boolean onItemLongClick(AdapterView<?> arg0, View view, int arg2, long arg3) {
        showSingleItemDeleteDialog(
                getResources().getString(R.string.app_name),
                Constant.fevorite_remove_msg,
                ((TextView) view.findViewById(R.id.txt_channel_name)).getTag().toString().trim(),
                ((TextView) view.findViewById(R.id.txt_channel_desc)).getTag().toString().trim()
        );
        return true;
    }

    public void showSingleItemDeleteDialog(String pTitle, final String pMsg, final String cID, final String stationURL) {

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        builder.setCancelable(false);
        builder.setTitle(pTitle);
        builder.setMessage(pMsg);
        builder.setIcon(R.mipmap.ic_launcher);
        builder.setPositiveButton("Yes",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (cID == null || cID.isEmpty() || cID.equalsIgnoreCase("")) {
                            removeUserAddedStationItem(stationURL);
                        } else {
                            removeFavoriteItem(cID);
                        }
                        dialog.dismiss();
                    }
                });

        builder.setNegativeButton("No",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        AlertDialog alert = builder.create();
        alert.show();
    }

    public void showDeleteAllDialog(String pTitle, final String pMsg) {

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setCancelable(false);
        builder.setTitle(pTitle);
        builder.setMessage(pMsg);
        builder.setIcon(R.mipmap.ic_launcher);
        builder.setPositiveButton("Yes",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        savedFevoList.clear();
                        ownStationList.clear();
                        globals.saveUserAddedStationList(getActivity(), ownStationList);
                        globals.saveFavoriteList(getActivity(), savedFevoList);
                        FetchList(getActivity());
                        dialog.dismiss();
                    }
                });

        builder.setNegativeButton("No",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        AlertDialog alert = builder.create();
        alert.show();
    }

    public void removeFavoriteItem(String ID) {
        int index = -99;
        for (int i = 0; i < savedFevoList.size(); i++) {
            if (savedFevoList.get(i).ChannelId.equals(ID)) {
                index = i;
                break;
            }
        }

        if (index != -99) {

            savedFevoList.remove(index);
            globals.saveFavoriteList(getActivity(), savedFevoList);
            FetchList(getActivity());
        }
    }

    public void removeUserAddedStationItem(String stationURL) {
        int index = -99;
        for (int i = 0; i < ownStationList.size(); i++) {
            if (ownStationList.get(i).get(Constant.MM_OWN_STATION_URL).equalsIgnoreCase(stationURL)) {
                index = i;
                break;
            }
        }

        if (index != -99) {
            ownStationList.remove(index);
            globals.saveUserAddedStationList(getActivity(), ownStationList);
            FetchList(getActivity());
        }
    }

}

package com.android.GoogleAnalytics;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.indianradio.R;

public class Analytics {

	//public Tracker mTrackers = null;
	private FirebaseAnalytics mFirebaseAnalytics;
	Activity mContext;


	public Analytics(Activity context) {
		super();
		// May return null if EasyTracker has not yet been initialized with a property ID.
		// mTrackers = getTracker(context);
		// Obtain the FirebaseAnalytics instance.
		mContext = context;
		mFirebaseAnalytics = FirebaseAnalytics.getInstance(context);
	}
	
	synchronized FirebaseAnalytics getTracker(Activity context) {
        if (mFirebaseAnalytics == null) {
        	mContext = context;
			mFirebaseAnalytics = FirebaseAnalytics.getInstance(context);
        }
        return mFirebaseAnalytics;
    }
	
	public void Screen_Measurement(String screenName) {
		// Set screen name. 
		mFirebaseAnalytics.setCurrentScreen(mContext, screenName, null);
        // Send a screen view.
		//mTrackers.send(new HitBuilders.AppViewBuilder().build());
	}

	public void Event_Tracking(String EC_name, String EA_name, String EL_name) {
        // Build and send an Event.
		Bundle params = new Bundle();
		params.putString(FirebaseAnalytics.Param.ITEM_CATEGORY, EC_name);
		params.putString("action", EA_name);
		params.putString("label", EL_name);

		mFirebaseAnalytics.logEvent(EA_name, params);
	}
	
	public void Ecommerce_Tracking(String orderID, String name, String sku, double price) {

		// Build and send an Event.
		Bundle params = new Bundle();
		params.putString(FirebaseAnalytics.Param.ITEM_ID, orderID);
		params.putString(FirebaseAnalytics.Param.ITEM_NAME, name);
		params.putString("sku", sku);
		params.putDouble(FirebaseAnalytics.Param.PRICE, price);
		params.putString(FirebaseAnalytics.Param.CURRENCY, "USD"); // e.g. $1.00 USD

		mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.PURCHASE, params);

		  // Build an item.
		 /*mTrackers.send(new HitBuilders.ItemBuilder()
	          .setTransactionId(orderID)
	          .setName(name)
	          .setSku(sku)
	          .setCategory(name)
	          .setPrice(price)
	          .setQuantity(1)
	          .setCurrencyCode("USD")
	          .build());*/
	}
}
	
	
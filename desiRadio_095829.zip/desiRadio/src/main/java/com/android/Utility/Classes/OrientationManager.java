package com.android.Utility.Classes;

import android.content.Context;
import android.content.res.Configuration;
import android.provider.Settings;
import android.view.OrientationEventListener;

public class OrientationManager extends OrientationEventListener{

	String TAG;
	private int previousAngle;
	private int previousOrientation;
	private Context context;
	private OrientationChangeListener orientationChangeListener;
	private static OrientationManager instance;
	private OrientationManager(Context context) {
	    super(context);
	    this.context = context;
	    TAG = getClass().getName();
	}

	public static OrientationManager  getInstance(Context context){
	    if (instance == null){
	        instance = new OrientationManager(context);
	    }
	    return instance;
	}

	public int getOrientation(){
	    return previousOrientation;
	}

	public void setOrientation(int orientation){
	    this.previousOrientation = orientation;
	}

	@Override
	public void onOrientationChanged(int orientation) {
		
		if (android.provider.Settings.System.getInt(context.getContentResolver(),Settings.System.ACCELEROMETER_ROTATION, 0) == 1){
			if (orientation == -1)
		        return;
		    if(previousOrientation == 0){
		        previousOrientation = context.getResources().getConfiguration().orientation;
		        if (orientationChangeListener != null){
		            orientationChangeListener.onOrientationChanged(previousOrientation);
		        }           
		    }
		    if (previousOrientation == Configuration.ORIENTATION_LANDSCAPE && ((previousAngle > 10 && orientation <= 10) || (previousAngle < 350 && previousAngle > 270 && orientation >= 350))){
		        if (orientationChangeListener != null){
		            orientationChangeListener.onOrientationChanged(Configuration.ORIENTATION_PORTRAIT);
		        }
		        previousOrientation = Configuration.ORIENTATION_PORTRAIT;
		    }

		    if (previousOrientation == Configuration.ORIENTATION_PORTRAIT && ((previousAngle <90 && orientation >= 90 && orientation <270) || (previousAngle > 280 && orientation <= 280 && orientation > 180))){
		        if (orientationChangeListener != null){
		            orientationChangeListener.onOrientationChanged(Configuration.ORIENTATION_LANDSCAPE);
		        }
		        previousOrientation = Configuration.ORIENTATION_LANDSCAPE;
		    }
		    previousAngle = orientation;
		} 
	}

	public void setOrientationChangedListener(OrientationChangeListener l){
	    this.orientationChangeListener = l;
	}

	public interface OrientationChangeListener{
	    public void onOrientationChanged(int newOrientation);
	}
	}
package com.app.genre;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.Utility.Classes.ImageLoader;
import com.app.ads.NativeAdsUtils;
import com.app.parser.Channel;
import com.app.player.PlaylistManager;
import com.app.utility.Constant;
import com.app.utility.Constant.PlayingMode;
import com.app.utility.Constant;
import com.app.utility.Globals;
import com.app.utility.Utils;
import com.google.android.ads.nativetemplates.TemplateView;
import com.indianradio.R;

public class ChannelListAdapter extends BaseAdapter implements Filterable {

    Globals globals;
    private Activity activity;
    private static LayoutInflater inflater = null;
    public ImageLoader imageLoader;
    OnItemClickListener onItemClickListener;
    private ArrayList<ChannelItem> data;
    public static ArrayList<ChannelItem> temporarylist;
    private PlayingMode playingMode;
    View nativeView;

    public ChannelListAdapter(Activity a, PlayingMode playingMode, OnItemClickListener onItemClickListener) {
        activity = a;
        globals = ((Globals) activity.getApplicationContext());
        imageLoader = new ImageLoader(activity.getApplicationContext());
        inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.onItemClickListener = onItemClickListener;
        data = new ArrayList<ChannelItem>();
        temporarylist = new ArrayList<ChannelItem>();
        this.playingMode = playingMode;
    }

    public void refreshList(ArrayList<ChannelItem> d) {
        data = d;
        temporarylist = d;
        this.notifyDataSetChanged();
    }

    public int getCount() {
        return temporarylist.size();
    }

    public ArrayList<ChannelItem> getCurrentVisibleList() {
        return temporarylist;
    }

    @Override
    public ChannelItem getItem(int position) {
        return temporarylist.get(position);
    }

    public long getItemId(int position) {
        return position;
    }

    public Channel getselectedChannel(int position) {
        return getItem(position).getChannelMap();
    }

    public static class ViewHolder {
        public TextView name;
        public TextView desc;
        public TextView bytes;
        public LinearLayout isNew;
        public LinearLayout my_item;
        public ImageView favoriteImage;
        public ImageView listen_icon;
        LinearLayout templateView;
        public LinearLayout div1;

        TextView tv_sponsored;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        View vi = convertView;
        ViewHolder holder;
        if (convertView == null) {
            vi = inflater.inflate(R.layout.channel_item, null);
            holder = new ViewHolder();
            holder.name = (TextView) vi.findViewById(R.id.txt_channel_name);
            holder.desc = (TextView) vi.findViewById(R.id.txt_channel_desc);
            holder.bytes = (TextView) vi.findViewById(R.id.txt_byte);
            holder.isNew = (LinearLayout) vi.findViewById(R.id.isNew);
            holder.favoriteImage = (ImageView) vi.findViewById(R.id.img_favo);
            holder.listen_icon = (ImageView) vi.findViewById(R.id.listen_icon);
            holder.templateView = vi.findViewById(R.id.templateView);
            holder.div1 = vi.findViewById(R.id.div1);
            holder.my_item = vi.findViewById(R.id.my_item);


            holder.tv_sponsored = (TextView) vi.findViewById(R.id.tv_sponsored);

            vi.setTag(holder);
        } else
            holder = (ViewHolder) vi.getTag();

        ChannelItem channelItem = getItem(position);


        if (Constant.nativePlaceList.contains(position)) {

            if (Utils.getInt(activity, activity.getResources().getString(R.string.In_app_product_ads_id), 0) == 0) {
                if (holder.templateView != null) {
                    NativeAdsUtils.getInstance().showNative(activity, holder.templateView);
                }

                holder.templateView.setVisibility(View.VISIBLE);
                holder.div1.setVisibility(View.VISIBLE);
            } else {
                holder.templateView.setVisibility(View.GONE);
                holder.div1.setVisibility(View.GONE);
            }
        } else {
            holder.templateView.setVisibility(View.GONE);
            holder.div1.setVisibility(View.GONE);
        }
        
        /*NativeAdItem nativeAdItem = channelItem.getNativeAdItem();
        if (nativeAdItem != null) {
        	if(globals.getNativeAdFlag().equalsIgnoreCase(Constant.MM_INMOBI_NATIVE_ADS)) {
            	
        		IMNative nativeAd = channelItem.getInMobiNativeAd();
        		// The below step is for Impression Tracking. This is Mandatory.
    			nativeAd.attachToView((ViewGroup) vi);
    			showAd(position, holder, nativeAdItem);
    	        return vi;
        		
            } else if(globals.getNativeAdFlag().equalsIgnoreCase(Constant.MM_STARTAPP_NATIVE_ADS)) {
            	
            	if(!channelItem.isDisplayed()) {
	            	NativeAdDetails startAppAd = channelItem.getStartAppNativeAd();
	            	startAppAd.sendImpression(activity);
	            	channelItem.setDisplayed(true);
            	}
            	showAd(position, holder, nativeAdItem);
                return vi;
            }
        }*/


        holder.tv_sponsored.setVisibility(View.GONE);

        Channel info = channelItem.getChannelMap();
        if (playingMode == PlayingMode.OTHER && Integer.parseInt(info.ChannelIsNew) == 1)
            holder.isNew.setVisibility(View.VISIBLE);
        else
            holder.isNew.setVisibility(View.GONE);

        holder.name.setText(info.ChannelTitle);

        String desc = info.ChannelDescription;
        if (playingMode == PlayingMode.HISTORY)
            desc = getCurrentFromettedDate(new Date(info.lastPlayedDate));
        holder.desc.setText(desc);

        if (info.ChannelByte != null && info.ChannelByte.toString().trim().length() > 0) {
            holder.bytes.setVisibility(View.VISIBLE);
            holder.bytes.setText(info.ChannelByte + "K");
        } else {
            holder.bytes.setVisibility(View.GONE);
        }

        holder.listen_icon.setVisibility(View.VISIBLE);

//        if (Utils.getInt(activity,"mode",0) == 0){
//            holder.listen_icon.setBackgroundResource(R.drawable.listen_normal);
//        }else {
        holder.listen_icon.setImageResource(R.drawable.headphones);
//        }
        if (PlaylistManager.isPlaying() && PlaylistManager.isStationPlaying(info)) {
            holder.listen_icon.setImageResource(R.drawable.headphones_blue);
        }

        if (playingMode == PlayingMode.OTHER && info.isFavorite)
            holder.favoriteImage.setVisibility(View.VISIBLE);
        else
            holder.favoriteImage.setVisibility(View.INVISIBLE);

        holder.my_item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onItemClickListener.onItemClick(position);
            }
        });
        return vi;
    }
    
    /*public void showAd(int position, ViewHolder holder, NativeAdItem nativeAdItem) {
		if (nativeAdItem != null) {
			holder.img_ad.setVisibility(View.VISIBLE);
	        holder.tv_sponsored.setVisibility(View.VISIBLE);
			
			holder.name.setText(nativeAdItem.title);
			holder.desc.setText(nativeAdItem.cta);
			
			holder.isNew.setVisibility(View.GONE);
			holder.bytes.setVisibility(View.GONE);
			holder.listen_icon.setVisibility(View.GONE);
			holder.favoriteImage.setVisibility(View.INVISIBLE);
			
			holder.img_ad.setTag(nativeAdItem.iconURL);
	        imageLoader.DisplayImage(nativeAdItem.iconURL, holder.img_ad, R.drawable.img_loader_stub, true);
		}
    }*/

    public String getCurrentFromettedDate(Date date) {
        SimpleDateFormat postFormater = new SimpleDateFormat("MMM dd, yyyy hh:mm a", Locale.getDefault());
        return postFormater.format(date);
    }

    public Filter getFilter() {
        Filter filter = new Filter() {

            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                FilterResults results = new FilterResults();

                //If there's nothing to filter on, return the original data for your list
                if (charSequence == null || charSequence.length() == 0) {
                    results.values = data;
                    results.count = data.size();
                } else {
                    ArrayList<ChannelItem> filterResultsData = new ArrayList<ChannelItem>();

                    for (int i = 0; i < data.size(); i++) {
                        ChannelItem temp = data.get(i);
                        
                        /*NativeAdItem nativeAdItem = temp.getNativeAdItem();
                        if (nativeAdItem != null) {
                        	if (temp.getNativeAdItem().title.toString().trim().toLowerCase().contains(charSequence.toString().trim().toLowerCase()))  {
                        		filterResultsData.add(temp);
                        	}
                        }
                        else*/
                        {
                            if (temp.getChannelMap().ChannelTitle.toString().trim().toLowerCase().contains(charSequence.toString().trim().toLowerCase())) {
                                filterResultsData.add(temp);
                            }
                        }
                    }
                    results.values = filterResultsData;
                    results.count = filterResultsData.size();
                }
                return results;
            }

            @SuppressWarnings("unchecked")
            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                temporarylist = (ArrayList<ChannelItem>) results.values;
                notifyDataSetChanged();
            }
        };
        return filter;
    }
}
package com.app.parser;

import androidx.annotation.Keep;

import java.io.Serializable;

@Keep
public class Channel implements Comparable<Channel>, Serializable {
    public String ChannelId;
    public String ChannelTitle;
    public String ChannelDescription;
    public String ChannelLink;
    public String ChannelByte;
    public int SortOrder;
    public String ChannelIsNew;
    public String LanguageId;
    public String LanguageName;
    public boolean isFavorite;
    public long lastPlayedDate;

    public Channel(String ChannelId, String ChannelTitle,
                   String ChannelDescription, String ChannelLink, String ChannelByte,
                   int SortOrder, String ChannelIsNew, String LanguageId,
                   String LanguageName, long lastPlayedDate) {
        this.ChannelId = ChannelId;
        this.ChannelTitle = ChannelTitle;
        this.ChannelDescription = ChannelDescription;
        this.ChannelLink = ChannelLink;
        this.ChannelByte = ChannelByte;
        this.SortOrder = SortOrder;
        this.ChannelIsNew = ChannelIsNew;
        this.LanguageId = LanguageId;
        this.LanguageName = LanguageName;
        this.isFavorite = false;
        this.lastPlayedDate = lastPlayedDate;

    }

    @Override
    public int compareTo(Channel sp) {
        return this.ChannelId.compareTo(sp.ChannelId);
    }

    /*@Override
    public String toString() {
        return SortOrder + "<";
    }*/

    @Override
    public String toString() {
        return "Channel{" +
                "ChannelId='" + ChannelId + '\'' +
                ", ChannelTitle='" + ChannelTitle + '\'' +
                ", ChannelDescription='" + ChannelDescription + '\'' +
                ", ChannelLink='" + ChannelLink + '\'' +
                ", ChannelByte='" + ChannelByte + '\'' +
                ", SortOrder=" + SortOrder +
                ", ChannelIsNew='" + ChannelIsNew + '\'' +
                ", LanguageId='" + LanguageId + '\'' +
                ", LanguageName='" + LanguageName + '\'' +
                ", isFavorite=" + isFavorite +
                ", lastPlayedDate=" + lastPlayedDate +
                '}';
    }

    public String toJsonData() {
        return String.format("{\"ChannelByte\":\"%s\",\"ChannelDescription\":\"%s\",\"ChannelId\":\"%s\",\"ChannelIsNew\":\"%s\",\"ChannelLink\":\"%s\",\"ChannelTitle\":\"%s\",\"LanguageId\":\"%s\",\"LanguageName\":\"%s\",\"SortOrder\":%d,\"isFavorite\":%s,\"lastPlayedDate\":%d}",
                ChannelByte, ChannelDescription, ChannelId, ChannelIsNew, ChannelLink, ChannelTitle, LanguageId, LanguageName, SortOrder, isFavorite, lastPlayedDate);
    }
}
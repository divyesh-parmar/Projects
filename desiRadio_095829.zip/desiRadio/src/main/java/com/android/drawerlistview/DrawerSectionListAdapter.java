package com.android.drawerlistview;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.ToggleButton;

import androidx.appcompat.app.AppCompatDelegate;

import com.android.drawerlistview.Item.Group;
import com.app.desiradio.MainActivity;
import com.app.desiradio.PrepareDrawerList;
import com.app.utility.Debugger;
import com.app.utility.Globals;
import com.app.utility.Utils;
import com.indianradio.R;

public class DrawerSectionListAdapter extends BaseAdapter {

    Context context;
    private String SelectedTitle = PrepareDrawerList.dw_entry_Genre;
    private ArrayList<Item> items;
    private LayoutInflater inflater;

    public DrawerSectionListAdapter(Context context, ArrayList<Item> items) {
        this.items = items;
        this.context = context;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public void refreshAdapter(ArrayList<Item> items) {
        Debugger.debugI("TAG", "item list size : " + items.size());
        this.items = items;
        this.notifyDataSetChanged();
    }

    public void setSelectedTitle(String title) {
        Debugger.debugI("TAG", "Selected item : " + title);
        SelectedTitle = title;
        this.notifyDataSetChanged();
    }

    public String getSelectedTitle() {
        return SelectedTitle;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        final Item i = items.get(position);
        if (i != null) {
            //check is item is section or sub item
            if (i.isSection()) {
                SectionItem si = (SectionItem) i;
                row = inflater.inflate(R.layout.drawerlist_item_section, null);

                row.setOnClickListener(null);
                row.setOnLongClickListener(null);
                row.setLongClickable(false);

                final TextView sectionView = (TextView) row.findViewById(R.id.list_item_section_text);
                sectionView.setText(si.getTitle().toUpperCase());

            } else {
                EntryItem ei = (EntryItem) i;

                if (ei.group == Group.Notification) {
                    row = inflater.inflate(R.layout.drawerlist_item_toggler, parent, false);
                    ToggleButton btn_toggle = (ToggleButton) row.findViewById(R.id.btn_toggle_notification);
                    btn_toggle.setChecked(((Globals) context.getApplicationContext()).isNotificationON());

                    ProgressBar GCM_progressBar = (ProgressBar) row.findViewById(R.id.GCM_progressBar);
                    if (((Globals) context.getApplicationContext()).isRequestPandding())
                        GCM_progressBar.setVisibility(View.VISIBLE);
                    else
                        GCM_progressBar.setVisibility(View.GONE);

                } else {
                    row = inflater.inflate(R.layout.drawerlist_item_entry, null);
                    final TextView title = (TextView) row.findViewById(R.id.list_item_entry_title);
                    final ImageView img = (ImageView) row.findViewById(R.id.Icon);
                    final LinearLayout containerLayout = (LinearLayout) row.findViewById(R.id.containerLayout);

                    if (title != null)
                        title.setText(ei.title);

                    if (ei.title.equalsIgnoreCase(SelectedTitle)) {

                        containerLayout.setBackgroundColor(context.getResources().getColor(R.color.drawer_selection));


                        img.setImageResource(ei.img_selected);
//						title.setTextColor(context.getResources().getColor(R.color.White));
                    } else {
                        containerLayout.setBackgroundColor(0);
                        img.setImageResource(ei.img_Normal);
//						title.setTextColor(context.getResources().getColor(R.color.Black));
                    }
                }
            }
        }
        return row;
    }
}

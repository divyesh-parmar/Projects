package com.app.genre;

import static com.app.utility.Utils.selectedPlayListCategory;
import static com.app.utility.Utils.showNativeOrNot;

import java.util.ArrayList;
import java.util.Collections;

import android.app.Activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ViewSwitcher;

import com.android.GoogleAnalytics.Analytics;
import com.android.GoogleAnalytics.AnalyticsConstant;
import com.app.ads.InterstitialAdManager;
import com.app.ads.InterstitialUtils;
import com.app.ads.NativeAdsUtils;
import com.app.ads.interfaces.InterstitialDismissListener;
import com.app.auto.RMusicService;
import com.app.desiradio.MainActivity;
import com.app.desiradio.PrepareDrawerList;
import com.app.http.ConnectionDetector;
import com.app.parser.Channel;
import com.app.player.PlaylistManager;

import com.app.player.showRecordingInterruptDialogActivity;
import com.app.recorded.RecordedManager;
import com.app.recorded.RecordedPlayerService;
import com.app.utility.Constant;
import com.app.utility.Constant.PlayingMode;
import com.app.utility.Constant;
import com.app.utility.Debugger;
import com.app.utility.Globals;
import com.app.utility.Utils;
import com.google.android.gms.ads.AdView;
import com.indianradio.R;

public class HistorylListFragment extends Fragment implements OnItemLongClickListener {

    Globals globals;
    View view;

    ViewSwitcher switcher;
    //	ListView lv_History;
    public static RecyclerView rvHistory;
    public static ChannelListRAdapter adapter;

    Menu mOptionsMenu;
    MenuInflater mMenuInflater;

    ArrayList<Channel> HistoryChannels = new ArrayList<Channel>();
    ArrayList<Channel> tempHistoryChannels = new ArrayList<Channel>();

    LinearLayout contentLayout;

    //google Analytics obj
    public static String TAG;

    int tempPosition = -99;
    boolean onActivityResultCalled = false;
    int counter = 0;
    int pos;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        globals = ((Globals) getActivity().getApplicationContext());
        TAG = getClass().getName();
        NativeAdsUtils.getInstance().removeAdView();
        Constant.nativePlaceList.clear();
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.history_list_fragment, container, false);

        ((MainActivity) getActivity()).actionbar.setTitle(PrepareDrawerList.dw_entry_History);
        globals.hideKeyboard(getActivity());

        rvHistory = view.findViewById(R.id.rv_history);
        rvHistory.setLayoutManager(new GridLayoutManager(getActivity(), 1));

        switcher = (ViewSwitcher) view.findViewById(R.id.playlistSwitcher);
        contentLayout = (LinearLayout) view.findViewById(R.id.contentLayout);

        updateData();

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        Debugger.debugI(TAG, "on resume called");
        globals.radioServiceActivity = getActivity();

    }

    public void updateData() {
        FetchList();

        if (onActivityResultCalled)
            counter++;

        if (counter == 2 && tempPosition != -99) {
            playHistoryStation(tempPosition);
            tempPosition = -99;
            counter = 0;
            onActivityResultCalled = false;
        }
    }

    public void openInterruptActivity(Bundle bundle) {
        // Start the activity whose result we want to retrieve.
        // The result will come back with request code GET_CODE.
        Intent intent = new Intent(getActivity(), showRecordingInterruptDialogActivity.class);
        intent.putExtras(bundle);
//        startActivityForResult(intent, Constant.MM_Recording_History_list_Interrupt);
        someActivityResultLauncher.launch(intent);
    }

    ActivityResultLauncher<Intent> someActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        // There are no request codes
                        Intent data = result.getData();
                        switch (data.getIntExtra("actionID", 0)) {
                            case Constant.MM_ActionID_onSelectStation:
                                onActivityResultCalled = true;
                                counter = 0;

                                globals.radioServiceActivity = getActivity();
                                RMusicService.stopStation(getActivity());

                                break;
                        }
                    }
                }
            });

    public boolean checkIsRecording(int actionCode, int position) {
        if (PlaylistManager.isRecording() /*&& PlaylistManager.isIntentFromActivity(tempHistoryChannels.get(position))*/) {
            Bundle bundle = new Bundle();
            bundle.putInt("actionID", actionCode);
            openInterruptActivity(bundle);
            return true;
        } else {
            return false;
        }
    }

    public void invalidOptionsMenuHelper() {
        if (mOptionsMenu != null && mMenuInflater != null) {
            mOptionsMenu.clear();
            onCreateOptionsMenu(mOptionsMenu, mMenuInflater);
        }
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        mOptionsMenu = menu;
        mMenuInflater = inflater;
        inflater.inflate(R.menu.history_menu, menu);

        if (HistoryChannels != null && HistoryChannels.size() > 0) {
            menu.findItem(R.id.action_delete_all).setVisible(true);
        } else {
            menu.findItem(R.id.action_delete_all).setVisible(false);
        }

//        if (!RecordedManager.isPlaying() && Constant.mStationArrayList != null && Constant.mStationArrayList.size() > 0) {
//            menu.findItem(R.id.now_playing).setVisible(true);
//        } else {
//            menu.findItem(R.id.now_playing).setVisible(false);
//        }

        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.action_delete_all:
                showDeleteAllDialog(getResources().getString(R.string.app_name), Constant.history_clear_all);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void FetchList() {
        HistoryChannels = globals.fetchHistoryList(getActivity());
        if (HistoryChannels.size() == 0) {
            switcher.setDisplayedChild(0);
        } else {
            switcher.setDisplayedChild(1);
            LoadHistoryList();
        }
        invalidOptionsMenuHelper();
    }

    public void LoadHistoryList() {
        if (rvHistory.getAdapter() == null) {
            adapter = new ChannelListRAdapter(getActivity(), PlayingMode.HISTORY, new com.app.genre.OnItemClickListener() {
                @Override
                public void onItemClick(int position) {
                    selectedPlayListCategory = 2;

                    if (RecordedPlayerService.rPlayer != null && RecordedPlayerService.rPlayer.isPlaying()){

                        RecordedPlayerService.stopPLaying();
                        RecordedManager.init();
                    }

                    if (!checkIsRecording(Constant.MM_ActionID_onSelectStation, position)) {
                        playHistoryStation(position);
                    } else {
                        tempPosition = position;
                    }
                }
            });
            rvHistory.setAdapter(adapter);
        }
        tempHistoryChannels.clear();
        tempHistoryChannels.addAll(HistoryChannels);

        Collections.reverse(tempHistoryChannels);
        adapter.refreshList(globals.convertChannelObjList(tempHistoryChannels));
        if (showNativeOrNot(getActivity())) {
            Constant.nativePlaceList = Utils.generateRandomListNative(globals.convertChannelObjList(tempHistoryChannels).size());

        }
    }

    public void playHistoryStation(int position) {
        pos = position;

        if (InterstitialAdManager.getInstance().showInterstitial(getActivity()) && InterstitialUtils.getInstance().interstitialAd != null) {
            InterstitialUtils.getInstance().displayInterstitialAd(getActivity(), new InterstitialDismissListener() {
                @Override
                public void onInterstitialDismissListener(Activity activity, int ButtonId) {
                    Constant.mStationArrayList = tempHistoryChannels;
                    PlaylistManager.setStationType("history");
                    PlaylistManager.setPlayerDetail(getActivity(), pos, tempHistoryChannels);
                }
            }, 616264);
        } else {
            Constant.mStationArrayList = tempHistoryChannels;
            PlaylistManager.setStationType("history");
            PlaylistManager.setPlayerDetail(getActivity(), pos, tempHistoryChannels);
        }
    }

    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
        showSingleHistoryDeleteDialog(getResources().getString(R.string.app_name), Constant.history_remove_msg, (HistoryChannels.size() - position - 1));
        return true;
    }

    public void showSingleHistoryDeleteDialog(String pTitle, final String pMsg, final int index) {

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());


        builder.setCancelable(false);
        builder.setTitle(pTitle);
        builder.setMessage(pMsg);
        builder.setIcon(R.mipmap.ic_launcher);
        builder.setPositiveButton("Yes",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        HistoryChannels.remove(index);
                        globals.saveHistoryList(getActivity(), HistoryChannels);
                        FetchList();
                        dialog.dismiss();
                    }
                });

        builder.setNegativeButton("No",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        AlertDialog alert = builder.create();
        alert.show();
    }

    public void showDeleteAllDialog(String pTitle, final String pMsg) {

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());


        builder.setCancelable(false);
        builder.setTitle(pTitle);
        builder.setMessage(pMsg);
        builder.setIcon(R.mipmap.ic_launcher);
        builder.setPositiveButton("Yes",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        HistoryChannels.clear();
                        globals.saveHistoryList(getActivity(), HistoryChannels);
                        FetchList();
                        dialog.dismiss();
                    }
                });

        builder.setNegativeButton("No",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        AlertDialog alert = builder.create();
        alert.show();
    }

}
package com.app.desiradio;

import static com.app.utility.Utils.channelInPlayList;

import java.util.ArrayList;
import java.util.Date;

import android.app.Application;
import android.content.Context;
import android.content.Intent;

import android.os.Bundle;
import android.os.Handler;
import android.text.format.DateFormat;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.android.Utility.Classes.UnCaughtException;
import com.app.ads.AppOpenAdManager;
import com.app.ads.interfaces.OpenAdLoadListener;
import com.app.ads.interfaces.ShowOpenAdCompleteListener;
import com.app.firebase.FirebaseRemoteConfigUtils;
import com.app.firebase.RemoteConfigLoadListener;
import com.app.genre.ChannelManager;
import com.app.googleservices.purchase.InAppBillingManager;
import com.app.http.ConnectionDetector;
import com.app.parser.Channel;
import com.app.player.PlaylistManager;

import com.app.recorded.RecordedManager;
import com.app.sqlite.DBHelper;
import com.app.utility.Constant;

import com.app.utility.Debugger;
import com.app.utility.Globals;
import com.app.utility.ResizeHelper;
import com.app.utility.Utils;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.indianradio.BuildConfig;
import com.indianradio.R;

public class SplashScreenActivity extends AppCompatActivity implements OpenAdLoadListener, RemoteConfigLoadListener {

    Globals globals;
    Boolean isInternetPresent = false;
    LinearLayout overlay_layout;
    Button btn_try_again;
    Context mContext;
    public static String TAG;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_screen_layout);
        getWindow().addFlags(1024);
        TAG = getClass().getName();
        mContext = this;

        getSupportActionBar().hide();
        //init firebase analytics
        FirebaseAnalytics firebaseAnalytics = FirebaseAnalytics.getInstance(this);

        Debugger.debugI(TAG, "\n\n" + getString(R.string.app_name) + " App Started on : " + DateFormat.format("dd-MM-yyyy hh:mm:ss", new Date().getTime()) + "\n\n");
        globals = ((Globals) getApplicationContext());
        globals.initialize();

        ResizeHelper.getHeightAndWidth(this);
        ResizeHelper.setSize(findViewById(R.id.iv_logo), 850, 850, true);

        //reset all variables
        RecordedManager.init();
        //VideolistManager.init();
        PlaylistManager.init();
        ChannelManager.resetAll();

        progressBar = findViewById(R.id.progress_bar);


        overlay_layout = (LinearLayout) findViewById(R.id.overlay_layout);
        overlay_layout.setVisibility(View.GONE);

        btn_try_again = (Button) findViewById(R.id.btn_try_again);
        btn_try_again.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                performOpration(0);
            }
        });


        Utils.flagSplash = 1;
        Utils.app_update_flag = 0;        //check app update one time while app is launch


        if (Utils.checkConnection(SplashScreenActivity.this)) {

            if (progressBar != null) {
                progressBar.setVisibility(View.VISIBLE);
            }
//            Intent serviceIntent = new Intent("com.android.vending.billing.InAppBillingService.BIND");
//            serviceIntent.setPackage("com.android.vending");
            if (isGooglePlayServicesAvailable(SplashScreenActivity.this)) {
                // service available to handle that Intent

                  checkPurchase();
            } else {
                // no service available to handle that Intent
          //      Utils.saveInt(mContext, mContext.getResources().getString(R.string.In_app_product_ads_id), 1);
                initRemoteConfig();
            }



        } else {

            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    performClick();
                }
            }, 700);

        }

    }

    private boolean isGooglePlayServicesAvailable(Context context) {
        GoogleApiAvailability googleApiAvailability = GoogleApiAvailability.getInstance();
        int resultCode = googleApiAvailability.isGooglePlayServicesAvailable(context);
        return resultCode == ConnectionResult.SUCCESS;
    }

    public void checkPurchase() {
        //check in app purchase
        InAppBillingManager inAppBillingManager = new InAppBillingManager(mContext, mContext.getResources().getString(R.string.In_app_license_key), null);
        inAppBillingManager.initInAppBilling(new InAppBillingManager.IInAppBillingInitializeListener() {
            @Override
            public void onInitializeSuccess() {
                Debugger.debugI(TAG, "------------onInitializeSuccess:------- ");
            }

            @Override
            public void onInitializePurchaseLoaded() {
                Debugger.debugI(TAG, "------------onPurchaseLoaded:------------- ");

                purchaseLoaded(mContext, inAppBillingManager);

            }

            @Override
            public void onInitializeFailed(InAppBillingManager.InAppBillingError errorCode, String error) {
                Debugger.debugI(TAG, "------------onInitializeFail------- ");

                //call remote config
                initRemoteConfig();
            }
        });

    }

    private void initRemoteConfig() {
        RemoteConfigLoadListener listener = SplashScreenActivity.this;
        FirebaseRemoteConfigUtils.getInstance().init(SplashScreenActivity.this, listener);
    }

    public void purchaseLoaded(Context mContext, InAppBillingManager inAppBillingManager) {
        if (inAppBillingManager.checkPurchased(mContext.getResources().getString(R.string.In_app_product_ads_id))) {
            Debugger.debugI(TAG, "Ads purchase - true: ");
            Utils.saveInt(mContext, mContext.getResources().getString(R.string.In_app_product_ads_id), 1);
        } else {
            Debugger.debugI(TAG, "Ads purchase - false: ");
            Utils.saveInt(mContext, mContext.getResources().getString(R.string.In_app_product_ads_id), 0);
        }

        if (inAppBillingManager.checkPurchased(Constant.SKU_PremiumRecording)) {
            Debugger.debugI(TAG, "record purchase - true: ");
            Utils.saveInt(mContext, Constant.SKU_PremiumRecording, 1);
            globals.setMaxRecordingTime(30);
        } else {
            Debugger.debugI(TAG, "record purchase - false: ");
            Utils.saveInt(mContext, Constant.SKU_PremiumRecording, 0);
            globals.setMaxRecordingTime(1);
        }

        //call remote config
        initRemoteConfig();
    }

    public void performClick() {
        Utils.afterSplashFlag = 1;
        Utils.flagSplash = 0;
        progressBar.setVisibility(View.GONE);
        performOpration(Constant.MM_SplashTime);
      //  Utils.saveInt(mContext, mContext.getResources().getString(R.string.In_app_product_ads_id), 1); // temporary
    }


    @Override
    public void onOpenAdLoaded() {

        Debugger.debugI(TAG, "OpenAd loaded");


        if (isAppOpenAdShow()) {

            Application application = getApplication();

            if ((!(application instanceof Globals))) {


                return;
            }
            progressBar.setVisibility(View.GONE);
            // Show the Open Ad
            runOnUiThread(new Runnable() {
                @Override
                public void run() {

                    OpenAdLoadListener openAdLoadListener = SplashScreenActivity.this;
                    ((Globals) application).showAdIfAvailable(SplashScreenActivity.this, new ShowOpenAdCompleteListener() {
                        @Override
                        public void onShowComplete() {

                            Utils.appOpenAdFlag = 1;


                            performClick();
                        }
                    });
                }
            });

        } else {
            progressBar.setVisibility(View.GONE);
            performClick();
        }

    }

    @Override
    public void onOpenAdFailed() {
        performClick();
    }

    private boolean isAppOpenAdShow() {

        if (Utils.checkConnection(SplashScreenActivity.this) &&
                FirebaseRemoteConfigUtils.getInstance().getAdOpenType() == Constant.AdOpenEnum.ADMOB.ordinal() &&
                Utils.getInt(SplashScreenActivity.this, getResources().getString(R.string.In_app_product_ads_id), 0) == 0) {
            Debugger.debugI(TAG, "true");
            return true;

        }
        Debugger.debugI(TAG, "false");
        return false;

    }

    @Override
    public void onRemoteConfigSuccessListener() {
        Debugger.debugI(TAG, "get remote config");

        if (isAppOpenAdShow()) {
            OpenAdLoadListener openAdLoadListener = SplashScreenActivity.this;
            AppOpenAdManager.getInstance().init(SplashScreenActivity.this, openAdLoadListener);

        } else {
            performClick();
        }

    }

    @Override
    public void onRemoteConfigFailListener() {
        performClick();
    }

    public void loadMainActivity() {

        Intent intent = new Intent(SplashScreenActivity.this, MainActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        SplashScreenActivity.this.finish();
    }

    public void performOpration(int mmSplashtime) {
        isInternetPresent = ConnectionDetector.isConnectingToInternet(getApplicationContext());
        new Handler().postDelayed(new Runnable() {
            public void run() {
                // check for Internet status
                if (isInternetPresent) {
                    if (globals.isNotificationON()) {
                        globals.setRequestPandding(true);
                        globals.GCMRegistrationRequest();
                    } else {
                        Debugger.debugI(TAG, "GCM Request not send");
                        globals.setRequestPandding(false);
                        globals.setGCM_DeviceToken(null);
                    }
                    Debugger.debugI(TAG, "load - splash - main - 1");
                    loadMainActivity();

                } else if (DBHelper.getDBHelper(SplashScreenActivity.this).getRecordingCount() > 0) {
                    Utils.showToast(SplashScreenActivity.this,Constant.MM_NO_INTERNET_RESPOND_MSG);
                    Debugger.debugI(TAG, "load - splash - main - 2");
                    loadMainActivity();
                } else {
                    Debugger.debugI(TAG, "load - splash - main - 3");
                    loadMainActivity();
                }
            }
        }, 200);
    }

    public void showTryAgain() {
        // Internet connection is not present
        ConnectionDetector.internetCheck(SplashScreenActivity.this);
        overlay_layout.setVisibility(View.VISIBLE);
    }


    public boolean canFit(int adWidth) {
        int adWidthPx = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, adWidth, getResources().getDisplayMetrics());
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        int deviceWidth = (metrics.heightPixels > metrics.widthPixels) ? metrics.widthPixels : metrics.heightPixels;
        return deviceWidth >= adWidthPx;
    }

    @Override
    public void onBackPressed() {
        this.finishAffinity();
        super.onBackPressed();
    }
}
package com.app.utility;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import android.content.Context;
import android.os.Environment;
import android.util.Log;
import android.widget.Toast;

import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.google.firebase.crashlytics.internal.model.CrashlyticsReport;


public class Debugger {
	
	public static File dir = null, logFile = null;
	
	public static boolean isDebugMode = true;
	public static boolean isFileDebugMode = false;
	
	public static void debugE(String Tag, String Text) {

		if(isDebugMode) {
			Log.e(Tag, Text + "");
			FirebaseCrashlytics crashlytics = FirebaseCrashlytics.getInstance();
			crashlytics.log(Text);
		}
		
		if(isFileDebugMode)
			addLogDetails(Tag +" :: "+Text+"\n");

	}

	public static void debugI(String Tag, String Text) {
		if (isDebugMode)
			Log.i(Tag, Text + "");
		
		if(isFileDebugMode)
			addLogDetails(Tag +" :: "+Text+"\n");
	}
	
	public static void debugD(String Tag, String Text) {
		if (isDebugMode)
			Log.d(Tag, Text + "");
		
		if(isFileDebugMode)
			addLogDetails(Tag +" :: "+Text+"\n");
	}
	
	public static File getDir() {
		if(dir == null){
			//Find the dir to save cached images
	        if (android.os.Environment.getExternalStorageState().equals(android.os.Environment.MEDIA_MOUNTED)) {
	        	dir = new File(android.os.Environment.getExternalStorageDirectory(), "Indian Radio");
		    
		        if(!dir.exists())
		        	dir.mkdirs();
	        }
		}
		return dir;
	}
	
	public static File getLogFile() {
		if(logFile == null) {
			if(getDir() != null) {
				logFile = new File(dir , "log.txt");
	
				if(!logFile.exists()) {
					try {
						logFile.createNewFile();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}
		return logFile;
	}

	public void generateLogOnSD(Context context, String sFileName, String sBody) {
		try {
			File root = new File(Environment.getExternalStorageDirectory(), "Indian Radio");
			if (!root.exists()) {
				root.mkdirs();
			}
			File gpxfile = new File(root, sFileName);
			FileWriter writer = new FileWriter(gpxfile);
			writer.append(sBody);
			writer.flush();
			writer.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void addLogDetails(String sBody) {
		try {
			if (getLogFile() != null) {
				FileWriter writer = new FileWriter(logFile, true);
				writer.append(sBody);
				writer.flush();
				writer.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

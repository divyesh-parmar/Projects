package com.app.recorded;

public class RecordedManager {

	public static int current_rID = -99;
	public static boolean isPlayingFlag = false;
	
	public static boolean isPlaying() {
		return isPlayingFlag;
	}

	public static void setIsPlayingFlag(boolean isPlayingFlag) {
		RecordedManager.isPlayingFlag = isPlayingFlag;
	}

	public static int getCurrent_rID() {
		return current_rID;
	}

	public static void setCurrent_rID(int current_rID) {
		RecordedManager.current_rID = current_rID;
	}
	
	public static void init() {
		current_rID = -99;
		isPlayingFlag = false;
	}
}

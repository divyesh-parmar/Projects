package com.app.http;

public class Utils {

    public static final String NO_RESPONSE = "error_in_response";

    public static String callGet(String urlString) {

//        HttpParams params = new BasicHttpParams();
//        HttpConnectionParams.setSoTimeout(params, 30000);
//        HttpConnectionParams.setConnectionTimeout(params, 30000);
//        HttpClient httpclient = new DefaultHttpClient(params);
//        HttpPost httppost = new HttpPost(urlString);

        try {
//            HttpResponse response = httpclient.execute(httppost);
//            return EntityUtils.toString(response.getEntity());

            return "";
        } catch (Exception e) {
            e.printStackTrace();
            return NO_RESPONSE;
        }
    }

    /**
     * A method to download json data from url
     */
//    public static String downloadfromUrl(String strUrl) throws IOException{
//            String data = "";
//            InputStream iStream = null;
//            try {
//                URL url = new URL(strUrl);
//                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
//                urlConnection.setConnectTimeout(10000);
//                urlConnection.setReadTimeout(20000);
//                urlConnection.connect();
//
//                try {
//                    iStream = urlConnection.getInputStream();
//                    BufferedReader br = new BufferedReader(new InputStreamReader(iStream, "UTF-8"));
//                    StringBuffer sb  = new StringBuffer();
//
//                    String line = "";
//                    while( ( line = br.readLine())  != null) {
//                        sb.append(line);
//                    }
//                    data = sb.toString();
//                    br.close();
//
//                } catch (Exception e) {
//                    e.printStackTrace();
//                    return NO_RESPONSE;
//                }
//            } catch(Exception e) {
//                data = NO_RESPONSE;
//                Log.d("Exceptionurl", e.toString());
//
//            } finally {
//                iStream.close();
//            }
//            return data;
//    }
//
//    // Send data using RowPost
//    public static final String MIME_FORM_ENCODED = "application/x-www-form-urlencoded";
//    private static DefaultHttpClient client;
//    private static final String GZIP = "gzip";
//    private static final String CONTENT_TYPE = "Content-Type";
//    private static final String ACCEPT_ENCODING = "Accept-Encoding";
//    public static final String HTTP_RESPONSE = "HTTP_RESPONSE";
//    public static final String HTTP_RESPONSE_ERROR = "HTTP_RESPONSE_ERROR";
//
//    private final static ResponseHandler<String> responseHandler = new BasicResponseHandler();
    public static String performRawPost(final String url, final String data) {
        return performRawPostRequest(url, data);
    }

    private static String performRawPostRequest(String url, final String data) {
        String responseStr = null;
//        OkHttpClient client = new OkHttpClient();
//
//        try {
//            Response response = client.newCall(new Request.Builder()
//                    .url(url)
//                    .build()).execute();
//            responseStr = response.body().string();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }





//        HttpParams params = new BasicHttpParams();
//
//            params.setParameter(CoreProtocolPNames.PROTOCOL_VERSION, HttpVersion.HTTP_1_1);
//            params.setParameter(CoreProtocolPNames.HTTP_CONTENT_CHARSET, HTTP.DEFAULT_CONTENT_CHARSET);
//            params.setParameter(CoreProtocolPNames.USER_AGENT, "Apache-HttpClient/Android");
//            params.setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, 15000);
//            params.setParameter(CoreConnectionPNames.STALE_CONNECTION_CHECK, false);
//            /*SchemeRegistry schemeRegistry = new SchemeRegistry();
//            schemeRegistry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), 80));
//
//            //schemeRegistry.register(new Scheme("https", new FakeSocketFactory(), 443));
//            ThreadSafeClientConnManager cm = new ThreadSafeClientConnManager(params, schemeRegistry);*/
//
//            //client = new DefaultHttpClient(cm, params);
//        client = new DefaultHttpClient(params);
//
//            // add gzip decompressor to handle gzipped content in responses
//            // (default we *do* always send accept encoding gzip header in request)
//            // Log.d("HTTPHandler", "DefaultHttpClient");
//
//            client.addResponseInterceptor(new HttpResponseInterceptor() {
//                public void process(final HttpResponse response, final HttpContext context) throws HttpException, IOException {
//                    HttpEntity entity = response.getEntity();
//                    Header contentEncodingHeader = entity.getContentEncoding();
//                    if (contentEncodingHeader != null) {
//                        HeaderElement[] codecs = contentEncodingHeader.getElements();
//                        for (int i = 0; i < codecs.length; i++) {
//                            if (codecs[i].getName().equalsIgnoreCase(GZIP)) {
//                                response.setEntity(new GzipDecompressingEntity(response.getEntity()));
//                                return;
//                            }
//                        }
//                    }
//                }
//            });
//
//            // process headers using request interceptor
//            final Map<String, String> sendHeaders = new HashMap<>();
//            // add encoding header for gzip if not present
//            if (!sendHeaders.containsKey(ACCEPT_ENCODING)) {
//                sendHeaders.put(ACCEPT_ENCODING, GZIP);
//            }
////		/*
////		 * if(data.length() > 0) { sendHeaders.put("Content-Length",
////		 * data.length()); }
////		 */
//
//            sendHeaders.put(CONTENT_TYPE, contentType);
//            if (sendHeaders.size() > 0) {
//                client.addRequestInterceptor(new HttpRequestInterceptor() {
//                    public void process(final HttpRequest request, final HttpContext context) throws HttpException, IOException {
//                        for (String key : sendHeaders.keySet()) {
//                            if (!request.containsHeader(key)) {
//                                request.addHeader(key, sendHeaders.get(key));
//                            }
//                        }
//                    }
//                });
//            }
//
//            // handle POST or GET request respectively
//            HttpPost method = new HttpPost(url);
//            try {
//                StringEntity entity = new StringEntity(data);
//                method.setEntity(entity);
//            } catch (UnsupportedEncodingException e) {
//                // throw new RuntimeException("Error peforming HTTP request: " +
//                // e.getMessage(), e);
//                throw new RuntimeException(NO_RESPONSE, e);
//            }
//
//            // execute request
//            return execute(method);
        return responseStr;
    }

//    private synchronized static String execute(final HttpRequestBase method) {
//            String response = null;
//            // execute method returns?!? (rather than async) - do it here sync, and
//            // wrap async elsewhere
//            try {
//                response = client.execute(method, responseHandler);
//            } catch (ClientProtocolException e) {
//                // response = HTTP_RESPONSE_ERROR + " - " +
//                // e.getClass().getSimpleName() + " " + e.getMessage();
//                response = NO_RESPONSE;
//            } catch (IOException e) {
//                // response = HTTP_RESPONSE_ERROR + " - " +
//                // e.getClass().getSimpleName() + " " + e.getMessage();
//                response = NO_RESPONSE;
//            }
//            return response;
//    }
//
//    static class GzipDecompressingEntity extends HttpEntityWrapper {
//            public GzipDecompressingEntity(final HttpEntity entity) {
//                super(entity);
//            }
//
//            @Override
//            public InputStream getContent() throws IOException,
//                    IllegalStateException {
//                // the wrapped entity's getContent() decides about repeatability
//                InputStream wrappedin = wrappedEntity.getContent();
//                return new GZIPInputStream(wrappedin);
//            }
//
//            @Override
//            public long getContentLength() {
//                // length of ungzipped content is not known
//                return -1;
//            }
//    }
//

}
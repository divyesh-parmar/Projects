package com.app.ads;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.app.firebase.FirebaseRemoteConfigUtils;
import com.app.utility.Constant;
import com.app.utility.Debugger;
import com.app.utility.Utils;
//import com.google.android.ads.nativetemplates.NativeTemplateStyle;
//import com.google.android.ads.nativetemplates.TemplateView;
import com.google.android.ads.nativetemplates.NativeTemplateStyle;
import com.google.android.ads.nativetemplates.TemplateView;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.nativead.NativeAd;
import com.indianradio.R;

public class NativeAdsUtils {

    private static NativeAdsUtils nativeInstance;
    public String TAG = getClass().getSimpleName();
    View nativeView;

    public static NativeAdsUtils getInstance() {
        if (nativeInstance == null) {
            nativeInstance = new NativeAdsUtils();

        }

        return nativeInstance;
    }

    public void loadNative(Context context, TemplateView template) {


        if (Utils.checkConnection(context)) {
            Debugger.debugI("Native", "---------check internet------------");
            if (Utils.getInt(context, context.getResources().getString(R.string.In_app_product_ads_id), 0) == 0) {
                Debugger.debugI("Native", "---------check purchase------------");
                if (FirebaseRemoteConfigUtils.getInstance().getNativeType() == Constant.NativeEnum.ADMOB.ordinal()) {
                    Debugger.debugI("Native", "---------check Native remote config------------");

                    AdLoader adLoader = new AdLoader.Builder(context, FirebaseRemoteConfigUtils.getInstance().getAdmobNativeAdID())
                            .forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
                                @Override
                                public void onNativeAdLoaded(NativeAd nativeAd) {

                                    NativeTemplateStyle styles = new
                                            NativeTemplateStyle.Builder().withMainBackgroundColor(new ColorDrawable(Color.BLACK)).build();

                                    // template.setStyles(styles);
                                    template.setNativeAd(nativeAd);
                                    template.setVisibility(View.VISIBLE);

                                }
                            })
                            .build();

                    adLoader.loadAd(new AdRequest.Builder().build());
                }else {
                    template.setVisibility(View.GONE);
                }
            } else {
                template.setVisibility(View.INVISIBLE);
            }
        } else {

            template.setVisibility(View.INVISIBLE);

        }

    }

    // load native to templateView
    public View requestNative(Context context, LinearLayout nativeLayout) {
        nativeView = LayoutInflater.from(context).inflate(R.layout.custom_template, nativeLayout, false);
        TemplateView template = nativeView.findViewById(R.id.template);
        loadNative(context, template);
        return nativeView;
    }

    // add templateView to destination layout
    public void showNative(Context context, LinearLayout nativeLayout) {
        if (nativeView != null) {
            // if templateView already added in other view than remove View first
            ViewGroup parent = (ViewGroup) nativeView.getParent();
            if (parent != null) {
                parent.removeView(nativeView);
            }
            nativeLayout.addView(nativeView);
        } else {
            nativeLayout.addView(requestNative(context, nativeLayout));
        }
    }

    public void removeAdView() {
        nativeView = null;
    }

}

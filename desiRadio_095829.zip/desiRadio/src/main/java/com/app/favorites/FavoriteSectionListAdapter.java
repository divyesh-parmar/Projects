package com.app.favorites;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.section.listview.AmazingAdapter;
import com.app.parser.Channel;
import com.app.player.PlaylistManager;
import com.indianradio.R;

public class FavoriteSectionListAdapter extends AmazingAdapter {
    ArrayList<Pair<String, ArrayList<Channel>>> data;
    private Context _activity;
    private static LayoutInflater inflater = null;

    public FavoriteSectionListAdapter(Context activity, ArrayList<Pair<String, ArrayList<Channel>>> arrayList) {
        _activity = activity;
        inflater = (LayoutInflater) _activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        data = arrayList;
    }

    public void RefreshList(ArrayList<Pair<String, ArrayList<Channel>>> arrayList) {
        data = arrayList;
        this.notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        int res = 0;
        for (int i = 0; i < data.size(); i++) {
            res += data.get(i).second.size();
        }
        return res;
    }

    @Override
    public Channel getItem(int position) {
        int c = 0;
        for (int i = 0; i < data.size(); i++) {
            if (position >= c && position < c + data.get(i).second.size()) {
                return data.get(i).second.get(position - c);
            }
            c += data.get(i).second.size();
        }
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    protected void onNextPageRequested(int page) {
    }

    @Override
    protected void bindSectionHeader(View view, int position, boolean displaySectionHeader) {
        if (displaySectionHeader) {
            view.findViewById(R.id.header).setVisibility(View.VISIBLE);
            TextView lSectionTitle = (TextView) view.findViewById(R.id.header);
            lSectionTitle.setText(getSections()[getSectionForPosition(position)]);
        } else {
            view.findViewById(R.id.header).setVisibility(View.GONE);
        }
    }

    @Override
    public View getAmazingView(int position, View convertView, ViewGroup parent) {
        View res = convertView;
        if (res == null)
            res = inflater.inflate(R.layout.favorite_item, null);

        TextView title = (TextView) res.findViewById(R.id.txt_channel_name);
        TextView desc = (TextView) res.findViewById(R.id.txt_channel_desc);
        TextView biteRate = (TextView) res.findViewById(R.id.txt_byte);
        ImageView listen_icon = (ImageView) res.findViewById(R.id.listen_icon);

        Channel channel = getItem(position);
        title.setText(channel.ChannelTitle);
        desc.setText(channel.ChannelDescription);

        if (channel.ChannelByte != null && channel.ChannelByte.toString().trim().length() > 0) {
            biteRate.setVisibility(View.VISIBLE);
            biteRate.setText(channel.ChannelByte + "K");
        } else {
            biteRate.setVisibility(View.GONE);
        }

        listen_icon.setImageResource(R.drawable.headphones);
        if (PlaylistManager.isPlaying() && PlaylistManager.isStationPlaying(channel)) {
            listen_icon.setImageResource(R.drawable.headphones_blue);
        }

        title.setTag(channel.ChannelId);
        desc.setTag(channel.ChannelLink);

        return res;
    }

    @Override
    public void configurePinnedHeader(View header, int position, int alpha) {
        TextView lSectionHeader = (TextView) header;
        lSectionHeader.setText(getSections()[getSectionForPosition(position)]);
        lSectionHeader.setBackgroundColor(alpha << 24 | (0xbfccd9));
        lSectionHeader.setTextColor(alpha << 24 | (0xffffff));
    }

    @Override
    public int getPositionForSection(int section) {
        if (section < 0)
            section = 0;
        if (section >= data.size())
            section = data.size() - 1;
        int c = 0;
        for (int i = 0; i < data.size(); i++) {
            if (section == i) {
                return c;
            }
            c += data.get(i).second.size();
        }
        return 0;
    }

    @Override
    public int getSectionForPosition(int position) {
        int c = 0;
        for (int i = 0; i < data.size(); i++) {
            if (position >= c && position < c + data.get(i).second.size()) {
                return i;
            }
            c += data.get(i).second.size();
        }
        return -1;
    }

    @Override
    public String[] getSections() {
        String[] res = new String[data.size()];
        for (int i = 0; i < data.size(); i++) {
            res[i] = data.get(i).first;
        }
        return res;
    }

}
package com.app.ads.interfaces;

// interface for a callback to be invoked when app open ad complete (dismiss or fail to show)
public interface ShowOpenAdCompleteListener {
    void onShowComplete();
}
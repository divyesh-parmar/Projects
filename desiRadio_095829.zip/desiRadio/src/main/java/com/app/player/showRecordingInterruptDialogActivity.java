package com.app.player;

import android.app.Activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.app.utility.Constant;
import com.app.utility.Debugger;
import com.indianradio.R;

public class showRecordingInterruptDialogActivity extends AppCompatActivity {

	AlertDialog alert;
	Bundle bundleData;
	boolean isGrantedStop = false;
	
	String TAG;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		TAG = getClass().getName();
		bundleData = getIntent().getExtras();
		
		AlertDialog.Builder builder = new AlertDialog.Builder(this);

		builder.setCancelable(false);
		
		builder.setIcon(R.mipmap.ic_launcher);
		builder.setTitle(getString(R.string.app_name));
		builder.setMessage(Constant.MM_RECORDING_INTERRUPT_ALERT);
		
		builder.setPositiveButton("YES",
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						isGrantedStop = true;
						returnResult();
					}
				});

		builder.setNegativeButton("NO",
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						isGrantedStop = false;
						returnResult();
					}
				});

		alert = builder.create();
		alert.show();
	}
	
	private void returnResult() {
		Debugger.debugI(TAG, "sending result back to calling activity");
		Intent returnIntent = new Intent();
		if(isGrantedStop) {
			returnIntent.putExtras(bundleData);
			setResult(RESULT_OK, returnIntent);
		} else {
			setResult(RESULT_CANCELED, returnIntent);
		}
		finish();
	}
}
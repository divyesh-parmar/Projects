package com.app.ads;

import static com.app.utility.Constant.interstitialsAdsFailDelay;

import android.app.Activity;

import androidx.annotation.NonNull;

import com.app.ads.interfaces.InterstitialDismissListener;
import com.app.firebase.FirebaseRemoteConfigUtils;
import com.app.utility.Debugger;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;


public class InterstitialUtils {

    public InterstitialAd interstitialAd;
    int buttonID;
    Activity act;
    AdRequest adRequest;
    InterstitialDismissListener listener;
    public String TAG = getClass().getSimpleName();

    //singleton variables
    private static InterstitialUtils interstitialInstance;
    AdRequest adRequest_new;
    int id;
    Activity activity;
    private long loadTime = 0;

    public static InterstitialUtils getInstance() {
        if (interstitialInstance == null) {
            interstitialInstance = new InterstitialUtils();
        }
        return interstitialInstance;
    }

    public void initAdRequest(Activity activity) {

        act = activity;

        if (adRequest == null) {
            adRequest = new AdRequest.Builder().build();
            setReq(adRequest);
        }

        startTimer(FirebaseRemoteConfigUtils.getInstance().getInterstitialInterval());

    }

    Timer mTimer;

    public void startTimer(int seconds) {

        mTimer = new Timer();

        mTimer.schedule(new TimerTask() {
            @Override
            public void run() {

                loadAds();

            }
        }, (long) seconds * 1000);
    }

    private void showAds(Activity activity) {

        act = activity;

        if (interstitialAd != null) {

            interstitialAd.show(act);

        } else {

            // user click while ad not loaded
            Activity activity1 = getAct();
            int id1 = getId();

            listener.onInterstitialDismissListener(activity1, id1);

        }
    }

    private boolean wasLoadTimeLessThanHourAgo(long numHour) {
        long dateDifference = (new Date()).getTime() - loadTime;
        long numMilliSecondPerHour = 36806808;
        return (dateDifference < numMilliSecondPerHour);

    }

    public void loadAds() {

        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                InterstitialAd.load(act, FirebaseRemoteConfigUtils.getInstance().getAdmobInterstitialID(), adRequest,
                        new InterstitialAdLoadCallback() {
                            @Override
                            public void onAdLoaded(@NonNull InterstitialAd interstitialAd1) {
                                // The mInterstitialAd reference will be null until
                                // an ad is loaded.
                                Debugger.debugI(TAG, "onAdLoaded");
                                loadTime = (new Date()).getTime();
                                interstitialAd = interstitialAd1;

                                interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {

                                    @Override
                                    public void onAdDismissedFullScreenContent() {
                                        // Called when fullscreen content is dismissed.
                                        Debugger.debugI(TAG, "The ad was dismissed.");

                                        interstitialAd = null;

                                        try {

//                                    Activity activity = getAct();
                                            int id = getId();
//                                    listener = (InterstitialDismissListener) getAct();

                                            // Dismiss click of ads
                                            listener.onInterstitialDismissListener(activity, id);
                                        } catch (Exception ee) {
                                            Debugger.debugI(TAG, "onAdDismissedFullScreenContent: " + ee.getMessage());
                                        }

                                        // reload the ad after some time (10 sec) of waiting

                                        startTimer(FirebaseRemoteConfigUtils.getInstance().getInterstitialInterval());

                                    }

                                    @Override
                                    public void onAdFailedToShowFullScreenContent(AdError adError) {
                                        // Called when fullscreen content failed to show.
                                        Debugger.debugI(TAG, "The ad failed to show.");
                                    }

                                    @Override
                                    public void onAdShowedFullScreenContent() {
                                        // Called when fullscreen content is shown.
                                        // Make sure to set your reference to null so you don't
                                        // show it a second time.

                                        Debugger.debugI(TAG, "The ad was shown.");
                                    }
                                });


                            }

                            @Override
                            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                                // Handle the error
                                Debugger.debugI(TAG, "--" + loadAdError.getMessage());

                                interstitialAd = null;

                                // reload the ad after some time (e.g.,10 sec) of waiting if Ad failed to load
                                startTimer(interstitialsAdsFailDelay);

                            }
                        });
            }
        });

    }

    private boolean isAdAvailable() {

        return interstitialAd != null && wasLoadTimeLessThanHourAgo(1);
    }

    public void removeAd() {
        if (mTimer != null) {
            mTimer.cancel();
            mTimer = null;
        }
        interstitialAd = null;
    }

    public void setData(Activity activity, InterstitialDismissListener interstitialDismissListener, int ButtonId) {

        buttonID = ButtonId;
        listener = interstitialDismissListener;
        act = activity;

        setAct(act);
        setId(buttonID);
    }


    public void displayInterstitialAd(Activity activity, InterstitialDismissListener interstitialDismissListener, int ButtonId) {
        setData(activity, interstitialDismissListener, ButtonId);
        if (isAdAvailable()) {
            showAds(activity);
        }
    }

    public void setReq(AdRequest adRequest1) {
        this.adRequest_new = adRequest1;
    }

    public AdRequest getReq() {
        return adRequest_new;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setAct(Activity activity1) {
        this.activity = activity1;
    }

    public Activity getAct() {
        return activity;
    }

}

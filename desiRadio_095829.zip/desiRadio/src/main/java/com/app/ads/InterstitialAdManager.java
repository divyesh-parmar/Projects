package com.app.ads;

import android.app.Activity;
import android.content.Context;

import com.app.firebase.FirebaseRemoteConfigUtils;
import com.app.utility.Constant;
import com.app.utility.Utils;
import com.indianradio.R;


public class InterstitialAdManager {

    private static InterstitialAdManager interstitialAdManagerInstance;

    public static InterstitialAdManager getInstance() {

        if (interstitialAdManagerInstance == null) {
            interstitialAdManagerInstance = new InterstitialAdManager();
        }
        return interstitialAdManagerInstance;
    }

    public boolean showInterstitial(Context context) {

        if (Utils.checkConnection(context) && Utils.getInt(context, context.getResources().getString(R.string.In_app_product_ads_id), 0) == 0) {

            if (FirebaseRemoteConfigUtils.getInstance().getInterstitialType() == Constant.InterstitialEnum.ADMOB.ordinal()) {
                return true;
            }

        }

        return false;
    }

    public void init(Context context){
        Utils.checkInterstitialIsInit = 1;
        if (Utils.checkConnection(context) && Utils.getInt(context, context.getResources().getString(R.string.In_app_product_ads_id), 0) == 0) {

            if (FirebaseRemoteConfigUtils.getInstance().getInterstitialType() == Constant.InterstitialEnum.ADMOB.ordinal()) {
                InterstitialUtils.getInstance().initAdRequest((Activity) context);
            }

        }
    }
}

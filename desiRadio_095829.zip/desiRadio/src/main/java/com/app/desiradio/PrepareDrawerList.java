package com.app.desiradio;

import android.content.Context;

import java.util.ArrayList;

import com.android.drawerlistview.EntryItem;
import com.android.drawerlistview.Item;
import com.android.drawerlistview.Item.Group;
import com.android.drawerlistview.SectionItem;
import com.app.utility.Constant;
import com.app.utility.Globals;
import com.app.utility.Utils;
import com.indianradio.R;

public class PrepareDrawerList {

    ArrayList<Item> items = new ArrayList<Item>();
    int mainEntry = 0, moreEntry = 0;

    public static final String dw_section_main = "Main";
    public static final String dw_section_more = "more";

    public static final String dw_entry_Genre = "Genre";
    public static final String dw_entry_Search = "Search";
    public static final String dw_entry_Favorites = "Favorites";
    public static final String dw_entry_Video = "Videos";
    public static final String dw_entry_Recorded = "Recorded";
    public static final String dw_entry_Add_Station = "Add Own Station";
    public static final String dw_entry_History = "History";

    public static final String dw_entry_RemoveAds = "Remove Ads";
    public static final String dw_entry_Upgrade_Recording = "Upgrade for Recording";
    public static String dw_entry_theme = "Theme";
    public static final String dw_entry_MoreApps = "More Apps";
    public static final String dw_entry_AboutUs = "About Us";
    public static final String dw_entry_ContactUs = "Contact Us";
    public static final String dw_entry_TellAFriends = "Tell a Friends";
    public static final String dw_entry_RateUs = "Rate Us";
    public static final String dw_entry_PrivacyPolicy = "Privacy Policy";

//	public static final String dw_entry_Notification = "Notification";

    public ArrayList<Item> getDrawerList(Context context, Globals globals) {

        items = new ArrayList<Item>();
        items.clear();

        //Group Main
        items.add(new SectionItem(dw_section_main));
        items.add(new EntryItem(dw_entry_Genre, Group.Main, R.drawable.ic_genre, R.drawable.ic_genre));
        items.add(new EntryItem(dw_entry_Search, Group.Main, R.drawable.ic_search, R.drawable.ic_search));
        items.add(new EntryItem(dw_entry_Favorites, Group.Main, R.drawable.ic_favourite, R.drawable.ic_favourite));
        items.add(new EntryItem(dw_entry_Video, Group.Main, R.drawable.ic_record, R.drawable.ic_record));

        if (Constant.RECORDING_FLAG == 1) {
            items.add(new EntryItem(dw_entry_Recorded, Group.Main, R.drawable.ic_microphone, R.drawable.ic_microphone));
        }
        items.add(new EntryItem(dw_entry_Add_Station, Group.Main, R.drawable.ic_adds, R.drawable.ic_adds));
        items.add(new EntryItem(dw_entry_History, Group.Main, R.drawable.ic_history, R.drawable.ic_history));

        //Group More
        items.add(new SectionItem(dw_section_more));
        items.add(new EntryItem(dw_entry_theme, Group.More, R.drawable.ic_day_night, R.drawable.ic_day_night));
        if (Utils.getInt(context, context.getResources().getString(R.string.In_app_product_ads_id), 0) == 0) {
            items.add(new EntryItem(dw_entry_RemoveAds, Group.More, R.drawable.remove_ads, R.drawable.remove_ads));
        }
        if (globals.getMaxRecordingTime() == 1) {
            if (Constant.RECORDING_FLAG == 1) {
                items.add(new EntryItem(dw_entry_Upgrade_Recording, Group.More, R.drawable.img_recording_upgrade, R.drawable.img_recording_upgrade));
            }
        }
        items.add(new EntryItem(dw_entry_MoreApps, Group.More, R.drawable.img_more_apps, R.drawable.img_more_apps));
        items.add(new EntryItem(dw_entry_AboutUs, Group.More, R.drawable.dw_about_us, R.drawable.dw_about_us));
        items.add(new EntryItem(dw_entry_ContactUs, Group.More, R.drawable.dw_contact_us, R.drawable.dw_contact_us));
        items.add(new EntryItem(dw_entry_TellAFriends, Group.More, R.drawable.ic_share, R.drawable.ic_share));
        items.add(new EntryItem(dw_entry_RateUs, Group.More, R.drawable.img_review, R.drawable.img_review));
        items.add(new EntryItem(dw_entry_PrivacyPolicy, Group.More, R.drawable.ic_pp, R.drawable.ic_pp));
        //Group Notification
        //items.add(new EntryItem(dw_entry_Notification, Group.Notification, R.drawable.notification_normal, R.drawable.notification_normal));

        setEntryCount();
        return items;
    }

    public Item getItem(int position) {
        return items.get(position);
    }

    public void setEntryCount() {
        int count = items.size();
        for (int i = 0; i < count; i++) {
            if (!items.get(i).isSection()) {
                EntryItem eItem = (EntryItem) items.get(i);
                switch (eItem.group) {
                    case Main:
                        mainEntry++;
                        break;
                    case More:
                        moreEntry++;
                        break;
                    default:
                        break;
                }
            }
        }
    }

    public int getMainItems() {
        return mainEntry;
    }

    public int getMoreItems() {
        return moreEntry;
    }
}

package com.app.recorded;

import static com.app.player.RadioPlayerActivity.mIsPlaying;
import static com.app.utility.Utils.checkPlayerIsPlay;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewSwitcher;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.GoogleAnalytics.Analytics;
import com.android.GoogleAnalytics.AnalyticsConstant;
import com.android.Utility.Classes.ExpandCollapseAnimation;
import com.android.youtube.YoutubeListActivity;
import com.app.auto.RMusicService;
import com.app.desiradio.MainActivity;
import com.app.desiradio.PrepareDrawerList;
import com.app.player.PlaylistManager;
import com.app.player.showRecordingInterruptDialogActivity;
import com.app.sqlite.DBHelper;
import com.app.sqlite.Recording;
import com.app.utility.Constant;
import com.app.utility.Debugger;
import com.app.utility.Globals;
import com.app.utility.Utils;
import com.indianradio.R;

import java.io.File;
import java.util.List;

public class RecordedFragment extends Fragment implements OnClickListener {

    Globals globals;
    Menu mOptionsMenu;
    MenuInflater mMenuInflater;

    LinearLayout contentLayout;

    //    ListView rList;
    RecyclerView rvRecords;
    List<Recording> tempList;
    public RecordingRAdapter rAdapter;

    ViewSwitcher switcher;
    public static LinearLayout seekLayout,listContainer;
    static TextView tv_duration;
    static SeekBar player_seek;
    static ImageView btn_play_pause;

    static boolean isVisible;
    int requestCode = 0;

    private View view;

    String TAG;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TAG = getClass().getName();
        globals = ((Globals) getActivity().getApplicationContext());
        setHasOptionsMenu(false);

        rAdapter = new RecordingRAdapter(getActivity(), new OnItemRecordLongClickListener() {
            @Override
            public void onItemClicker(View view, int position) {
                int rID = Integer.parseInt(((TextView) view.findViewById(R.id.tv_rName)).getTag().toString());
                Debugger.debugI(TAG, "Recording ID : " + rID);

                if (PlaylistManager.isRecording()) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("actionID", Constant.MM_ActionID_PlayRecorded);
                    bundle.putInt("rID", rID);
                    openInterruptActivity(bundle);
                } else {
                    onRecordedItemClick(rID);
                }
                Intent recordedService = new Intent(getActivity(), RecordedPlayerService.class);
                getActivity().startService(recordedService);
            }

            @Override
            public void onItemLongClick(View view, int position) {

                int id = Integer.parseInt(((TextView) view.findViewById(R.id.tv_rName)).getTag().toString());
                Debugger.debugI(TAG, "Recording ID : " + id);
                showCustomMessage(getString(R.string.app_name), Constant.MM_MSG_DELETE_RECORDED_ITME, id);

            }
        });

    }

    @Override
    public void onResume() {
        super.onResume();
        Debugger.debugI(TAG, "on resume called");
        isVisible = true;
        globals.radioServiceActivity = getActivity();

    }

    @Override
    public void onPause() {
        super.onPause();
        isVisible = false;

    }

    public void loadSwitcherView() {

        tempList = DBHelper.getDBHelper(getActivity()).getAllRecordings();
        if (tempList.size() > 0) {
            switcher.setDisplayedChild(1);
            setRecordedAdapter();
        } else {
            switcher.setDisplayedChild(0);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        if (RecordedManager.getCurrent_rID() == -99) {
            if (RecordedPlayerService.rPlayer != null && !RecordedPlayerService.rPlayer.isPlaying()) {

                getActivity().stopService(new Intent(getActivity(), RecordedPlayerService.class));
            }
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.recorded_layout, container, false);

        ((MainActivity) getActivity()).actionbar.setTitle(PrepareDrawerList.dw_entry_Recorded);

        rvRecords = view.findViewById(R.id.rv_records);
        rvRecords.setLayoutManager(new GridLayoutManager(getActivity(), 1));
//	    rList = (ListView)view.findViewById(R.id.RecordListView);
//	    rList.setOnItemClickListener(this);
//	    rList.setOnItemLongClickListener(this);

        switcher = (ViewSwitcher) view.findViewById(R.id.playlistSwitcher);
        seekLayout = (LinearLayout) view.findViewById(R.id.seekLayout);
        listContainer = (LinearLayout) view.findViewById(R.id.listContainer);

        tv_duration = (TextView) view.findViewById(R.id.tv_duration);
        player_seek = (SeekBar) view.findViewById(R.id.player_seek);

        btn_play_pause = (ImageView) view.findViewById(R.id.btn_play_pause);
        btn_play_pause.setOnClickListener(this);

        //Ads
        contentLayout = (LinearLayout) view.findViewById(R.id.contentLayout);

        loadSwitcherView();
        updateUI();
      //  invalidOptionsMenuHelper();

        return view;
    }

    public void invalidOptionsMenuHelper() {
        if (mOptionsMenu != null && mMenuInflater != null) {
            mOptionsMenu.clear();
            onCreateOptionsMenu(mOptionsMenu, mMenuInflater);
        }
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        mOptionsMenu = menu;
        mMenuInflater = inflater;
//        inflater.inflate(R.menu.now_playing_menu, menu);
//
//        if (!RecordedManager.isPlaying() && Constant.mStationArrayList != null && Constant.mStationArrayList.size() > 0) {
//            menu.findItem(R.id.now_playing).setVisible(true);
//        } else {
//            menu.findItem(R.id.now_playing).setVisible(false);
//        }

        super.onCreateOptionsMenu(menu, inflater);
    }

    public static void PreparePlayer(final Context ActivityContext) {
        if (RecordedManager.getCurrent_rID() != -99) {
            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (RecordedPlayerService.rPlayer != null) {
                            RecordedPlayerService.rPlayer.stop();
                            RecordedPlayerService.playSong();
                        }
                    } catch (IllegalStateException e) {
                        e.printStackTrace();
                    }
                }
            }, 200);
        } else {
            Utils.showToast(ActivityContext, "Select Recording to play");
        }
    }

    public void setRecordedAdapter() {
        rAdapter.updateResults(getActivity(), tempList);
        if (rvRecords.getAdapter() == null)
            rvRecords.setAdapter(rAdapter);
    }

    ActivityResultLauncher<Intent> someActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        // There are no request codes
                        Intent data = result.getData();
                        if (data.getIntExtra("actionID", 0) == Constant.MM_ActionID_PlayRecorded) {
                            if (data.getIntExtra("rID", -99) != -99) {
                                onRecordedItemClick(data.getIntExtra("rID", -99));

                            }
                        }
                    }
                }
            });


    public void openInterruptActivity(Bundle bundle) {
        // Start the activity whose result we want to retrieve.  The
        // result will come back with request code GET_CODE.
        Intent intent = new Intent(getActivity(), showRecordingInterruptDialogActivity.class);
        intent.putExtras(bundle);
        //  startActivityForResult(intent, requestCode);
        someActivityResultLauncher.launch(intent);
    }

    private void onRecordedItemClick(int rID) {

      //  if (checkPlayerIsPlay == 1) {
            globals.radioServiceActivity = getActivity();
            RMusicService.stopStation(getActivity());
//            if (RMusicService.mPlayback != null ){
//                RMusicService.mPlayback.stop();
//            }


            checkPlayerIsPlay = 1;
            mIsPlaying = false;
            if (RMusicService.mPlayback != null)
                RMusicService.mPlayback.stop();
            if (MainActivity.loaderLay != null)
                MainActivity.loaderLay.setVisibility(View.GONE);

      //  }

        if (RecordedManager.getCurrent_rID() != rID) {
            RecordedManager.setCurrent_rID(rID);
            RecordedManager.setIsPlayingFlag(true);
            PreparePlayer(getActivity());
        }

        updatePlayerVisibility(0);
        rAdapter.notifyDataSetChanged();
       // invalidOptionsMenuHelper();
    }

    public void updateUI() {
        setPlayerState();
        setPlayBtnState();
    }

    public void updatePlayerVisibility(int animType) {
        ExpandCollapseAnimation animation;
        switch (animType) {
            case 0:
                if (seekLayout.getVisibility() != View.VISIBLE) {
                    seekLayout.setVisibility(View.GONE);
                    animation = new ExpandCollapseAnimation(seekLayout, 500, 0, seekLayout.getLayoutParams().height);
                    listContainer.startAnimation(animation);
                }
                break;

            case 1:
                if (seekLayout.getVisibility() == View.VISIBLE) {
                    seekLayout.setVisibility(View.VISIBLE);
                    animation = new ExpandCollapseAnimation(seekLayout, 500, 1, seekLayout.getLayoutParams().height);
                    listContainer.startAnimation(animation);
                }
                break;
        }
    }

    public void setPlayerState() {
        if (RecordedManager.getCurrent_rID() == -99) {
            seekLayout.setVisibility(View.GONE);
        } else {
            seekLayout.setVisibility(View.VISIBLE);
        }
    }

    public void setPlayBtnState() {
        if (RecordedManager.isPlaying()) {
            btn_play_pause.setImageResource(R.drawable.btn_pause);
            player_seek.setEnabled(true);
        } else {
            btn_play_pause.setImageResource(R.drawable.btn_play);
            player_seek.setEnabled(false);
            initiatePlayerComps();
        }
    }

    public void initiatePlayerComps() {
        player_seek.setProgress(0);
        tv_duration.setText("0:00");
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_play_pause:


                checkPlayerIsPlay = 1;
                mIsPlaying = false;
                if (RMusicService.mPlayback != null)
                    RMusicService.mPlayback.stop();
                if (MainActivity.loaderLay != null)
                    MainActivity.loaderLay.setVisibility(View.GONE);


                if (RecordedPlayerService.rPlayer != null) {
                    if (RecordedPlayerService.rPlayer.getCurrentPosition() != 0) {
                        if (RecordedPlayerService.rPlayer.isPlaying())
                            RecordedPlayerService.pauseSong();
                        else {
                            RMusicService.changePlayerStopLayout(getActivity());
                            RecordedPlayerService.resumeSong();
                            globals.radioServiceActivity = getActivity();

                        }
                    } else {
                        RecordedManager.setIsPlayingFlag(true);
                        PreparePlayer(getActivity());
                    }
                }
                break;
        }
//        invalidOptionsMenuHelper();
    }

    public void showCustomMessage(String pTitle, final String pMsg, final int rID) {

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setCancelable(true);
        builder.setTitle(pTitle);
        builder.setMessage(pMsg);
        builder.setIcon(R.mipmap.ic_launcher);
        builder.setPositiveButton("Yes",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        deleteRecording(rID);
                        dialog.dismiss();
                    }
                });

        builder.setNegativeButton("No",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        AlertDialog alert = builder.create();
        alert.show();
    }

    public void deleteRecording(int rID) {
        Recording recording = DBHelper.getDBHelper(getActivity()).getRecording(rID);
        if (recording != null) {

            String fPath = recording.getPath();
            if (DBHelper.getDBHelper(getActivity()).deleteRecording(rID)) {
                File f = new File(fPath);
                if (f.exists()) {
                    f.delete();
                    if (rID == RecordedManager.getCurrent_rID()) {
                        //RecordedManager.setIsPlayingFlag(false);
                        RecordedPlayerService.stopPLaying();
                        updatePlayerVisibility(1);
                        RecordedManager.init();
                    }
                }
            }
        }
        loadSwitcherView();
    }
}

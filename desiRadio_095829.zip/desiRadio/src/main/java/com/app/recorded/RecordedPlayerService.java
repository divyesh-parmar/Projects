package com.app.recorded;

import java.io.IOException;
import java.lang.ref.WeakReference;
import java.text.DecimalFormat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnBufferingUpdateListener;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnInfoListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;

import androidx.annotation.RequiresApi;
import androidx.annotation.RequiresPermission;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import android.telephony.PhoneStateListener;
import android.telephony.TelephonyCallback;
import android.telephony.TelephonyManager;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;

import com.app.desiradio.MainActivity;
import com.app.desiradio.SplashScreenActivity;
import com.app.player.PlaylistManager;
import com.app.sqlite.DBHelper;
import com.app.utility.Debugger;
import com.app.utility.DummyActivity;
import com.app.utility.Globals;
import com.google.android.exoplayer2.C;
import com.indianradio.R;

public class RecordedPlayerService extends Service implements OnCompletionListener, OnBufferingUpdateListener,
        OnPreparedListener, OnErrorListener, OnInfoListener, OnSeekBarChangeListener {

    public static MediaPlayer rPlayer;
    public static int errorCount = 0;
    private static int lengthOfAudio;
    public static final int NOTIFICATION_ID = 11;
    public static Service me = null;
    static String fPath;
    int currentSecondaryProgress = 0;
    public static Boolean isInternetPresent = false, isPrepare = false, isError = false;
    static Context context;

    private static Handler progressBarHandler = new Handler();
    private static WeakReference<SeekBar> songProgressBar;

    String TAG = "RecordedPlayerService";


    @RequiresApi(api = Build.VERSION_CODES.S)
    private static abstract class CallStateListener extends TelephonyCallback implements TelephonyCallback.CallStateListener {
        @Override
        abstract public void onCallStateChanged(int state);
    }

    private boolean callStateListenerRegistered = false;

    @RequiresPermission(android.Manifest.permission.READ_PHONE_STATE)
    private CallStateListener callStateListener = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) ?
            new CallStateListener() {
                @Override
                public void onCallStateChanged(int state) {
                    // Handle call state change
                    performStateOperation(state);
                }
            }
            : null;

    private PhoneStateListener phoneStateListener = (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) ?
            new PhoneStateListener() {
                @Override
                public void onCallStateChanged(int state, String phoneNumber) {
                    // Handle call state change
                    performStateOperation(state);
                }
            }
            : null;

    public void performStateOperation(int state) {

        if (state == TelephonyManager.CALL_STATE_RINGING || state == TelephonyManager.CALL_STATE_OFFHOOK) { // Incoming call: Pause music
            if (RecordedManager.isPlaying()) {
                mWasPlayingWhenCalled = true;
                RecordedPlayerService.rPlayer.pause();
                Debugger.debugI(TAG, "CALL_STATE_RINGING");
            }
        } else if (state == TelephonyManager.CALL_STATE_IDLE) {  // Not in call: Play music
            if (mWasPlayingWhenCalled) {
                RecordedPlayerService.rPlayer.start();
                mWasPlayingWhenCalled = false;
            }
            Debugger.debugI(TAG, "CALL_STATE_IDLE");
        }

    }


    @Override
    public void onCreate() {
        TAG = getClass().getName();
        initializePlayer();

        Debugger.debugI(TAG, TAG + "__ oncreate __");


        TelephonyManager telephonyManager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);

        if (!callStateListenerRegistered) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                    telephonyManager.registerTelephonyCallback(getMainExecutor(), callStateListener);
                    callStateListenerRegistered = true;
                }
            } else {
                telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_CALL_STATE);
                callStateListenerRegistered = true;
            }
        }

        super.onCreate();
    }

    private void initializePlayer() {
        Debugger.debugI(TAG, "player initiated");
        rPlayer = new MediaPlayer();
        rPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        rPlayer.setOnCompletionListener(this);
        rPlayer.setOnBufferingUpdateListener(this);
        rPlayer.setOnPreparedListener(this);
        rPlayer.setOnErrorListener(this);
        rPlayer.setOnInfoListener(this);
    }

    private void initUI() {
        Debugger.debugI(TAG, TAG + "__ initUI __");

        try {
            if (RecordedFragment.isVisible) {
                songProgressBar = new WeakReference<SeekBar>(RecordedFragment.player_seek);
                songProgressBar.get().setOnSeekBarChangeListener(this);
                progressBarHandler.removeCallbacks(mUpdateTimeTask);
                updateSeekProgress();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        me = this;
    }

    // --------------onStartCommand---------------//
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // TODO Auto-generated method stub
        me = this;
        context = RecordedPlayerService.me.getApplicationContext();
        initUI();
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO Auto-generated method stub
        return null;
    }

    protected boolean mWasPlayingWhenCalled = false;
    PhoneStateListener phoneStateListener1 = new PhoneStateListener() {

        @Override
        public void onCallStateChanged(int state, String incomingNumber) {
            if (state == TelephonyManager.CALL_STATE_RINGING || state == TelephonyManager.CALL_STATE_OFFHOOK) { // Incoming call: Pause music
                if (RecordedManager.isPlaying()) {
                    mWasPlayingWhenCalled = true;
                    RecordedPlayerService.rPlayer.pause();
                    Debugger.debugI(TAG, "CALL_STATE_RINGING");
                }
            } else if (state == TelephonyManager.CALL_STATE_IDLE) {  // Not in call: Play music
                if (mWasPlayingWhenCalled) {
                    RecordedPlayerService.rPlayer.start();
                    mWasPlayingWhenCalled = false;
                }
                Debugger.debugI(TAG, "CALL_STATE_IDLE");
            }
            super.onCallStateChanged(state, incomingNumber);
        }
    };

    // ----------------on Seekbar Change Listener --------------------------------//
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromTouch) {
        Debugger.debugI(TAG, "progress : " + progress + " fromTouch : " + fromTouch);

        if (fromTouch) {
            RecordedFragment.tv_duration.setText(computeTimer((progress * lengthOfAudio) / 100));
        }
    }

    /**
     * When user starts moving the progress handler
     */
    public void onStartTrackingTouch(SeekBar seekBar) {
        // remove message Handler from updating progress bar
        progressBarHandler.removeCallbacks(mUpdateTimeTask);
        Debugger.debugI(TAG, "Seek : " + seekBar.getProgress());
    }

    /**
     * When user stops moving the progress hanlder
     */
    public void onStopTrackingTouch(SeekBar seekBar) {
        rPlayer.seekTo((lengthOfAudio / 100) * seekBar.getProgress());
        // update timer progress again
        updateSeekProgress();
    }

    private static Notification GeneratNotification() {
        CharSequence NotificationContent = DBHelper.getDBHelper(context).getRecording(RecordedManager.getCurrent_rID()).getName().toString() + ", is playing..";
        int icon = R.drawable.ic_action_play_recorded;
        String string = context.getString(R.string.app_name);
        Bitmap bm = BitmapFactory.decodeResource(RecordedPlayerService.me.getResources(), R.mipmap.ic_launcher);


        if (Build.VERSION.SDK_INT >= 26) {
            @SuppressLint("WrongConstant") NotificationChannel notificationChannel = new NotificationChannel(string, string, 3);
            notificationChannel.setDescription(string);
            notificationChannel.setSound((Uri) null, (AudioAttributes) null);
            ((NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(notificationChannel);
        }
        NotificationCompat.Builder defaults = new NotificationCompat.Builder(context, string).setSmallIcon((int) R.drawable.ic_action_play_recorded).setLargeIcon(bm)
                .setTicker("Recording is playing..").setContentTitle(me.getString(R.string.app_name)).setAutoCancel(false).setContentText(NotificationContent).setDefaults(38);
        Intent intent = new Intent(context, MainActivity.class);
        intent.putExtra("requiredRecordedView", true);
        int flag = PendingIntent.FLAG_UPDATE_CURRENT;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            flag = PendingIntent.FLAG_IMMUTABLE;
        }

        defaults.setContentIntent(PendingIntent.getActivity(context, 0, intent, flag));
        return defaults.build();

    }

    private static void updateSeekProgress() {
        progressBarHandler.postDelayed(mUpdateTimeTask, 0);
    }

    /**
     * Background Runnable thread
     */
    private static Runnable mUpdateTimeTask = new Runnable() {
        public void run() {

            if (RecordedFragment.isVisible) {
                if (isPrepare) {
                    long currentDuration = rPlayer.getCurrentPosition();
                    // Displaying time completed playing
                    RecordedFragment.tv_duration.setText(computeTimer(currentDuration));
                }
                if (songProgressBar != null) {
                    songProgressBar.get().setSelected(true);
                    songProgressBar.get().setProgress((int) (((float) rPlayer.getCurrentPosition() / lengthOfAudio) * 100));
                    if (rPlayer.isPlaying()) {
                        progressBarHandler.postDelayed(this, 500);
                    }
                }
            }
        }
    };

    /**
     * compute a timer value for the current playing song
     */
    private static String computeTimer(long time) {
        int min = (int) (time / 1000 / 60);
        String m = (min > 9) ? new DecimalFormat("00").format(min) : new DecimalFormat("0").format(min);
        String s = new DecimalFormat("00").format((int) (time / 1000 % 60));

        return (m + ":" + s);
    }

    public static void playSong() {
        Debugger.debugI("RecordedPlayerService", "RecordedPlayerService" + "__ playsong __");

        fPath = DBHelper.getDBHelper(context).getRecording(RecordedManager.getCurrent_rID()).getPath();
        initProgressBar();
        try {
            isError = false;
            errorCount = 0;
            rPlayer.reset();
            rPlayer.setDataSource(fPath);
            rPlayer.prepare();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (IllegalStateException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void stopPLaying() {
        if (rPlayer != null) {
            rPlayer.pause();
            rPlayer.seekTo(0);
            updateApplicationUI(false);
        }
    }

    public static void pauseSong() {
        if (rPlayer.isPlaying() && rPlayer != null) {
            progressBarHandler.removeCallbacks(mUpdateTimeTask);
            rPlayer.pause();
            updateApplicationUI(false);
        }
    }

    public static void resumeSong() {
        if (!rPlayer.isPlaying() && rPlayer != null) {
            rPlayer.start();
            updateApplicationUI(true);
            updateSeekProgress();
        }
    }

    public static void initProgressBar() {
        Debugger.debugI("RecordedPlayerService", "RecordedPlayerService" + "__ initProgressBar __");
        if (RecordedFragment.isVisible) {
            // set Progress bar values
            if (songProgressBar != null) {
                songProgressBar.get().setProgress(0);
                songProgressBar.get().setMax(100);
            }

            // Displaying time completed playing
            RecordedFragment.tv_duration.setText("0:00");
            RecordedFragment.btn_play_pause.setImageResource(R.drawable.btn_play);
        }

        isPrepare = false;
        RecordedManager.setIsPlayingFlag(true);

        progressBarHandler.removeCallbacks(mUpdateTimeTask);
    }

    public static void updateApplicationUI(boolean isplaying) {
        Debugger.debugI("RecordedPlayerService", "RecordedPlayerService" + "__ updateApplicationUI __");
        RecordedManager.setIsPlayingFlag(isplaying);

        if (RecordedFragment.isVisible) {
            if (isplaying) {
                RecordedFragment.btn_play_pause.setImageResource(R.drawable.btn_pause);
                if (songProgressBar != null)
                    songProgressBar.get().setEnabled(true);
            } else {
                RecordedFragment.btn_play_pause.setImageResource(R.drawable.btn_play);
                if (songProgressBar != null)
                    songProgressBar.get().setEnabled(false);
            }
        }

//        if (isplaying)
//            me.startForeground(NOTIFICATION_ID, GeneratNotification());
//        else
//            me.stopForeground(true);
    }

    /*
     * BufferUpdate Listener is used to moniter buffering of song
     * here secondary progress of seekbar will be updated
     */
    @Override
    public void onBufferingUpdate(MediaPlayer mediaPlayer, int percent) {
        Debugger.debugI(TAG, "Station Buffering :" + percent);
        currentSecondaryProgress = percent;
        try {
            if (RecordedFragment.isVisible)
                songProgressBar.get().setSecondaryProgress(percent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean onError(MediaPlayer mp, int what, int extra) {
        errorCount += 1;
        initProgressBar();
        StringBuilder sb = new StringBuilder();
        sb.append("Media Player Error: ");
        switch (what) {
            case MediaPlayer.MEDIA_ERROR_SERVER_DIED:
                Debugger.debugI(TAG, "MEDIA_ERROR_SERVER_DIED : " + what);
                isError = true;
                break;

            case MediaPlayer.MEDIA_ERROR_UNSUPPORTED:
                Debugger.debugI(TAG, "MEDIA_ERROR_UNSUPPORTED : " + what);
                isError = true;
                break;

            case MediaPlayer.MEDIA_ERROR_UNKNOWN:
                Debugger.debugI(TAG, "MEDIA_ERROR_UNKNOWN : " + what);
                isError = true;
                break;

            default:
                sb.append(" Non standard (");
                sb.append(what);
                sb.append(")");
        }
        sb.append(" (" + what + ") ");
        sb.append(extra);
        Debugger.debugI(TAG, "Error Listener called : " + sb.toString());
        return false;
    }

    @Override
    public boolean onInfo(MediaPlayer mp, int what, int extra) {
        Debugger.debugI(TAG, "Info Listener called" + what);
        return false;
    }

    @Override
    public void onPrepared(MediaPlayer arg0) {
        Debugger.debugI(TAG, "Prepared Listener called");
        lengthOfAudio = rPlayer.getDuration();
        isPrepare = true;
        resumeSong();
    }

    @Override
    public void onDestroy() {
        stopForeground(true);
        Debugger.debugI(TAG, TAG + "__ destroy __");
        if (rPlayer != null) {
            rPlayer.stop();
            rPlayer.release();
            rPlayer = null;
            Debugger.debugI(TAG, "Media player is release.");
        }
        super.onDestroy();
    }

    @Override
    public void onCompletion(MediaPlayer mPlayer) {
        Debugger.debugI(TAG, TAG + "__ onCompletion __");

        stopPLaying();
        dummyActivity();
    }

    public void dummyActivity() {
        Debugger.debugI(TAG, TAG + "__ dummy Activity __");
        Intent forgroundIntent = new Intent(context, DummyActivity.class);
        forgroundIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(forgroundIntent);
    }

    public void BringAppToForground() {
        Intent forgroundIntent = new Intent(context, SplashScreenActivity.class);
        forgroundIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        forgroundIntent.setAction(Intent.ACTION_MAIN);
        forgroundIntent.addCategory(Intent.CATEGORY_LAUNCHER);
        startActivity(forgroundIntent);
    }
}

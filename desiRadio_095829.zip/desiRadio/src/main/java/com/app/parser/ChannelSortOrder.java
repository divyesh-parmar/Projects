package com.app.parser;

import java.util.Comparator;

public class ChannelSortOrder implements Comparator<Channel>{

    @Override
    public int compare(Channel sp1, Channel sp2) {
        return (sp1.SortOrder < sp2.SortOrder ) ? -1: (sp1.SortOrder > sp2.SortOrder) ? 1:0 ;
    }
  
}

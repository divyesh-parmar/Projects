package com.app.utility;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.indianradio.R;

public class IABTestActivity extends Activity{
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.iab_test_activity);
		
		Button btn_on = (Button) findViewById(R.id.btn_on);
		btn_on.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				((Globals)IABTestActivity.this.getApplicationContext()).setNoAds(true);
			}
		});
		
		Button btn_off = (Button) findViewById(R.id.btn_off);
		btn_off.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				((Globals)IABTestActivity.this.getApplicationContext()).setNoAds(false);
			}
		});
	}

}

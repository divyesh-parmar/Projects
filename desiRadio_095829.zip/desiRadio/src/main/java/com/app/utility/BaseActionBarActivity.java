package com.app.utility;

import android.content.BroadcastReceiver;

import androidx.appcompat.app.AppCompatActivity;

//import com.android.GCMNotification.GCMUtilities;


public class BaseActionBarActivity extends AppCompatActivity {
	
	protected BroadcastReceiver mReceiver = null;
	
	@Override
	protected void onResume() {
		super.onResume();
		//if(MainActivity.isAppReady)
		//	registerReceiver(mReceiver = GCMUtilities.mHandleMessageReceiver, new IntentFilter(GCMUtilities.DISPLAY_MESSAGE_ACTION));
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		/*if(mReceiver != null) {
			unregisterReceiver(GCMUtilities.mHandleMessageReceiver);		
			mReceiver = null;
		} */
	}
}

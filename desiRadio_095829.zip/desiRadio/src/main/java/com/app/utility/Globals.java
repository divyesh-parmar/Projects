package com.app.utility;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;

import android.annotation.SuppressLint;
import android.app.Activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Configuration;
import android.net.ConnectivityManager;
import android.os.Build;
import android.os.Environment;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.multidex.MultiDex;
import androidx.multidex.MultiDexApplication;

import android.telephony.TelephonyManager;
import android.view.inputmethod.InputMethodManager;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.app.ads.AppOpenAdManager;
import com.app.ads.interfaces.ShowOpenAdCompleteListener;
import com.app.genre.ChannelItem;
import com.app.internetreceiver.ConnectivityReceiver;
import com.app.parser.Channel;
import com.app.parser.Language;
import com.google.android.gms.ads.MobileAds;
import com.google.firebase.FirebaseApp;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.indianradio.R;

public class Globals extends MultiDexApplication {

    SharedPreferences sp;
    SharedPreferences.Editor editor;
    boolean isRequestPending;
    private RequestQueue mRequestQueue;

    String newAppVersion;
    String nativeAdFlag;
    boolean isUpdateDialogNeeded;

    public ArrayList<Channel> ChannelList;
    public ArrayList<Language> languageList;

    File rCacheDir;
    File iCacheDir;
    public static String TAG;
    public Activity radioServiceActivity;
    public static Context myGlobalsContext;
    private static boolean activityVisible;

    public static Context getContext() {
        return myGlobalsContext;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        TAG = getClass().getName();
        initialize();
        Debugger.debugI(TAG, "onCreate Method called");

        myGlobalsContext = getApplicationContext();

        // for dark mode or light mode changes
        if (Utils.getInt(myGlobalsContext, "mode", 0) == 0) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        } else if (Utils.getInt(myGlobalsContext, "mode", 0) == 1) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_UNSPECIFIED);

            if (getSystemMode(myGlobalsContext) == Configuration.UI_MODE_NIGHT_NO) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
            } else if (getSystemMode(myGlobalsContext) == Configuration.UI_MODE_NIGHT_YES) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            }
        }

        // register receiver
        getApplicationContext().registerReceiver(new ConnectivityReceiver(),
                new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
        FirebaseApp.initializeApp(this);
        FirebaseCrashlytics.getInstance().setCrashlyticsCollectionEnabled(true);
        initAds();
    }

    public int getSystemMode(Context activity) {
        return activity.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
    }

    private void initAds() {
        MobileAds.initialize(this, initializationStatus -> {

        });
        //   MobileAds.setAppVolume(0.0f);
    }

    /**
     * OpenAds Code
     */

    public void showAdIfAvailable(@NonNull Activity activity, @NonNull ShowOpenAdCompleteListener onShowAdCompleteListener) {
        AppOpenAdManager.getInstance().showAdIfAvailable(activity, onShowAdCompleteListener);
    }

    @Override
    protected void attachBaseContext(Context context) {
        super.attachBaseContext(context);
        MultiDex.install(this);
    }

    public void initialize() {
        //initialization
        ChannelList = new ArrayList<Channel>();
        languageList = new ArrayList<Language>();
        sp = null;
        editor = null;
        isRequestPending = false;

        newAppVersion = null;
        nativeAdFlag = "0";
        isUpdateDialogNeeded = true;
    }

    public File getDir(Context context) {
        return (rCacheDir == null) ? rCacheDir = makeDir(context) : rCacheDir;
    }

    public File makeDir(Context context) {
        //Find the dir to save Recorded songs
        if (android.os.Environment.getExternalStorageState().equals(android.os.Environment.MEDIA_MOUNTED)) {
            // Create directory into External storage;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                rCacheDir = new File(getExternalFilesDir(Environment.DIRECTORY_MUSIC) + "/" + getResources().getString(R.string.app_name) + File.separator + "Recordings");
            } else {
                rCacheDir = new File(android.os.Environment.getExternalStorageDirectory(), getResources().getString(R.string.app_name) + File.separator + "Recordings");
            }
            if (!rCacheDir.exists())
                rCacheDir.mkdirs();
        } else {
            Utils.showToast(context, "External storage Required for Recording.");
            rCacheDir = null;
        }

        return rCacheDir;
    }

    public File getCache() {
        //Find the dir to save cached images
        if (android.os.Environment.getExternalStorageState().equals(android.os.Environment.MEDIA_MOUNTED))

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                iCacheDir = new File(getExternalFilesDir(Environment.DIRECTORY_MUSIC) + "/" + getResources().getString(R.string.app_name) + File.separator + "cache");
            } else {
                iCacheDir = new File(android.os.Environment.getExternalStorageDirectory(), getResources().getString(R.string.app_name) + File.separator + "cache");
                // iCacheDir = new File(android.os.Environment.getExternalStorageDirectory(), "Android" );
            }

        else
            iCacheDir = getCacheDir();

        if (!iCacheDir.exists())
            iCacheDir.mkdirs();
        return iCacheDir;
    }

    public static boolean isActivityVisible() {
        return activityVisible;
    }

    public static void activityResumed() {
        activityVisible = true;
    }

    public static void activityPaused() {
        activityVisible = false;
    }

    public void clearCache() {
        if (iCacheDir == null) {
            return;
        }
        if (iCacheDir.exists()) {
            File[] files = iCacheDir.listFiles();
            if (files != null && files.length > 0)
                for (File f : files)
                    f.delete();
        }
    }

    public SharedPreferences getSharedPref() {
        return sp = (sp == null) ? getSharedPreferences("secrets", Context.MODE_PRIVATE) : sp;
    }

    public SharedPreferences.Editor getEditor() {
        return editor = (editor == null) ? getSharedPref().edit() : editor;
    }

    public boolean isRequestPandding() {
        return isRequestPending;
    }

    public void setRequestPandding(boolean isRequestPandding) {
        this.isRequestPending = isRequestPandding;
    }

    public void GCMRegistrationRequest() {
    }

    public void setLastPlayedIndex(int index) {
        getEditor().putInt("last_played_index", index);
        getEditor().apply();
    }

    public void setNoAds(boolean isNoAds) {
        getEditor().putBoolean("isNoAds", isNoAds);
        getEditor().commit();
    }

    public int getMaxRecordingTime() {
        return getSharedPref().getInt("rMaxTime", 1);
    }

    public void setMaxRecordingTime(int maxTime) {
        getEditor().putInt("rMaxTime", maxTime);
        getEditor().commit();
    }

    public boolean isNotificationON() {
        return getSharedPref().getBoolean("isNotificationON", true);
    }

    public void setGCM_DeviceToken(String token) {
        getEditor().putString("DeviceToken", token);
        getEditor().commit();
    }

    public boolean isUpdateDialogNeeded() {
        return isUpdateDialogNeeded;
    }

    public ArrayList<Channel> getChannelList() {
        return ChannelList;
    }

    public ArrayList<Language> getLanguageList() {
        return languageList;
    }

    public void setLanguageList(ArrayList<Language> languageList) {
        this.languageList.clear();
        this.languageList = languageList;
    }

    public void setChannelList(ArrayList<Channel> ChannelList) {
        this.ChannelList.clear();
        this.ChannelList = ChannelList;
    }

    public String getDeviceName() {
        String manufacturer = Build.MANUFACTURER;
        String model = Build.MODEL;
        if (model.startsWith(manufacturer)) {
            return capitalize(model);
        } else {
            return capitalize(manufacturer) + " " + model;
        }
    }

    @SuppressLint("WrongConstant")
    public String getDeviceCountry() {
        return ((TelephonyManager) getSystemService("phone")).getNetworkCountryIso();
    }

    @SuppressLint("WrongConstant")
    public String getDeviceCarriers() {
        return ((TelephonyManager) getSystemService("phone")).getNetworkOperatorName();
    }

    public String getOsName() {
        String str = null;
        for (Field field : Build.VERSION_CODES.class.getFields()) {
            String name = field.getName();
            int i = -1;
            try {
                i = field.getInt(new Object());
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
            if (i == Build.VERSION.SDK_INT) {
                str = name;
            }
        }
        return str;
    }

    public String getOsVersion() {
        return Build.VERSION.RELEASE;
    }

    private String capitalize(String s) {
        if (s == null || s.length() == 0) {
            return "";
        }
        char first = s.charAt(0);
        if (Character.isUpperCase(first)) {
            return s;
        } else {
            return Character.toUpperCase(first) + s.substring(1);
        }
    }

    public String getApplicationPackageName() {
        return getApplicationContext().getPackageName();
    }

    public String getApplicationVersionName() {
        String Version = "1.0.1";
        try {
            PackageInfo pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
            Version = pInfo.versionName;
        } catch (NameNotFoundException e) {
            e.printStackTrace();
        }
        return Version;
    }

    public void addFragment(FragmentManager fragmentManager, int placeholder, Fragment fragment, boolean addBackStack) {
        FragmentTransaction ft = fragmentManager.beginTransaction();
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        ft.replace(placeholder, fragment);
        if (addBackStack)
            ft.addToBackStack(null);
        ft.commit();
    }

    public void addFragmentThisCase(FragmentManager fragmentManager, int placeholder, Fragment fragment, boolean addBackStack) {
        FragmentTransaction ft = fragmentManager.beginTransaction();
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        ft.add(placeholder, fragment);
        if (addBackStack)
            ft.addToBackStack(null);
        ft.commit();
    }

    public void showCustomMessageOK(Context _context, String pTitle, final String pMsg, boolean isCancle) {
        AlertDialog.Builder builder = new AlertDialog.Builder(_context);

        builder.setCancelable(isCancle);
        builder.setTitle(pTitle);
        builder.setMessage(pMsg);

        if (pTitle.contains(getResources().getString(R.string.app_name)))
            builder.setIcon(R.mipmap.ic_launcher);
        else
            builder.setIcon(R.drawable.alert_icon);

        builder.setPositiveButton("OK",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        AlertDialog alert = builder.create();
        alert.show();
    }

    public ArrayList<Channel> fetchFavoriteList(Context _context) {

        ArrayList<Channel> tempList;
        SharedPreferences prefs = _context.getSharedPreferences(Constant.MM_FAVORITES, Context.MODE_PRIVATE);
        Gson gson = new Gson();
        Type arrayType = new TypeToken<ArrayList<Channel>>() {
        }.getType();
        String json = prefs.getString(Constant.MM_FAVORITES_LIST, gson.toJson(new ArrayList<Channel>(), arrayType));
        tempList = gson.fromJson(json, arrayType);
        Debugger.debugI(TAG, "saved list size :" + tempList.toString());

        return tempList;
    }

    public void saveFavoriteList(Context _context, ArrayList<Channel> tempList) {
        SharedPreferences prefs = _context.getSharedPreferences(Constant.MM_FAVORITES, Context.MODE_PRIVATE);
        Editor editor = prefs.edit();
        Gson gson = new Gson();
        Type arrayType = new TypeToken<ArrayList<Channel>>() {
        }.getType();
        String json = gson.toJson(tempList, arrayType);
        editor.putString(Constant.MM_FAVORITES_LIST, json);
        editor.apply();
    }

    public ArrayList<HashMap<String, String>> fetchUserAddedStationList(Context _context) {
        ArrayList<HashMap<String, String>> templist;
        SharedPreferences prefs = _context.getSharedPreferences(Constant.MM_USER_ADDED_STATIONS, Context.MODE_PRIVATE);
        Gson gson = new Gson();
        Type arrayType = new TypeToken<ArrayList<HashMap<String, String>>>() {
        }.getType();
        String json = prefs.getString(Constant.MM_OWN_STATION_LIST, gson.toJson(new ArrayList<HashMap<String, String>>(), arrayType));
        templist = gson.fromJson(json, arrayType);
        Debugger.debugI(TAG, "UserAddedStations saved list size :" + templist.size());
        return templist;
    }

    public void saveUserAddedStationList(Context _context, ArrayList<HashMap<String, String>> tempList) {
        SharedPreferences prefs = _context.getSharedPreferences(Constant.MM_USER_ADDED_STATIONS, Context.MODE_PRIVATE);
        Editor editor = prefs.edit();
        Gson gson = new Gson();
        Type arrayType = new TypeToken<ArrayList<HashMap<String, String>>>() {
        }.getType();
        String json = gson.toJson(tempList, arrayType);
        editor.putString(Constant.MM_OWN_STATION_LIST, json);
        editor.apply();
    }

    public ArrayList<Channel> fetchHistoryList(Context _context) {

        ArrayList<Channel> tempList;
        SharedPreferences prefs = _context.getSharedPreferences(Constant.MM_STATION_HISTORY, Context.MODE_PRIVATE);
        Gson gson = new Gson();
        Type arrayType = new TypeToken<ArrayList<Channel>>() {
        }.getType();
        String json = prefs.getString(Constant.MM_HISTORY_LIST, gson.toJson(new ArrayList<Channel>(), arrayType));
        tempList = gson.fromJson(json, arrayType);
        Debugger.debugI(TAG, "saved History list size :" + tempList.size());

        return tempList;
    }

    public void saveHistoryList(Context _context, ArrayList<Channel> tempList) {
        SharedPreferences prefs = _context.getSharedPreferences(Constant.MM_STATION_HISTORY, Context.MODE_PRIVATE);
        Editor editor = prefs.edit();
        Gson gson = new Gson();
        Type arrayType = new TypeToken<ArrayList<Channel>>() {
        }.getType();
        String json = gson.toJson(tempList, arrayType);
        editor.putString(Constant.MM_HISTORY_LIST, json);
        editor.apply();
    }

    public void AddStationToHistory(Context _context, Channel channel) {
        Debugger.debugI(TAG, "AddStationToHistory called");
        ArrayList<Channel> historyList = fetchHistoryList(_context);
        if (!isStationExistInHistory(_context, historyList, channel)) {
            if (historyList.size() == 25) {
                historyList.remove(0);
            }
            if (historyList.add(channel)) {
                Debugger.debugI(TAG, "New station in history is added : " + channel.toJsonData());
            }
            saveHistoryList(_context, historyList);
        }
    }

    public boolean isStationExistInHistory(Context _context, ArrayList<Channel> historyList, Channel channel) {
        Debugger.debugI(TAG, "History channel check");
        boolean isExist = false;
        int i = 0;
        int count = historyList.size();
        for (i = 0; i < count; i++) {
            if (historyList.get(i).ChannelId != null && historyList.get(i).ChannelId.equals(channel.ChannelId) && historyList.get(i).ChannelLink != null && historyList.get(i).ChannelLink.equals(channel.ChannelLink)) {

                isExist = true;
                break;
            }
        }

        if (isExist) {
            Debugger.debugI(TAG, "History channel item is updated");
            historyList.remove(i);
            historyList.add(channel);
            saveHistoryList(_context, historyList);
        }
        return isExist;
    }

    public ArrayList<ChannelItem> convertChannelObjList(ArrayList<Channel> stationArraylist) {
        ArrayList<ChannelItem> station_ads_list = new ArrayList<ChannelItem>();

        for (Channel ChannelItem : stationArraylist) {
            station_ads_list.add(new ChannelItem(ChannelItem));
        }
        return station_ads_list;
    }

    public ArrayList<Channel> convertChannelMapList(ArrayList<ChannelItem> station_Ads_Arraylist) {
        ArrayList<Channel> stationList = new ArrayList<Channel>();
        for (ChannelItem stationItem : station_Ads_Arraylist) {
			/*if(stationItem.getNativeAdItem() == null) {
				stationList.add(stationItem.getChannelMap());
			}*/
            stationList.add(stationItem.getChannelMap());
        }
        return stationList;
    }

    public RequestQueue getRequestQueue() {
        if (mRequestQueue == null) {
            mRequestQueue = Volley.newRequestQueue(getApplicationContext());
        }
        return mRequestQueue;
    }

    public <T> void addToRequestQueue(Request<T> req) {
        req.setTag(TAG);
        req.setRetryPolicy(new DefaultRetryPolicy(30000, 1, 1));
        getRequestQueue().add(req);
    }

    public Boolean isPlayedFromSp() {
        return getSharedPref().getBoolean("isPlayedSP", false);
    }

    public int getCurrentIndexOfChannel(Channel cItem, ArrayList<Channel> channelList) {
        for (int i = 0; i < channelList.size(); i++) {
            if (cItem.ChannelId.equals(channelList.get(i).ChannelId)) {
                return i;
            }
        }
        return 0;
    }

    public void hideKeyboard(Activity activity) {
        try {
            InputMethodManager inputManager = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
            inputManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
        } catch (Exception e) {
            Debugger.debugI(getClass().getName(), "not able to hide keyboard.");
        }
    }
}
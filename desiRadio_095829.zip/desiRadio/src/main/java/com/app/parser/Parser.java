package com.app.parser;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import android.text.Html;
import android.util.Log;

import com.android.youtube.ConvertSeconds;
import com.app.utility.Debugger;
import com.app.utility.Globals;

public class Parser {
	
	public static String getStringFromJSON(JSONObject obj, String key) {
		try {
			return obj.getString(key);
		} catch (JSONException e) {
			e.printStackTrace();
			return "";
		}
	}
	
	/**
	 * Getting Genre list
	 * @param globals 
	 * @param json string
	 * */
	public static ArrayList<Language> getGenreList(Globals globals, JSONArray jsonArray) 
	{
		ArrayList<Language> Languages = new ArrayList<Language>();
		ArrayList<Channel> AllChannels = new ArrayList<Channel>();
		int count = jsonArray.length();
		for (int i = 0; i < count; i++) 
		{
			String LanguageId = null;
			String LanguageName = null;
			int LanguageSortOrder = 999;
			String LanguageIsNew = null;
			ArrayList<Channel> Channels = new ArrayList<Channel>();
			int channelcount = 0;
			
			try {
				JSONObject JObj_language = ((JSONObject) jsonArray.get(i));
				@SuppressWarnings("rawtypes")
				Iterator keys = JObj_language.keys();
				
				while(keys.hasNext()) 
				{
			        String currentDynamicKey = (String)keys.next();
			        JSONArray JArray_channels = JObj_language.getJSONArray(currentDynamicKey);
			        
			        Channels.clear();
			        channelcount = JArray_channels.length();
					for (int j = 0; j < channelcount; j++) 
					{
						try {
							JSONObject jObj_channel = ((JSONObject) JArray_channels.get(j));
							
							if(j == 0) {
								LanguageId = jObj_channel.getString("LanguageId");
								LanguageName = Html.fromHtml(jObj_channel.getString("LanguageName")).toString();
								LanguageSortOrder = Integer.parseInt(jObj_channel.getString("LanguageSortOrder"));
								LanguageIsNew = jObj_channel.getString("LanguageIsNew");
							}
							
							String ChannelId = jObj_channel.getString("ChannelId");
							String ChannelTitle = Html.fromHtml(jObj_channel.getString("ChannelTitle")).toString();
							String ChannelDescription = Html.fromHtml(jObj_channel.getString("ChannelDescription")).toString();
							String ChannelLink = jObj_channel.getString("ChannelLink");
							String ChannelByte = jObj_channel.getString("ChannelByte");
							int SortOrder = Integer.parseInt(jObj_channel.getString("SortOrder"));
							String ChannelIsNew = jObj_channel.getString("ChannelIsNew");
							
							Channels.add(new Channel(ChannelId, ChannelTitle, ChannelDescription, ChannelLink, ChannelByte, SortOrder, ChannelIsNew, LanguageId, LanguageName, 0));
							AllChannels.add(new Channel(ChannelId, ChannelTitle, ChannelDescription, ChannelLink, ChannelByte, SortOrder, ChannelIsNew, LanguageId, LanguageName, 0));
							
						} catch (JSONException e) {
							e.printStackTrace();
						}
					}
					Collections.sort(Channels,new ChannelSortOrder());
			    }
				Languages.add(new Language(LanguageId, LanguageName, LanguageSortOrder, channelcount, LanguageIsNew, Channels));
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}
		Collections.sort(Languages,new LanguageSortOrder());
		globals.setChannelList(AllChannels);
		return Languages;
	}
	
	
	/**
	 * Getting Youtube Video List 
	 */
	public static ArrayList<HashMap<String, String>> getVideoList(JSONArray jsonArray) {

		ArrayList<HashMap<String, String>> itemList = new ArrayList<HashMap<String, String>>();

		int count = jsonArray.length();
		for (int i = 0; i < count; i++) {
			HashMap<String, String> item = new HashMap<String, String>();
			try {
				JSONObject temp = jsonArray.getJSONObject(i);

				item.put("youtubeID", getStringFromJSON(temp, "id"));
				
				JSONObject jSnippet = temp.getJSONObject("snippet");
				item.put("title", Html.fromHtml(getStringFromJSON(jSnippet, "title")).toString());
				item.put("description", Html.fromHtml(getStringFromJSON(jSnippet, "description")).toString());
				
				JSONObject jContentDetails = temp.getJSONObject("contentDetails");
				item.put("duration", ConvertSeconds.getSimpleDuration(getStringFromJSON(jContentDetails, "duration")));
				
				JSONObject jThumbnail = jSnippet.getJSONObject("thumbnails");
				JSONObject jHigh = jThumbnail.getJSONObject("high");
				item.put("big_thumbnail", jHigh.getString("url"));
				
				JSONObject jDefault = jThumbnail.getJSONObject("default");
				item.put("small_thumbnail", jDefault.getString("url"));

			} catch (JSONException e) {
				e.printStackTrace();
			}
			itemList.add(item);
		}
		return itemList;
	}
	
	/**
	 * Getting Youtube Video id as string 
	 */
	public static String getVideoID(JSONArray jsonArray) {

		int count = jsonArray.length();
		StringBuilder str = new StringBuilder();
	   
		for (int i = 0; i < count; i++) {
			try {
				JSONObject temp = jsonArray.getJSONObject(i).getJSONObject("id");
				String youtube_id = getStringFromJSON(temp, "videoId");
				str.append(youtube_id+",");
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}
		return str.toString();
	}
	

	public static Document getDomElement(String xml) {
		Document doc = null;
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		try {
			DocumentBuilder db = dbf.newDocumentBuilder();
			InputSource is = new InputSource();
			is.setCharacterStream(new StringReader(xml));
			doc = db.parse(is);

		} catch (ParserConfigurationException e) {
			Debugger.debugI("Error: ", e.getMessage());
			return null;
		} catch (SAXException e) {
			Debugger.debugI("Error: ", e.getMessage());
			return null;
		} catch (IOException e) {
			Debugger.debugI("Error: ", e.getMessage());
			return null;
		}
		return doc;
	}
	
/*	public static NativeAdItem parseInMobiNativeAd(String content) {

		if (content == null || content.trim().length() == 0)
			return null;
		
		NativeAdItem item = new NativeAdItem();
		try {
			JSONObject mainObject = new JSONObject(content);
			item.title = getStringFromJSON(mainObject, "title");
			
			try {
				JSONObject icon = mainObject.getJSONObject("icon");
				item.iconURL = getStringFromJSON(icon, "url");
			} catch (Exception e) {
				e.printStackTrace();
				item.iconURL = "";
			}
			
			item.cta = getStringFromJSON(mainObject, "cta");
			item.landingURL = mainObject.getString("landingURL");
			
			try {
				item.rating = mainObject.getString("rating");
			} catch (Exception e) {
				e.printStackTrace();
				item.rating = "0";
			}
			item.category = "";
			return item;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public static NativeAdItem parseStartAppNativeAd(NativeAdDetails adDetails) {

		if (adDetails == null)
			return null;
		
		NativeAdItem item = new NativeAdItem();
		try {
			item.title = Html.fromHtml(adDetails.getTitle()).toString();
			item.iconURL = adDetails.getImageUrl();
//			item.cta = adDetails.getInstalls();
			item.cta = adDetails.getCategory();
			item.landingURL = null;
			item.rating = Float.toString(adDetails.getRating());
			item.category = adDetails.getCategory();
			
			return item;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}*/
}

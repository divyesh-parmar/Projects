package com.app.genre;

import static com.app.utility.Utils.generateRandomNumber;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.android.GoogleAnalytics.Analytics;
import com.android.GoogleAnalytics.AnalyticsConstant;
import com.android.Utility.Classes.ProgressIndicator;
import com.android.youtube.YoutubeListActivity;
import com.app.ads.InterstitialAdManager;
import com.app.ads.InterstitialUtils;
import com.app.ads.NativeAdsLanguageUtils;
import com.app.ads.NativeAdsUtils;
import com.app.ads.interfaces.InterstitialDismissListener;

import com.app.auto.apicall.DataProvider;
import com.app.auto.apicall.OnApiCallListener;
import com.app.desiradio.MainActivity;
import com.app.desiradio.PrepareDrawerList;
import com.app.http.ConnectionDetector;
import com.app.http.ParamsGenerator;
import com.app.http.Utils;
import com.app.parser.Parser;
import com.app.player.PlaylistManager;
import com.app.recorded.RecordedManager;
import com.app.utility.Constant;
import com.app.utility.Debugger;
import com.app.utility.Globals;
import com.indianradio.R;

import java.text.SimpleDateFormat;
import java.util.Date;

public class LanguageListFragment extends Fragment  {

    View view;
    Globals globals;
    public static String TAG;

    LanguageListRAdapter LanguageAdapter;
    Menu mOptionsMenu;
    MenuInflater mMenuInflater;

    LinearLayout contentLayout;
    public static int random;

    //Try Again Layout
    LinearLayout tryAgainLayout;
    Button btn_tryAgain;
    int mPosition;
    public static RecyclerView rv_language;
    ProgressIndicator mProgress;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        TAG = getClass().getName();
        globals = ((Globals) getActivity().getApplicationContext());

        // remove native id if already have
        NativeAdsLanguageUtils.getInstance().removeAdView();

        // set language list adapter
        LanguageAdapter = new LanguageListRAdapter(getActivity(), new com.app.genre.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                showDetails(position);
            }
        });

        // create menus
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.language_list_fragment, container, false);

        ((MainActivity) getActivity()).actionbar.setTitle(PrepareDrawerList.dw_entry_Genre);
        globals.hideKeyboard(getActivity());
        ((MainActivity) getActivity()).mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);
        // Languagelist = (ListView) view.findViewById(R.id.LanguageList);
        rv_language = view.findViewById(R.id.rv_language);
        rv_language.setLayoutManager(new GridLayoutManager(getActivity(), 1));


        tryAgainLayout = (LinearLayout) view.findViewById(R.id.tryAgainLayout);
        showTryAgain(false);

        btn_tryAgain = (Button) view.findViewById(R.id.btn_try_again);
        btn_tryAgain.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                FetchList();
            }
        });

        //Ads
        contentLayout = (LinearLayout) view.findViewById(R.id.contentLayout);

        if (globals.getLanguageList().isEmpty()) {
            if (ConnectionDetector.isConnectingToInternet(getActivity()))
                FetchList();
            else {
                showTryAgain(true);
            }
        } else {
            setLanguageListAdapter();
        }

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        Debugger.debugI(TAG, "on resume called");

        globals.radioServiceActivity = getActivity();
        //here fetch the language list

        invalidOptionsMenuHelper();
    }

    public void showTryAgain(boolean isVisible) {
        tryAgainLayout.setVisibility(isVisible ? View.VISIBLE : View.GONE);
    }

    public void invalidOptionsMenuHelper() {
        if (mOptionsMenu != null && mMenuInflater != null) {
            mOptionsMenu.clear();
            onCreateOptionsMenu(mOptionsMenu, mMenuInflater);
        }
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        mOptionsMenu = menu;
        mMenuInflater = inflater;
        inflater.inflate(R.menu.genre_menu, menu);

//        if (!RecordedManager.isPlaying() && Constant.mStationArrayList != null && Constant.mStationArrayList.size() > 0) {
//            menu.findItem(R.id.now_playing).setVisible(true);
//        } else {
//            menu.findItem(R.id.now_playing).setVisible(false);
//        }

        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.refresh_genre:
                FetchList();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    //  fetch data
    public void FetchList() {
        boolean isInternetPresent = ConnectionDetector.isConnectingToInternet(getActivity());
        if (isInternetPresent) {

//            if (globals.getLanguageList() != null && globals.getLanguageList().size() > 0) {
//                Debugger.debugI(TAG, "get langList 1");
//                setLanguageListAdapter();
//
//            } else {
                Debugger.debugI(TAG, "get langList 2");
                mProgress = ProgressIndicator.show(getActivity(), Constant.genre_Loading_msg, true, false);


                new DataProvider(globals, new OnApiCallListener() {
                    @Override
                    public void onSuccessListener(String response) {

                        try {
                            if ((mProgress != null) && mProgress.isShowing()) {
                                mProgress.dismiss();
                            }
                        } catch (final IllegalArgumentException e) {
                            // Handle or log or ignore
                        } catch (final Exception e) {
                            // Handle or log or ignore
                        } finally {
                            mProgress = null;
                        }

                        if (response != null) {
                            Debugger.debugI(TAG, "response form api :" + response.trim());

                            if (!response.trim().equalsIgnoreCase("error_in_response")) {

                                setLanguageListAdapter();

                            } else {
                                ConnectionDetector.showAlertDialog(getActivity(), Constant.MM_ALERT_TITLE_ERROR, Constant.MM_NO_INTERNET_RESPOND_MSG, true);
                            }
                            sendAppReadyBroadcast();
                        }

                    }

                    @Override
                    public void onFailListener(String error) {

                        try {
                            if ((mProgress != null) && mProgress.isShowing()) {
                                mProgress.dismiss();
                            }
                        } catch (final IllegalArgumentException e) {
                            // Handle or log or ignore
                        } catch (final Exception e) {
                            // Handle or log or ignore
                        } finally {
                            mProgress = null;
                        }

                    }
                }).execute();

//            }


        } else
            ConnectionDetector.showAlertDialog(getActivity(), Constant.MM_NO_INTERNET_TITLE, Constant.MM_NO_INTERNET_MSG, true);
    }

    public void setLanguageListAdapter() {


        if (globals.getLanguageList() != null && globals.getLanguageList().size() > 0) {
            showTryAgain(false);
            LanguageAdapter.updateResults(getActivity(), globals.getLanguageList());
            random = generateRandomNumber(globals.getLanguageList().size());
            if (rv_language.getAdapter() == null)
                rv_language.setAdapter(LanguageAdapter);
        }
    }

    public static String getStringFromJSON(JSONObject obj, String key) {
        try {
            return obj.getString(key);
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
    }

    // Send an Intent with an action named "App-Ready-event". The Intent sent should
    // be received by the MainActivity and show Rater dialog and update dialog.
    public void sendAppReadyBroadcast() {
        Debugger.debugI(TAG, "UpdateDialogNeeded : " + globals.isUpdateDialogNeeded());
        if (globals.isUpdateDialogNeeded()) {
            Debugger.debugI(TAG, "sender Broadcasting message AppReady");
            Intent intent = new Intent("App-Ready");
            LocalBroadcastManager.getInstance(getActivity()).sendBroadcast(intent);
        }
    }

    void showDetails(int index) {
        mPosition = index;

        if (InterstitialAdManager.getInstance().showInterstitial(getContext()) && InterstitialUtils.getInstance().interstitialAd != null) {
            InterstitialUtils.getInstance().displayInterstitialAd(getActivity(), new InterstitialDismissListener() {
                @Override
                public void onInterstitialDismissListener(Activity activity, int ButtonId) {
                    processAfterAd();
                }
            }, 492562);
        } else {
            processAfterAd();
        }

    }

    public void processAfterAd() {

        globals.addFragment(getActivity().getSupportFragmentManager(), R.id.content_frame,
                ChannelListFragment.newInstance(mPosition, false), true);

    }

}
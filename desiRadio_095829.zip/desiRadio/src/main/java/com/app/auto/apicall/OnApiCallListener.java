package com.app.auto.apicall;

public interface OnApiCallListener {

    void onSuccessListener(String response);

    void onFailListener(String error);
}

package com.android.drawerlistview;

public interface Item {
	
	public enum Group {
		Main, More, Notification;
	}
	
	public boolean isSection();

}

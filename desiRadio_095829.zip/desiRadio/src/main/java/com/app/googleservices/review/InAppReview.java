package com.app.googleservices.review;


import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

import com.app.utility.Debugger;
import com.google.android.gms.tasks.Task;
import com.google.android.play.core.review.ReviewInfo;
import com.google.android.play.core.review.ReviewManager;
import com.google.android.play.core.review.ReviewManagerFactory;


public class InAppReview {

    private final static int DAYS_UNTIL_PROMPT = 7;//Min number of days
    private final static long LAUNCHES_UNTIL_PROMPT = 0;//Min number of launches
    public static String TAG = "InAppReview";

    public static void app_launched(Context mContext) {
        SharedPreferences prefs = mContext.getSharedPreferences("apprater", 0);
        if (prefs.getBoolean("dontshowagain", false)) {
            return;
        }

        SharedPreferences.Editor editor = prefs.edit();

        // Increment launch counter
        long launch_count = prefs.getLong("launch_count", 0) + 1;
        editor.putLong("launch_count", launch_count);

        // Get date of first launch
        Long date_firstLaunch = prefs.getLong("date_firstlaunch", 0);
        if (date_firstLaunch == 0) {
            date_firstLaunch = System.currentTimeMillis();
            editor.putLong("date_firstlaunch", date_firstLaunch);
        }

        // Wait at least n days before opening
        if (launch_count >= LAUNCHES_UNTIL_PROMPT) {
            if (System.currentTimeMillis() >= date_firstLaunch +
                    (DAYS_UNTIL_PROMPT * 24 * 60 * 60 * 1000)) {    //Uncomment for 7 days
                showRateDialog((Activity) mContext, editor);
            }
        }

        editor.commit();
    }

    public static void showRateDialog(Activity activity, final SharedPreferences.Editor editor) {

        Debugger.debugI(TAG,"showRateDialog: ");


        if (editor != null) {
            Long date_firstLaunch = System.currentTimeMillis();
            editor.putLong("date_firstlaunch", date_firstLaunch);
            editor.commit();
        }

        inAppReviewOpen(activity);
    }

    public static void inAppReviewOpen(Activity activity){
        ReviewManager manager = ReviewManagerFactory.create(activity);
//        ReviewManager manager = new FakeReviewManager(activity);

        Task<ReviewInfo> request = manager.requestReviewFlow();
        request.addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                // We can get the ReviewInfo object
                ReviewInfo reviewInfo = task.getResult();
                Task<Void> flow = manager.launchReviewFlow(activity, reviewInfo);
                flow.addOnCompleteListener(task1 -> {
                    // The flow has finished. The API does not indicate whether the user
                    // reviewed or not, or even whether the review dialog was shown. Thus, no
                    // matter the result, we continue our app flow.
                    Debugger.debugI(TAG,"openReviewDialog: Success");
                });
            } else {
                // There was some problem, continue regardless of the result.
                // you can show your own rate dialog alert and redirect user to your app page
                // on play store.

                Debugger.debugI(TAG,"openReviewDialog: Fail");
            }
        });
    }
}
package com.android.youtube;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.android.FirebaseAnalytics.AnalyticsConstants;
import com.android.Utility.Classes.OrientationManager;
import com.android.Utility.Classes.OrientationManager.OrientationChangeListener;
import com.android.Utility.Classes.UnCaughtException;
import com.app.utility.Constant;
import com.app.utility.Debugger;
import com.app.utility.Globals;
import com.app.utility.Utils;
import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayer.OnFullscreenListener;
import com.google.android.youtube.player.YouTubePlayer.PlaybackEventListener;
import com.google.android.youtube.player.YouTubePlayerView;

import com.indianradio.R;

public class videoplayerActivity extends YouTubeBaseActivity implements YouTubePlayer.OnInitializedListener, OnClickListener, OrientationChangeListener {

	static private final String YoutubeDeveloperKey = Constant.Youtube_Appkey;
	private static final int RECOVERY_DIALOG_REQUEST = 1;
	public static YouTubePlayer videoPlayer = null;
	private YouTubePlayerView youTubeView;
	
	static private String vID;
	int orientation;
	public static int currentIndex;
	Button btn_previous_video,btn_next_video;
	LinearLayout mHeader;

    ImageButton backButton;
	
	public boolean isFullScreen = false;

	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Thread.setDefaultUncaughtExceptionHandler(new UnCaughtException(videoplayerActivity.this));
		setContentView(R.layout.videoplayer_layout);
		
		Intent DATA = getIntent();
		currentIndex = DATA.getIntExtra("index", 0);
		
		OrientationManager.getInstance(this).setOrientationChangedListener(this);
		orientation = getResources().getConfiguration().orientation;
		OrientationManager.getInstance(videoplayerActivity.this).setOrientation(0);
		OrientationManager.getInstance(this).enable();
		
		videoPlayer = null;

        mHeader = findViewById(R.id.header);
        
		btn_previous_video = findViewById(R.id.btn_previous_video);
		btn_next_video = findViewById(R.id.btn_next_video);

        backButton = findViewById(R.id.back_btn_icon);

        backButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {

                onBackPressed();
            }
        });
		
		btn_previous_video.setOnClickListener(this);
		btn_next_video.setOnClickListener(this);
		
		setStateForNExtPreviousBtn();

		youTubeView = findViewById(R.id.youtube_view);
	    youTubeView.initialize(YoutubeDeveloperKey, this);

	    
	    onOrientationChanged(orientation);
	    //StartAnalytics(videoplayerActivity.this);
        Bundle bundle = new Bundle();
        bundle.putString(AnalyticsConstants.SCREEN_NAME, AnalyticsConstants.SN_video);

    }

	@Override
	public void onBackPressed() {
		if (orientation == Configuration.ORIENTATION_LANDSCAPE){

			exitFullScreen();
		}
		finish();
		overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btn_next_video:	
			PlayNextVideo();
			break;

		case R.id.btn_previous_video:	
			PLayPreviousVideo();
			break;
			
		default:
			break;
		}
	}
	
	public void PlayNextVideo() {
		if (currentIndex < YoutubeListActivity.itemList.size() - 1) {
			currentIndex++;
			startYoutubePlayback();
			setStateForNExtPreviousBtn();
		} else {
			Utils.showToast(getBaseContext(),"End of List");
		}
	}

	public void PLayPreviousVideo() {
		if (currentIndex > 0) {
			currentIndex--;
			startYoutubePlayback();
			setStateForNExtPreviousBtn();
		} else {
			Utils.showToast(getBaseContext(),"Beging of List");
		}
	}
	
	public void setStateForNExtPreviousBtn()
	{
		int size = YoutubeListActivity.itemList.size()-1;
		if (currentIndex == size) {
			btn_next_video.setEnabled(false);
			btn_previous_video.setEnabled(true);
			btn_next_video.setBackgroundResource(R.drawable.btn_next_video_disable);
			btn_previous_video.setBackgroundResource(R.drawable.btn_previous_video);
		} else if (currentIndex == 0) {
			btn_next_video.setEnabled(true);
			btn_previous_video.setEnabled(false);
			btn_next_video.setBackgroundResource(R.drawable.btn_next_video);
			btn_previous_video.setBackgroundResource(R.drawable.btn_previous_video_disable);
		} else if (currentIndex < size && currentIndex > 0) {
			btn_next_video.setEnabled(true);
			btn_previous_video.setEnabled(true);
			btn_next_video.setBackgroundResource(R.drawable.btn_next_video);
			btn_previous_video.setBackgroundResource(R.drawable.btn_previous_video);
		}
	}
	
	public void startYoutubePlayback() {
		/*if(adapter != null)
			adapter.notifyDataSetChanged();*/

		if(videoPlayer != null) {
			vID = YoutubeListActivity.itemList.get(currentIndex).get("youtubeID");
			videoPlayer.loadVideo(vID);

		} 
	}
	
	@Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == RECOVERY_DIALOG_REQUEST) {
            // Retry initialization if user performed a recovery action
            getYouTubePlayerProvider().initialize(YoutubeDeveloperKey, this);
        }
    }
 
    protected YouTubePlayer.Provider getYouTubePlayerProvider() {
        return (YouTubePlayerView) findViewById(R.id.youtube_view);
    }
	
	@Override
	public void onInitializationFailure(com.google.android.youtube.player.YouTubePlayer.Provider provider, YouTubeInitializationResult errorReason) {
		if (errorReason.isUserRecoverableError()) {
			errorReason.getErrorDialog(this, RECOVERY_DIALOG_REQUEST).show();	
		} else {
			String errorMessage = String.format(getString(R.string.error_player), errorReason.toString());
			Utils.showToast(this,errorMessage);
		}
	}
	
	@Override
	public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer player, boolean wasRestored) {
		videoPlayer = player;
	    // Specify that we want to handle fullscreen behavior ourselves.
		videoPlayer.addFullscreenControlFlag(YouTubePlayer.FULLSCREEN_FLAG_CUSTOM_LAYOUT);
		videoPlayer.setOnFullscreenListener(new OnFullscreenListener() {
			@Override
			public void onFullscreen(boolean _isFullScreen) {
				setFullScreenFlag(_isFullScreen);
				onOrientationChanged(_isFullScreen ? Configuration.ORIENTATION_LANDSCAPE : Configuration.ORIENTATION_PORTRAIT);
			}
		});
		
		videoPlayer.setPlaybackEventListener(new PlaybackEventListener() {
			
			@Override
			public void onStopped() {
				//adapter.notifyDataSetChanged();
			}
			
			@Override
			public void onSeekTo(int arg0) {
				
			}
			
			@Override
			public void onPlaying() {
				//adapter.notifyDataSetChanged();
			}
			
			@Override
			public void onPaused() {
				//adapter.notifyDataSetChanged();
			}
			
			@Override
			public void onBuffering(boolean arg0) {
				
			}
		});
		
		if (!wasRestored) {
			startYoutubePlayback();
		}
	}
	
    public boolean isFullScreen() {
        return isFullScreen;
    }
    
	public void setFullScreenFlag(boolean isFullScreen) {
		if(isFullScreen() != isFullScreen) {
			this.isFullScreen = isFullScreen;
			
			if(videoPlayer != null)
				videoPlayer.setFullscreen(isFullScreen);
		}
	}

	@Override
	protected void onPause() {
		super.onPause();
		Globals.activityPaused();
	}

	@Override
	protected void onResume() {
		super.onResume();
		Globals.activityResumed();
	}
	
	@Override
	public void onOrientationChanged(int newOrientation) {
		Debugger.debugI("TAG", "onOrientationChanged called");
		if (newOrientation == Configuration.ORIENTATION_PORTRAIT) {
			setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT);
			setFullScreenFlag(false);
			Debugger.debugI("TAG", "ORIENTATION_PORTRAIT");
		} else {
			setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
			setFullScreenFlag(true);
			Debugger.debugI("TAG", "SCREEN_ORIENTATION_SENSOR_LANDSCAPE");
		}
		orientation = newOrientation;
		updateLayout();
	}
	
	private void updateLayout() {
		Debugger.debugI("TAG", "updateLayout called");
		if(orientation == Configuration.ORIENTATION_LANDSCAPE) {
			mHeader.setVisibility(View.GONE);
			//video_Listview.setVisibility(View.GONE);
			enterFullScreen();
		} else if(orientation == Configuration.ORIENTATION_PORTRAIT) {
			// Show the description fragment
			mHeader.setVisibility(View.VISIBLE);
			//video_Listview.setVisibility(View.VISIBLE);
			exitFullScreen();
		} 
	}
	
	public void enterFullScreen() {
		Debugger.debugI("TAG", "enterFullScreen called");
		// Hide the status bar
	    getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);
	    
	    // Hide the software buttons
	    //if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.ICE_CREAM_SANDWICH) {
	    	View main_layout = findViewById(android.R.id.content).getRootView();
	    	main_layout.setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
	    //}
	}
	

    public void exitFullScreen() {
		Debugger.debugI("TAG", "exitFullScreen called");
		// Show the status bar
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        
		// Show the software buttons
		//if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.ICE_CREAM_SANDWICH) {
	    	View main_layout = findViewById(android.R.id.content).getRootView();
	    	main_layout.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
	    //}
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		OrientationManager.getInstance(this).disable();
	}
}

package com.app.genre;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.Utility.Classes.ImageLoader;
import com.app.ads.NativeAdsUtils;
import com.app.desiradio.MainActivity;
import com.app.parser.Channel;
import com.app.parser.Language;
import com.app.player.PlaylistManager;
import com.app.utility.Constant;

import com.app.utility.Debugger;
import com.app.utility.Globals;
import com.app.utility.Utils;
import com.google.android.ads.nativetemplates.TemplateView;
import com.indianradio.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class ChannelListRAdapter extends RecyclerView.Adapter<ChannelListRAdapter.MyHolder> implements Filterable {

    Activity activity;
    Globals globals;
    private static LayoutInflater inflater = null;
    public ImageLoader imageLoader;

    private ArrayList<ChannelItem> data;
    public static ArrayList<ChannelItem> temporarylist;
    public static ArrayList<ChannelItem> playlistArray;
    private Constant.PlayingMode playingMode;
    OnItemClickListener onItemClickListener;

    public ChannelListRAdapter(Activity activity, Constant.PlayingMode playingMode, OnItemClickListener onItemClickListener) {
        this.activity = activity;
        globals = ((Globals) activity.getApplicationContext());
        imageLoader = new ImageLoader(activity.getApplicationContext());

        data = new ArrayList<ChannelItem>();
        temporarylist = new ArrayList<ChannelItem>();
        playlistArray = new ArrayList<ChannelItem>();
        this.playingMode = playingMode;
        this.onItemClickListener = onItemClickListener;

    }

    public void refreshList(ArrayList<ChannelItem> d) {
        data = d;
        temporarylist = d;
        playlistArray = d;
        this.notifyDataSetChanged();
    }


    public String getCurrentFromettedDate(Date date) {
        SimpleDateFormat postFormatter = new SimpleDateFormat("MMM dd, yyyy hh:mm a", Locale.getDefault());
        return postFormatter.format(date);
    }

    public Filter getFilter() {
        Filter filter = new Filter() {

            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                FilterResults results = new FilterResults();

                //If there's nothing to filter on, return the original data for your list
                if (charSequence == null || charSequence.length() == 0) {
                    results.values = data;
                    results.count = data.size();
                } else {
                    ArrayList<ChannelItem> filterResultsData = new ArrayList<ChannelItem>();

                    for (int i = 0; i < data.size(); i++) {
                        ChannelItem temp = data.get(i);


                        {
                            if (temp.getChannelMap().ChannelTitle.toString().trim().toLowerCase().contains(charSequence.toString().trim().toLowerCase())) {
                                filterResultsData.add(temp);
                            }
                        }
                    }
                    results.values = filterResultsData;
                    results.count = filterResultsData.size();
                }
                return results;
            }

            @SuppressWarnings("unchecked")
            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                if (((ArrayList<ChannelItem>) results.values).size() > 0) {
                    temporarylist = (ArrayList<ChannelItem>) results.values;
                    playlistArray = (ArrayList<ChannelItem>) results.values;
                }else {
                    temporarylist = data;
                    playlistArray = data;
                }
                notifyDataSetChanged();
            }
        };
        return filter;
    }

    public ArrayList<ChannelItem> getCurrentVisibleList() {
        return temporarylist;
    }

    public ChannelItem getItem(int position) {
        return temporarylist.get(position);
    }

    @NonNull
    @Override
    public ChannelListRAdapter.MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(activity).inflate(R.layout.channel_item, parent, false);

        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ChannelListRAdapter.MyHolder holder, int position) {

        if (position > 99){
            Debugger.debugE("ChannelListRAdapter", " current position -> "+ position);
        }

        ChannelItem channelItem = getItem(position);
        Channel info = channelItem.getChannelMap();

        if (Constant.nativePlaceList.contains(position)) {
            Debugger.debugI("channelListRAdapter", "onBindViewHolder: " + position + " - " + info.ChannelTitle);

            if (Utils.getInt(activity, activity.getResources().getString(R.string.In_app_product_ads_id), 0) == 0) {
                if (holder.templateView != null) {
                    NativeAdsUtils.getInstance().showNative(activity, holder.templateView);
                }

                holder.templateView.setVisibility(View.VISIBLE);
                holder.div1.setVisibility(View.VISIBLE);
            }else {
                holder.templateView.setVisibility(View.GONE);
                holder.div1.setVisibility(View.GONE);
            }

        } else {
            holder.templateView.setVisibility(View.GONE);
            holder.div1.setVisibility(View.GONE);
        }


        holder.tv_sponsored.setVisibility(View.GONE);
        holder.divider.setVisibility(View.VISIBLE);

        if (playingMode == Constant.PlayingMode.OTHER && Integer.parseInt(info.ChannelIsNew) == 1)
            holder.isNew.setVisibility(View.VISIBLE);
        else
            holder.isNew.setVisibility(View.GONE);

        holder.name.setText(info.ChannelTitle);

        String desc = info.ChannelDescription;
        if (playingMode == Constant.PlayingMode.HISTORY)
            desc = getCurrentFromettedDate(new Date(info.lastPlayedDate));
        holder.desc.setText(desc);

        if (info.ChannelByte != null && info.ChannelByte.toString().trim().length() > 0) {
            holder.bytes.setVisibility(View.VISIBLE);
            holder.bytes.setText(info.ChannelByte + "K");
        } else {
            holder.bytes.setVisibility(View.GONE);
        }

        holder.listen_icon.setVisibility(View.VISIBLE);
        holder.listen_icon.setImageResource(R.drawable.headphones);
//        }

      //  holder.listen_icon.setBackgroundResource(R.drawable.listen_normal);
        if (PlaylistManager.isPlaying() && PlaylistManager.isStationPlaying(info)) {
            holder.listen_icon.setImageResource(R.drawable.headphones_blue);
        }

        if (playingMode == Constant.PlayingMode.OTHER && info.isFavorite)
            holder.favoriteImage.setVisibility(View.VISIBLE);
        else
            holder.favoriteImage.setVisibility(View.INVISIBLE);


        holder.my_item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onItemClickListener.onItemClick(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return temporarylist.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder {

        public TextView name;
        public TextView desc;
        public TextView bytes;
        public LinearLayout isNew, my_item;
        public ImageView favoriteImage;
        public ImageView listen_icon;
        LinearLayout templateView, divider,div1;
        TextView tv_sponsored;

        public MyHolder(@NonNull View itemView) {
            super(itemView);

            name = (TextView) itemView.findViewById(R.id.txt_channel_name);
            desc = (TextView) itemView.findViewById(R.id.txt_channel_desc);
            bytes = (TextView) itemView.findViewById(R.id.txt_byte);
            isNew = (LinearLayout) itemView.findViewById(R.id.isNew);
            favoriteImage = (ImageView) itemView.findViewById(R.id.img_favo);
            listen_icon = (ImageView) itemView.findViewById(R.id.listen_icon);
            templateView = itemView.findViewById(R.id.templateView);
            my_item = itemView.findViewById(R.id.my_item);
            divider = itemView.findViewById(R.id.divider);
            div1 = itemView.findViewById(R.id.div1);

            tv_sponsored = (TextView) itemView.findViewById(R.id.tv_sponsored);
        }
    }
}

package com.app.player;

import static com.app.auto.RMusicService.getAlbumTitle;
import static com.app.auto.RMusicService.getAlbumUris;

import static com.app.auto.RMusicService.saveRecordingIfInBackground;
import static com.app.auto.RMusicService.stopStation;
import static com.app.utility.Constant.RECORDING_FLAG;
import static com.app.utility.Constant.mStationArrayList;
import static com.app.utility.Utils.checkPlayerIsPlay;
import static com.app.utility.Utils.flgForPlayerOpen;
import static com.app.utility.Utils.isMyServiceRunning;
import static com.app.utility.Utils.saveArrayList;
import static com.app.utility.Utils.saveString;
import static com.app.utility.Utils.selectedStation;
import static com.app.utility.Constant.MM_Song_Info_Not_Found;
import static com.app.utility.Utils.setSongLabel;
import static com.app.utility.Utils.setStationLabel;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.graphics.Color;
import android.media.AudioManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Parcelable;
import android.support.v4.media.MediaBrowserCompat;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaControllerCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NavUtils;
import androidx.core.content.ContextCompat;

import com.android.DragDropList.DragSortListView;
import com.android.DragDropList.SimpleDragSortCursorAdapter;
import com.android.FirebaseAnalytics.AnalyticsConstants;
import com.android.Utility.Classes.ProgressIndicator;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.youtube.YoutubeListActivity;
import com.anjlab.android.iab.v3.PurchaseInfo;
import com.app.ads.BannerAdsUtil;
import com.app.ads.InterstitialAdManager;
import com.app.ads.InterstitialUtils;
import com.app.ads.interfaces.InterstitialDismissListener;
import com.app.auto.MediaBrowserHelper;

import com.app.auto.RMusicService;
import com.app.desiradio.MainActivity;
import com.app.desiradio.SplashScreenActivity;
import com.app.genre.ChangeStationListener;
import com.app.genre.ChannelItem;
import com.app.genre.ChannelListFragment;
import com.app.googleservices.purchase.InAppBillingManager;
import com.app.http.ConnectionDetector;
import com.app.parser.Channel;
import com.app.sqlite.DBHelper;
import com.app.utility.Constant;
import com.app.utility.Debugger;
import com.app.utility.Globals;
import com.app.utility.Utils;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import com.google.gson.Gson;
import com.indianradio.R;
import com.jakewharton.processphoenix.ProcessPhoenix;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


@SuppressLint("StaticFieldLeak")
public class RadioPlayerActivity extends AppCompatActivity implements OnSeekBarChangeListener, OnClickListener, OnItemClickListener, InterstitialDismissListener, ChangeStationListener {

    // Main Context
    static Globals globals;

    // ImageButtons
    public static ImageView btn_mute;
    public static ImageView btn_play, btn_next, btn_previous;

    //ImageView
    public static ImageView btn_record, btn_addToFavorite, btn_sharing, btn_youtube_video, btn_st_list;

    // ToolBar
    public static Toolbar toolbar;
    //public static ActionBar actionBar;

    // TextViews
    public static TextView stationNameLabel;
    public static TextView songNameLabel;
    public static TextView txt_timer;

    public static RadioPlayerActivity thisInstance;

    // Flags
    public static Boolean isTablet = false;
    public static Boolean isVisible = false;
    static Boolean isInFavorite = false;
    static Boolean isMute = false;
    static Boolean isPlayerAdOpen = false;
    private int requireAds = 0;
    public int startIndex = -99;

    // Context
    public static Context app;
    public static Context act;

    // Strings
    public static String TAG = "RadioPlayerActivity";
    public static final String mm_station_id = "_id";
    public static final String mm_station_name = "sName";
    public static String finalUrl;

    // ImageViews
    public static ImageView currentSongImage, backGroundImageArt;
    ImageView larAdCloseBtn, norAdCloseBtn, unifiedAdCloseBtn;

    // Lists
    static ArrayList<Channel> tempFevList;
    public static DragSortListView currentPlayingStationsList;

    // Adapters
    public static SimpleDragSortCursorAdapter dragAdapter;

    // Layouts
    public RelativeLayout imageLayout, stationListLayout, larAdLayout;
    public RelativeLayout unifiedAdLayout;
    public static LinearLayout centerLayout;
    // Buttons
    public TextView clearBtn, playListEditBtn;


    public Intent radioService;
    private AudioManager audio;
    private SeekBar vol_seekBar;
    int orientation;
    int tempPosition = -99;
    public static int resultCode;
    int requestCode = 2;

    static RadioPlayerActivity radioPlayerActivity;
    Animation animation;
    public Handler handler = new Handler();
    protected Configuration mPrevConfig;

    /**
     * android auto start
     */

    ImageView gifImg;
    public static RelativeLayout loaderLay;
    public static MediaBrowserHelper mMediaBrowserHelper;
    public static boolean mIsPlaying;
    String myStation;
    ProgressDialog progressDialog;
    public static ArrayList<Channel> selectedPlaylistChannel = new ArrayList<>();
    LinearLayout recording_layout;

    /**
     * android auto end
     */

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TAG = getClass().getName();
        RadioPlayerActivity.thisInstance = this;
        //   Thread.setDefaultUncaughtExceptionHandler(new UnCaughtException(RadioPlayerActivity.this));
        setContentView(R.layout.player_new_layout);

        try {
            mPrevConfig = new Configuration(getResources().getConfiguration());
        } catch (Exception ee) {
            Debugger.debugI(TAG, "onCreate -> error -> " + ee.getMessage());
        }

        // Initialize Home/Back button on toolBar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        radioPlayerActivity = this;



        try {
            globals = ((Globals) RadioPlayerActivity.this.getApplicationContext());
            app = getApplicationContext();
            act = RadioPlayerActivity.this;
        } catch (Exception ee) {
            Debugger.debugI(TAG, "context -> error -> " + ee.getMessage());
        }

        Debugger.debugI(TAG, " >>>>>>>>>>>>>>>>>>: total size of station array is " + PlaylistManager.getStationList().size() + " <<<<<<<<<<<<<<<<<<<<<<< ");

        selectedPlaylistChannel = PlaylistManager.getStationList();

        init();

        try {
            orientation = getApplicationContext().getResources().getConfiguration().orientation;
            isTablet = getResources().getBoolean(R.bool.isTablet);
            Debugger.debugI(TAG, "isTablet :" + isTablet);

            Bundle extras = getIntent().getExtras();
            if (extras != null && extras.getBoolean("is_playback_error"))
                globals.showCustomMessageOK(RadioPlayerActivity.this, Constant.MM_ALERT_TITLE_ERROR, Constant.MM_MSG_UNABLE_TO_PLAY, true);

            // Initialize Radio Service & start service
            globals.radioServiceActivity = this;
            try {
                radioService = new Intent(RadioPlayerActivity.this, RMusicService.class);
                if (!isMyServiceRunning(RadioPlayerActivity.this, RMusicService.class)) {
//                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//                        stopService(new Intent(RadioPlayerActivity.this, RMusicService.class));
//                        startForegroundService(radioService);
//                    } else {
                    startService(radioService);
//                    }
                }
            } catch (Exception e) {

            }

            Debugger.debugI(TAG, "GET INDEX :" + PlaylistManager.getCurrentIndex());
            registerReceiver(myBroadCast1, new IntentFilter(Intent.ACTION_SCREEN_OFF));

            Bundle bundle = new Bundle();
            bundle.putString(AnalyticsConstants.SCREEN_NAME, AnalyticsConstants.EC_player);
        } catch (Exception ee) {
            Debugger.debugI(TAG, "ON CREATE -> error -> " + ee.getMessage());
        }

        // here we check its call from actionbar or not
        if (!flgForPlayerOpen) {    //not call from actionbar
            setSongLabel(MM_Song_Info_Not_Found);
        } else {

            if (getAlbumUris() != null) {
                Glide.with(RadioPlayerActivity.this).load(getAlbumUris()).placeholder(R.drawable.player_img_view).into(currentSongImage);
            }
            if (getAlbumTitle() != null) {
                setSongLabel(getAlbumTitle());
            }
        }

        /** android auto start **/

        //  Establish connection
        mMediaBrowserHelper = new MediaBrowserConnection(this);

        //  MediaControllerCompatListener register
        mMediaBrowserHelper.registerCallback(new MediaBrowserListener());

        /** android auto end  **/

    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        try {
            configurationChanged(newConfig);
            mPrevConfig = new Configuration(newConfig);
        } catch (Exception ee) {
            Debugger.debugI(TAG, "onConfigurationChanged -> error -> " + ee.getMessage());
        }
    }

    protected void configurationChanged(Configuration newConfig) {
        try {
            if (Utils.getInt(this, "mode", 0) == 2)
                ProcessPhoenix.triggerRebirth(RadioPlayerActivity.this, new Intent(this, SplashScreenActivity.class));
        } catch (Exception ee) {
            Debugger.debugI(TAG, "configurationChanged -> error -> " + ee.getMessage());
        }

    }

    @Override
    public void updateAllPlayerData() {
        Debugger.debugI(TAG, " update all player data ");
        loadPlaylist();
    }

    public void playClick() {

        Debugger.debugD(TAG, " click of player play btn ");
        //change
        if (!checkIsRecording(Constant.MM_ActionID_StopPlaying)) {
            Debugger.debugD(TAG, " click of player play btn - if not recording ");

            if (ConnectionDetector.internetCheck(RadioPlayerActivity.this))
                if (globals.isPlayedFromSp()) {
                    Debugger.debugD(TAG, " click of player play btn - sharedpref ");

                    if (!mIsPlaying) {
                        Debugger.debugD(TAG, " click of player play btn - sharedpref - if ");
                        fetchStationURL(RadioPlayerActivity.this, getApplicationContext());
                        mMediaBrowserHelper.getTransportControls().play();

                    } else {
                        Debugger.debugD(TAG, " click of player play btn - sharedpref - else ");
                        RMusicService.play_stop_Event(globals, RadioPlayerActivity.this);
                        mMediaBrowserHelper.getTransportControls().stop();
                    }

                } else {
                    Debugger.debugD(TAG, " click of player play btn - not sharedpref ");
                    if (!mIsPlaying) {
                        Debugger.debugD(TAG, " click of player play btn - not sharedpref - if ");
                        fetchStationURL(RadioPlayerActivity.this, getApplicationContext());
                        mMediaBrowserHelper.getTransportControls().play();

                    } else {
                        Debugger.debugD(TAG, " click of player play btn - not sharedpref - else ");
                        RMusicService.play_stop_Event(globals, RadioPlayerActivity.this);
                        mMediaBrowserHelper.getTransportControls().stop();

                    }
                }
        }
        updateItemAtPosition();

    }

    public void nextClick() {
        try {
            if (!checkIsRecording(Constant.MM_ActionID_PlayNext))
                if (ConnectionDetector.internetCheck(RadioPlayerActivity.this)) {

                    Glide.with(RadioPlayerActivity.this).load(R.drawable.player_img_view).into(currentSongImage);
                    setSongLabel(MM_Song_Info_Not_Found);

                    /** android auto start **/
                    mMediaBrowserHelper.getTransportControls().skipToNext();
                    /** android auto end **/
                    updateItemAtPosition();
                }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void previousClick() {
        try {
            if (!checkIsRecording(Constant.MM_ActionID_PlayPrev))
                if (ConnectionDetector.internetCheck(RadioPlayerActivity.this)) {
                    Glide.with(RadioPlayerActivity.this).load(R.drawable.player_img_view).into(currentSongImage);
                    setSongLabel(MM_Song_Info_Not_Found);

                    /** android auto start **/
                    mMediaBrowserHelper.getTransportControls().skipToPrevious();
                    /** android auto end **/
                    updateItemAtPosition();
                }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /** android auto start **/

    /**
     * Customize the connection to our {@link .MediaBrowserServiceCompat}
     * and implement our app specific desires.
     */
    private class MediaBrowserConnection extends MediaBrowserHelper {
        private MediaBrowserConnection(Context context) {
            super(context, RMusicService.class);
            Debugger.debugI(TAG, "MediaBrowserConnection: ");
        }

        @Override
        protected void onConnected(@NonNull MediaControllerCompat mediaController) {
            //   mSeekBarAudio.setMediaController(mediaController);
            Debugger.debugI(TAG, "onConnected: ");
            Channel currentChannel = null;
            ArrayList<Channel> chArray = PlaylistManager.getStationList();
            if (chArray != null && chArray.size() > 0 && PlaylistManager.getCurrentIndex() >= 0)
                currentChannel = chArray.get(PlaylistManager.getCurrentIndex());

            if (currentChannel != null) {
                Debugger.debugI(TAG, "media connected url ---" + currentChannel.ChannelLink);
                Debugger.debugI(TAG, "ui selected station  --  " + selectedStation);
                //selectedStation = currentChannel;


                Bundle bundle = new Bundle();
//                    bundle.putString(currentChannel.ChannelId, selectedStation);
                bundle.putString(Constant.CHANNEL_DATA, new Gson().toJson(selectedStation));
                bundle.putString(Constant.CHANNEL_TYPE, PlaylistManager.getStationType());

                if (!currentChannel.ChannelId.equals("")) {
                    mediaController.getTransportControls().playFromMediaId(currentChannel.ChannelId, bundle);
                } else {
//                    int randomNumber = Utils.generateRandomNumber(1000, 9999);
                    mediaController.getTransportControls().playFromMediaId(selectedStation.ChannelId, bundle);
                }


//                String contents = PlaylistManager.getStationType() + "___" + new Gson().toJson(selectedStation);
//                mediaController.getTransportControls().playFromMediaId(contents, bundle);

            }

        }

        @Override
        protected void onDisconnected() {
            super.onDisconnected();
        }

        @Override
        protected void onChildrenLoaded(@NonNull String parentId,
                                        @NonNull List<MediaBrowserCompat.MediaItem> children) {
            super.onChildrenLoaded(parentId, children);
            Debugger.debugI(TAG, "onChildrenLoaded: dvs");

        }
    }

    /**
     * Implementation of the {@link MediaControllerCompat.Callback} methods we're interested in.
     * <p>
     * Here would also be where one could override
     * {@code onQueueChanged(List<MediaSessionCompat.QueueItem> queue)} to get informed when items
     * are added or removed from the queue. We don't do this here in order to keep the UI
     * simple.
     */
    private class MediaBrowserListener extends MediaControllerCompat.Callback {
        @Override
        public void onPlaybackStateChanged(PlaybackStateCompat playbackState) {

            mIsPlaying = playbackState != null &&
                    playbackState.getState() == PlaybackStateCompat.STATE_PLAYING;
            if (mIsPlaying) {
                if (btn_play != null) {
                    btn_play.setBackgroundResource(R.drawable.player_layout_stop_icon);
                }
                if (LockScreenPlayer.btn_play != null) {
                    LockScreenPlayer.btn_play.setBackgroundResource(R.drawable.player_layout_stop_icon);
                }
                if (MainActivity.ivPlayBottom != null) {
                    MainActivity.ivPlayBottom.setImageResource(R.drawable.player_layout_stop_icon);
                }

            } else {


                setSongLabel(MM_Song_Info_Not_Found);

                if (btn_play != null) {
                    btn_play.setBackgroundResource(R.drawable.player_layout_play_icon);
                }
                if (LockScreenPlayer.btn_play != null) {
                    LockScreenPlayer.btn_play.setBackgroundResource(R.drawable.player_layout_play_icon);
                }
                if (MainActivity.ivPlayBottom != null) {
                    MainActivity.ivPlayBottom.setImageResource(R.drawable.player_layout_play_icon);
                }
            }

        }

        @Override
        public void onMetadataChanged(MediaMetadataCompat mediaMetadata) {

            if (mediaMetadata == null) {
                return;
            }

        }

        @Override
        public void onSessionDestroyed() {
            super.onSessionDestroyed();
        }

        @Override
        public void onQueueChanged(List<MediaSessionCompat.QueueItem> queue) {
            super.onQueueChanged(queue);
        }
    }

    /**
     * android auto end
     **/


    public void init() {

        // Volume Controller
        audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        vol_seekBar = findViewById(R.id.volumeSeekbar);
        vol_seekBar.setMax(audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        vol_seekBar.setProgress(audio.getStreamVolume(AudioManager.STREAM_MUSIC));
        vol_seekBar.setOnSeekBarChangeListener(this);
        //vol_seekBar.getProgressDrawable().setColorFilter(Color.BLUE, PorterDuff.Mode.SRC_IN);

        // Drag & Drop, Edit ListView
        stationListLayout = findViewById(R.id.player_st_list_layout);
        gifImg = findViewById(R.id.gif_img);
        loaderLay = findViewById(R.id.loader_lay);
        progressDialog = new ProgressDialog(RadioPlayerActivity.this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Please wait...");
        // Close Buttons for playerView Ads
        norAdCloseBtn = findViewById(R.id.nor_ad_close_btn);
        recording_layout = findViewById(R.id.recording_layout);

        if (RECORDING_FLAG == 0){
            recording_layout.setVisibility(View.GONE);
        }

        // Native Express Ad Layout
        larAdLayout = findViewById(R.id.player_lar_native_ad_layout);

        //Unified layout

        unifiedAdLayout = (RelativeLayout) findViewById(R.id.player_unified_native_ad_layout);

        unifiedAdCloseBtn = findViewById(R.id.unified_ad_close_btn);

        larAdCloseBtn = findViewById(R.id.lar_ad_close_btn);

        // Album Image Layout
        centerLayout = findViewById(R.id.test_layout);
        imageLayout = findViewById(R.id.album_image_layout);

        stationNameLabel = findViewById(R.id.stationName);
        if (PlaylistManager.getStationList() != null && !PlaylistManager.getStationList().isEmpty() && PlaylistManager.getStationList().size() > 0) {

            if (PlaylistManager.getCurrentIndex() >= 0)
                setStationLabel(PlaylistManager.getStationList().get(PlaylistManager.getCurrentIndex()).ChannelTitle);

        }
        stationNameLabel.setSelected(true);

        songNameLabel = findViewById(R.id.songName);

        songNameLabel.setSelected(true);

        txt_timer = findViewById(R.id.timer_txt);
        txt_timer.setVisibility(View.INVISIBLE);

        // Drag and Drop StationListView
        currentPlayingStationsList = findViewById(R.id.stationListView);
        currentPlayingStationsList.setOnItemClickListener(this);
        currentPlayingStationsList.setDragEnabled(false);

        // Drag and Drop ListView Adapter
        dragAdapter = new MAdapter(RadioPlayerActivity.this, R.layout.station_list_item_edit_mode, null, 0);
        currentPlayingStationsList.setAdapter(dragAdapter);
        loadPlaylist();

        btn_play = findViewById(R.id.play_btn);
        btn_previous = findViewById(R.id.previous_btn);
        btn_next = findViewById(R.id.next_btn);
        btn_mute = findViewById(R.id.mute_btn);
        clearBtn = findViewById(R.id.clear_btn);
        playListEditBtn = findViewById(R.id.edit_btn);
        btn_addToFavorite = findViewById(R.id.addToFavorite_btn);
        btn_youtube_video = findViewById(R.id.youtube_video_btn);
        btn_record = findViewById(R.id.record_btn);
        btn_sharing = findViewById(R.id.sharing_btn);
        btn_st_list = findViewById(R.id.station_list_btn);
        currentSongImage = findViewById(R.id.album_art);
        backGroundImageArt = findViewById(R.id.img_art);

        btn_previous.setOnClickListener(this);
        btn_next.setOnClickListener(this);
        btn_play.setOnClickListener(this);
        btn_mute.setOnClickListener(this);
        clearBtn.setOnClickListener(this);
        playListEditBtn.setOnClickListener(this);
        currentSongImage.setOnClickListener(this);
        btn_addToFavorite.setOnClickListener(this);
        btn_youtube_video.setOnClickListener(this);
        btn_record.setOnClickListener(this);
        btn_sharing.setOnClickListener(this);
        btn_st_list.setOnClickListener(this);

        PlaylistManager.checkClear = 1;

        Glide.with(this).load(R.drawable.loading).into(gifImg);

        // to set volume seekBar last position
        if (vol_seekBar.getProgress() == 0) {

            if (isTablet) {
                btn_mute.setImageResource(R.drawable.player_tab_mute_icon);
            } else {
                btn_mute.setImageResource(R.drawable.player_layout_volume_mute_icon);
            }

        } else {

            if (isTablet) {
                btn_mute.setImageResource(R.drawable.player_tab_volume_up_icon);
            } else {
                btn_mute.setImageResource(R.drawable.player_layout_volume_up_icon);
            }
        }

        ChanceUIonRunTime();
        initiatePlayer();
    }

    // BroadCast for while screen off
    BroadcastReceiver myBroadCast1 = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction() != null &&
                    intent.getAction().equals(Intent.ACTION_SCREEN_OFF)) {
                Debugger.debugI(TAG, "RadioPlayerActivity Screen OFF");

                if (PlaylistManager.isPlaying())
                    RadioPlayerActivity.this.finish();
            }
        }
    };


    @Override
    protected void onResume() {
        super.onResume();
        Globals.activityResumed();

        Debugger.debugI(TAG, "on resume called");
        isVisible = true;
        globals.radioServiceActivity = RadioPlayerActivity.this;
        BannerAdsUtil.showBannerAd(this, findViewById(R.id.adContainer));

        //  loadPlaylist();
        ChanceUIonRunTime();
        if (Utils.isPLAY && RMusicService.currentPlayingName != null) {

            setSongLabel(RMusicService.currentPlayingName);
            if (getAlbumUris() != null && getAlbumUris().length() > 0) {
                Glide.with(this).load(getAlbumUris()).placeholder(R.drawable.player_img_view).into(currentSongImage);
            } else {
                Glide.with(this).load(R.drawable.player_img_view).into(currentSongImage);
            }
        }

        if (PlaylistManager.getPlayingURL() != null) {
            try {
                if (!Utils.isMyServiceRunning(RadioPlayerActivity.this, RMusicService.class)) {
//                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//                        stopService(new Intent(RadioPlayerActivity.this, RMusicService.class));
//                        startForegroundService(radioService);
//                    } else {
                    startService(radioService);
//                    }

                }
            } catch (Exception e) {

            }
        }

    }

    @Override
    protected void onPause() {
        super.onPause();
        isVisible = false;
        Globals.activityPaused();
    }

    private final Runnable playerRunnable = new Runnable() {
        @Override
        public void run() {
            // Play station after delayed.
            try {

                Context context = RadioPlayerActivity.this;
                Globals globals1 = (Globals) context.getApplicationContext();

                if (globals1 == null) {

                    globals1 = (Globals) context.getApplicationContext();
                }

                if (context == null) {

                    context = getApplicationContext();
                }

                RMusicService.playStation(globals1, context);    //  crash occur due to null object reference

            } catch (Exception ee) {
                Debugger.debugI(TAG, "run: " + ee.getMessage());
                Context context = RadioPlayerActivity.this;
                RMusicService.playStation(((Globals) context.getApplicationContext()), RadioPlayerActivity.thisInstance);    //  crash occur due to null object reference
            }
        }
    };

    public void initiatePlayer() {
        try {
            if (PlaylistManager.isIntentFromActivty()) {
                PlaylistManager.setIsIntentFromActivty(false);
            }
            fetchStationURL(RadioPlayerActivity.this, getApplicationContext());

        } catch (Exception ee) {
            Debugger.debugI(TAG, "initiatePlayer -> error -> " + ee.getMessage());
        }
    }

    /**
     * To set playing button in different state as its playing or buffering or stopped
     * To check orientation before 1st time activity go start
     * To check whether it is playing intent or just Visiting player while its already being played
     **/
    private void ChanceUIonRunTime() {

        try {
            setRecordBtnState();
            UpdateFavBtnView(RadioPlayerActivity.this);
        } catch (Exception ee) {
            Debugger.debugI(TAG, "ChanceUIonRunTime -> error -> " + ee.getMessage());
        }
    }

    public void setRecordBtnState() {
        try {
            if (isTablet) {
                btn_record.setImageResource((PlaylistManager.isRecording()) ? R.drawable.player_tab_recording_icon : R.drawable.player_tab_record_icon);
            } else {
                btn_record.setImageResource((PlaylistManager.isRecording()) ? R.drawable.player_layout_recording_icon : R.drawable.player_layout_record_icon);
            }
        } catch (Exception ee) {
            Debugger.debugI(TAG, "setRecordBtnState -> error -> " + ee.getMessage());
        }

    }

    // Fetch Current Station's URL for streaming
    public static void fetchStationURL(Context ActivityContext, Context ApplicationContext) {

        try {

            Debugger.debugD(TAG, "fetch station url");
            ArrayList<Channel> allSelectedList = PlaylistManager.getStationList();
            int myIndex = PlaylistManager.getCurrentIndex();

            if (allSelectedList != null && allSelectedList.size() != 0) {
                Debugger.debugD(TAG, "fetch station url -  if");

                {
                    if (ConnectionDetector.internetCheck(ApplicationContext)) {
                        if (RadioPlayerActivity.isVisible) {
                            UpdateFavBtnView(ActivityContext);
                        }

                        Debugger.debugI(TAG, "STATION INDEX :" + myIndex);
                        PlaylistManager.setPlayingChannel(allSelectedList.get(myIndex));

                        selectedStation = allSelectedList.get(myIndex);
                        globals.radioServiceActivity = (Activity) ActivityContext;

                        thisInstance.handler.postDelayed(thisInstance.playerRunnable, 100);
                    }
                }

            } else {
                Debugger.debugD(TAG, "fetch station url -  else");
                Utils.showToast(ActivityContext, "Station list is empty, Try again");
            }

        } catch (Exception ee) {
            Debugger.debugD(TAG, "fetch station url -  error");
        }
        Debugger.debugD(TAG, "from fetchStation");

    }

    // load current stationList's data
    public static void loadPlaylist() {

        try {
            ArrayList<Channel> allChannelData = PlaylistManager.getStationList();
            Debugger.debugI(TAG, " LIST LOADED ");
            int Count = allChannelData.size();
            if (allChannelData != null && !allChannelData.isEmpty() && Count > 0) {
                try {
                    setStationLabel(allChannelData.get(PlaylistManager.getCurrentIndex()).ChannelTitle);

                } catch (Exception e) {
                    Debugger.debugI(TAG, " error - > " + e.getMessage());
                }
            }

            if (Count > 0) {
                Debugger.debugI(TAG, "RadioPlayer load Playlist if part");
                String[] columnNames = {mm_station_id, mm_station_name};
                MatrixCursor cursor = new MatrixCursor(columnNames);
                String[] temp = new String[2];

                for (int i = 0; i < Count; i++) {
                    temp[0] = Integer.toString(i);
                    temp[1] = allChannelData.get(i).ChannelTitle;
                    cursor.addRow(temp);
                }
                //      Utils.saveArrayList(globals.getApplicationContext(),allChannelData ,"lastPlayedArray");
                if (dragAdapter != null) {
                    dragAdapter.swapCursor(cursor);

                    Debugger.debugE(TAG, "after remove current song position is "+PlaylistManager.getCurrentIndex());

                    currentPlayingStationsList.setSelection(PlaylistManager.getCurrentIndex());
//                    mStationArrayList.clear();
//                    mStationArrayList.addAll(allChannelData);
                    dragAdapter.notifyDataSetChanged();
                }
            } else {
                Debugger.debugI(TAG, "RadioPlayer load Playlist else part");
                Channel channel = PlaylistManager.getPlayingChannel();
                int pos = Utils.getMediaPosition(channel.toJsonData());
                PlaylistManager.setCurrentIndex(pos);
            }
        } catch (Exception ee) {
            Debugger.debugI(TAG, "Error --> " + ee.getMessage());
        }
    }

    // onClick from Drag & Drop List
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {


        if (ConnectionDetector.internetCheck(RadioPlayerActivity.this)) {
            if (position != PlaylistManager.getCurrentIndex()) {
                Bundle bundle = new Bundle();
                bundle.putString(AnalyticsConstants.EVENT_CATEGORY, AnalyticsConstants.EC_player);
                try {
                    if (progressDialog != null) {
                        progressDialog.show();
                    }

                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                if (progressDialog != null) {
                                    progressDialog.dismiss();
                                }
                            } catch (Exception e) {

                            }
                        }
                    }, 2000);
                    Debugger.debugI(TAG, "Drag list item click try statement");
                    bundle.putString(AnalyticsConstants.SELECT_STATION_NAME, PlaylistManager.getStationList().get(position).ChannelTitle);
                    boolean isNeedToPlayStation = PlaylistManager.isIntentFromActivity(PlaylistManager.getStationList().get(position)) || !PlaylistManager.isPlaying();
                    if (isNeedToPlayStation) {
                        Debugger.debugI(TAG, "Drag list item click isNeedToPlayStation");
                        if (!checkIsRecording(Constant.MM_ActionID_onClickPLStation)) {
                            Debugger.debugI(TAG, "PART 1");
                            //not call from actionbar

                            setSongLabel(MM_Song_Info_Not_Found);

                            Bundle bundle1 = new Bundle();
//                            bundle1.putString(mStationArrayList.get(position).ChannelId,mStationArrayList.get(position).toJsonData());
                            bundle1.putString(Constant.CHANNEL_DATA, new Gson().toJson(mStationArrayList.get(position)));
                            bundle1.putString(Constant.CHANNEL_TYPE, PlaylistManager.getStationType());
                            mMediaBrowserHelper.getTransportControls().playFromMediaId(mStationArrayList.get(position).ChannelId, bundle1);
                            setStationLabel(mStationArrayList.get(position).ChannelTitle);

                            ((Globals) getApplicationContext()).AddStationToHistory(RadioPlayerActivity.this, mStationArrayList.get(position));
                            // UpdateStationWithSongName(RadioPlayerActivity.this, position);

                        } else {
                            Debugger.debugI(TAG, "PART 2");
                            tempPosition = position;
                        }
                    } else {
                        Debugger.debugI(TAG, "PART 3");
                        PlaylistManager.setCurrentIndex(position);
                        if (!checkIsRecording(Constant.MM_ActionID_onClickPLStation)) {

                            playNow(RadioPlayerActivity.this, globals.getApplicationContext());
                            //to update history even if same station is playing.
                            Channel currentChannel = PlaylistManager.getStationList().get(PlaylistManager.getCurrentIndex());
                            //currentChannel.put("last_played_date", Long.toString(System.currentTimeMillis()));
                            currentChannel.lastPlayedDate = System.currentTimeMillis();
                            selectedStation = currentChannel;
                            ((Globals) getApplicationContext()).AddStationToHistory(RadioPlayerActivity.this, currentChannel);
                        }
                    }
                    updateItemAtPosition();
                } catch (Exception e) {
                    Debugger.debugI(TAG, "Error »»»» " + e.getMessage());
                }

            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.timer_view, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
            return true;
        }

        if (id == R.id.timer_icon) {
            RMusicService.ShowTimePicker(this, getApplicationContext());
        }
        return true;
    }

    public static void playNow(Context ActivityContext, Context ApplicationContext) {
        if (!PlaylistManager.getStationList().isEmpty() && PlaylistManager.getStationList().size() > 0)
            setStationLabel(PlaylistManager.getStationList().get(PlaylistManager.getCurrentIndex()).ChannelTitle);

        Context context = RadioPlayerActivity.radioPlayerActivity.getApplicationContext();
        RMusicService.currentPlayingName = context.getString(R.string.song_info_not_found);
        setSongLabel(RMusicService.currentPlayingName);

        fetchStationURL(ActivityContext, ApplicationContext);

        updateItemAtPosition();
        globals.setLastPlayedIndex(PlaylistManager.getCurrentIndex());
    }

    public static void updateItemAtPosition() {
        Debugger.debugI(TAG, " Notify Adapter ");
        try {
            if (dragAdapter != null)
                dragAdapter.notifyDataSetChanged();
        } catch (Exception ee) {
            Debugger.debugI(TAG, "updateItemAtPosition -> error  -> " + ee.getMessage());
        }
    }

    // show Record Dialog
    public void showRecordDialog(String pTitle, final String pMsg) {

        AlertDialog.Builder builder = new AlertDialog.Builder(RadioPlayerActivity.this);
        builder.setTitle(pTitle)
                .setMessage(pMsg)
                .setIcon(R.mipmap.ic_launcher)
                .setPositiveButton("Record Now", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        doStartRecording();
                    }
                })
                .setNegativeButton("Purchase", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Bundle bundle = new Bundle();
                        bundle.putString(AnalyticsConstants.EVENT_CATEGORY, AnalyticsConstants.EC_player);
                        //  performPurchase(Constant.PurchaseType.PremiumRecording);
                        if (ConnectionDetector.internetCheck(RadioPlayerActivity.this)) {
                            purchase(Constant.SKU_PremiumRecording);
                        }
                    }
                });

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    public void purchase(String productId) {

        try {
            InAppBillingManager inAppBillingManager = InAppBillingManager.getSharedInstance();
            inAppBillingManager.purchase(RadioPlayerActivity.this, productId, new InAppBillingManager.IInAppBillingPurchaseListener() {
                @Override
                public void onPurchaseSuccess(String sku, PurchaseInfo purchaseInfo) {
                    Debugger.debugI(TAG, "productID -- " + sku);
                    Debugger.debugI(TAG, "Info -- " + purchaseInfo.toString());

                    if (purchaseInfo != null) {
                        Debugger.debugI(TAG, "getInfo success");

                        if (sku.equalsIgnoreCase(Constant.SKU_PremiumRecording)) {

                            globals.setMaxRecordingTime(30);
                            globals.showCustomMessageOK(RadioPlayerActivity.this, getString(R.string.app_name) + "!", "Congratulations! You have successfully Owned to \"Premium Recording\"", false);

                        }

                    }

                }

                @Override
                public void onPurchaseFailed(String sku, InAppBillingManager.InAppBillingError errorCode, String error) {
                    Debugger.debugI(TAG, "onPurchaseFailed: " + error);
                }
            });
        } catch (Exception ee) {
            Debugger.debugI(TAG, ee.getMessage());
        }
    }

    // startRecording Thread method
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    public void doStartRecording() {
        try {
            if (mIsPlaying) {

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                            && ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                            && ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                        RMusicService.startRecordingThread();
                    else
                        ActivityCompat.requestPermissions(RadioPlayerActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.RECORD_AUDIO}, 1);
                } else {
                    Debugger.debugI(TAG, "Start Recording thread...");
                    RMusicService.startRecordingThread();
                }

            } else {
                globals.showCustomMessageOK(RadioPlayerActivity.this, getString(R.string.app_name), Constant.MM_CANT_RECORD_BEFOR_PLAY_ALERT, true);
            }
        } catch (Exception ee) {
            Debugger.debugI(TAG, "error :" + ee.getMessage());
        }

    }

    // permission for API Level >= 5.0
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 1: {

                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    RMusicService.startRecordingThread();
                    // permission was granted, yay! Do the contacts-related task you need to do.
                } else {

                    // permission denied, boo! Disable the functionality that depends on this permission.
                    Utils.showToast(RadioPlayerActivity.this, "Permission denied to read/write your External storage");
                }
                //return;
            }
        }
    }

    public static void setPlayButtonIcon(Context context, int resourceId) {
        if (btn_play != null) {
            btn_play.setBackgroundResource(resourceId);
        }
        if (LockScreenPlayer.btn_play != null) {
            LockScreenPlayer.btn_play.setBackgroundResource(resourceId);
        }
        if (MainActivity.ivPlayBottom != null) {
            MainActivity.ivPlayBottom.setImageResource(resourceId);
        }

    }

    public void openInterruptActivity(Bundle bundle) {
        // Start the activity whose result we want to retrieve.
        // The result will come back with request code GET_CODE.
        Intent intent = new Intent(RadioPlayerActivity.this, showRecordingInterruptDialogActivity.class);
        intent.putExtras(bundle);
//        startActivityForResult(intent, requestCode);
        someActivityResultLauncher.launch(intent);
    }

    ActivityResultLauncher<Intent> someActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        // There are no request codes
                        Intent data = result.getData();
                        switch (data.getIntExtra("actionID", 0)) {
                            case Constant.MM_ActionID_StopPlaying:
                                if (ConnectionDetector.internetCheck(RadioPlayerActivity.this))
                                    RMusicService.play_stop_Event(globals, RadioPlayerActivity.this);
                                RMusicService.changePlayerStopLayout(RadioPlayerActivity.this);
                                mMediaBrowserHelper.getTransportControls().stop();
                                break;
                            case Constant.MM_ActionID_PlayPrev:
                                globals.radioServiceActivity = RadioPlayerActivity.this;
                                RMusicService.stopStation(RadioPlayerActivity.this);

                                if (ConnectionDetector.internetCheck(RadioPlayerActivity.this))
                                    PlayPrevious(RadioPlayerActivity.this, getApplicationContext());
                                break;

                            case Constant.MM_ActionID_PlayNext:
                                globals.radioServiceActivity = RadioPlayerActivity.this;
                                RMusicService.stopStation(RadioPlayerActivity.this);
                                if (ConnectionDetector.internetCheck(RadioPlayerActivity.this))
                                    PlayNext(RadioPlayerActivity.this, getApplicationContext());
                                break;

                            case Constant.MM_ActionID_Clear:
                                globals.radioServiceActivity = RadioPlayerActivity.this;
                                RMusicService.stopStation(RadioPlayerActivity.this);
                                Exit();
                                break;

                            case Constant.MM_ActionID_onClickPLStation:
                                globals.radioServiceActivity = RadioPlayerActivity.this;
                                RMusicService.stopStation(RadioPlayerActivity.this);

                                if (tempPosition != -99)
                                    PlaylistManager.setCurrentIndex(tempPosition);
                                playNow(RadioPlayerActivity.this, globals.getApplicationContext());
                                break;

                            default:
                                break;
                        }
                    }
                }
            });

    //check recording is ON or OFF
    public boolean checkIsRecording(int actionCode) {
        Debugger.debugI(TAG, "~~~~~~~~~~~~~ checkIsRecording ~~~~~~~~~~");

        try {
            if (PlaylistManager.isRecording()) {
                Bundle bundle = new Bundle();
                bundle.putInt("actionID", actionCode);
                openInterruptActivity(bundle);
                return true;
            } else {
                return false;
            }
        } catch (Exception ee) {
            Debugger.debugI(TAG, "checkIsRecording ->  error -> " + ee.getMessage());
            return false;
        }

    }

    // onClick from buttons of playerView
    @Override
    public void onClick(View view) {

        switch (view.getId()) {

            case R.id.album_art:
                flipImage();
                flipListIcon();
                break;

            case R.id.station_list_btn:
                flipListIcon();
                break;

            case R.id.edit_btn:
                editPlaylist();
                break;

            case R.id.play_btn:

                playClick();

                break;

            case R.id.previous_btn:
                if (progressDialog != null) {
                    progressDialog.show();
                }
                previousClick();

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (progressDialog != null) {
                            progressDialog.dismiss();
                        }
                    }
                }, 1000);
                break;

            case R.id.next_btn:
                if (progressDialog != null) {
                    progressDialog.show();
                }

                nextClick();

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (progressDialog != null) {
                            progressDialog.dismiss();
                        }
                    }
                }, 1000);

                break;

            case R.id.clear_btn:

                clickOFClear();

                break;

            case R.id.record_btn:

                if (RMusicService.mPlayback.isPlaying()) {

                    Bundle bundle = new Bundle();
                    bundle.putString(AnalyticsConstants.EVENT_CATEGORY, AnalyticsConstants.EC_player);
                    if (PlaylistManager.getStationList() == null || PlaylistManager.getStationList().size() <= 0) {
                        bundle.putString("recording_st_name", mStationArrayList.get(PlaylistManager.getCurrentIndex()).ChannelTitle);
                    } else {
                        bundle.putString("recording_st_name", PlaylistManager.getStationList().get(PlaylistManager.getCurrentIndex()).ChannelTitle);
                    }

                    if (!PlaylistManager.isRecording()) {

                        if (globals.getMaxRecordingTime() == 1) {
                            if (DBHelper.getDBHelper(RadioPlayerActivity.this).getRecordingCount() < Constant.maxRecordingCount) {
                                showRecordDialog(getString(R.string.app_name) + "!", Constant.MM_LITE_VERSION_ALERT);
                            } else {
                                recordingPurchaseDialog(getString(R.string.app_name) + "!", Constant.MM_PURCHASE_RECORDING_ALERT);
                            }
                        } else {
                            doStartRecording();
                        }

                    } else {
                        //To immediately stop recording
                        RMusicService.stopRecording(RadioPlayerActivity.this);
                    }
                } else {
                    Utils.showToast(RadioPlayerActivity.this, Constant.MM_CANT_RECORD_BEFOR_PLAY_ALERT);
                }
                break;

            case R.id.addToFavorite_btn:
                // AddToFavorites();
                mMediaBrowserHelper.getTransportControls().sendCustomAction("toggle_favorite", null);

                break;

            case R.id.youtube_video_btn:
                if (ConnectionDetector.internetCheck(RadioPlayerActivity.this))
                    clickCommonForAll(RadioPlayerActivity.this, 421422);

                break;

            case R.id.sharing_btn:
                Bundle bundle1 = new Bundle();
                bundle1.putString(AnalyticsConstants.EVENT_CATEGORY, AnalyticsConstants.EC_player);
                bundle1.putString("sharing_st_name", PlaylistManager.getStationList().get(PlaylistManager.getCurrentIndex()).ChannelTitle);
                if (ConnectionDetector.internetCheck(RadioPlayerActivity.this)) {
                    String message = "I am listening \""
                            + (PlaylistManager.getStationList().get(PlaylistManager.getCurrentIndex())).ChannelTitle
                            + "...\" on " + getResources().getString(R.string.app_name) + " mobile app."
                            + "\n\n" + Constant.MM_IOS_APP + Constant.Link_IOS
                            + "\n" + Constant.MM_ANDROID_APP + Constant.Link_Android + getPackageName();


                    Intent sharingIntent = new Intent(Intent.ACTION_SEND);
                    sharingIntent.setType("text/plain");
                    sharingIntent.putExtra(Intent.EXTRA_TEXT, message);
                    startActivity(Intent.createChooser(sharingIntent, "Share using"));

                }
                break;

            case R.id.mute_btn:

                if (isMute) {

                    isMute = false;
                    audio.setStreamVolume(AudioManager.STREAM_MUSIC, vol_seekBar.getProgress(), 1);

                    if (isTablet) {
                        btn_mute.setImageResource(R.drawable.player_tab_volume_up_icon);
                    } else {
                        btn_mute.setImageResource(R.drawable.player_layout_volume_up_icon);
                    }
                    vol_seekBar.getProgress();

                } else {

                    isMute = true;
                    audio.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0);
                    if (isTablet) {
                        btn_mute.setImageResource(R.drawable.player_tab_mute_icon);
                    } else {
                        btn_mute.setImageResource(R.drawable.player_layout_volume_mute_icon);
                    }
                    vol_seekBar.getProgress();

                }

                break;
        }
    }

    private void clickOFClear() {
        if (PlaylistManager.isRecording()) {
            Utils.showToast(RadioPlayerActivity.this, "Please stop recording before clear Playlist");
        } else {
            // if (!checkIsRecording(Constant.MM_ActionID_Clear))

            try {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Exit();

                        PlaylistManager.checkClear = 0;
                        mStationArrayList = null;
                        mStationArrayList = new ArrayList<>();
                        selectedStation = null;
                        saveArrayList(RadioPlayerActivity.this, mStationArrayList, "lastPlayedArray");
                        saveString(RadioPlayerActivity.this, "lastStation", null);
                        if (MainActivity.tvStationBottom != null) {
                            MainActivity.tvStationBottom.setText(Constant.MM_DEFAULT_TEXT_WHEN_CLEAR);
                            MainActivity.tvSongBottom.setText(MM_Song_Info_Not_Found);
                        }
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (loaderLay != null) {
                loaderLay.setVisibility(View.GONE);
            }

        }
    }

    public void processAfterAd(Context context, int buttonId) {

        if (buttonId == 772666) {
            NavUtils.navigateUpTo(this, new Intent(this, ChannelListFragment.class));
        } else if (buttonId == 421422) {
            StartYoutubeActivity();
        }

    }

    public void clickCommonForAll(Activity activity, int buttonID) {

        if (InterstitialAdManager.getInstance().showInterstitial(activity) && InterstitialUtils.getInstance().interstitialAd != null) {
            InterstitialUtils.getInstance().displayInterstitialAd(RadioPlayerActivity.this, RadioPlayerActivity.this, buttonID);
        } else {
            processAfterAd(activity, buttonID);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        clickCommonForAll(this, 772666);
    }

    @Override
    public void onInterstitialDismissListener(Activity activity, int ButtonId) {
        processAfterAd(activity, ButtonId);
    }

    // Flip ImageView Method
    private void flipImage() {
        View imageLayout = findViewById(R.id.album_art);
        View playListLayout = findViewById(R.id.player_st_list_layout);
        View centerLayout = findViewById(R.id.album_image_layout);
        FlipAnimation flipAnimation = new FlipAnimation(imageLayout, playListLayout);
        if (imageLayout.getVisibility() == View.GONE) {
            flipAnimation.reverse();
        }
        centerLayout.startAnimation(flipAnimation);
    }

    // Flip StationList Icon
    private void flipListIcon() {
        View StListIcon = findViewById(R.id.station_list_btn);
        FlipAnimation flipAnimation = new FlipAnimation(StListIcon, StListIcon);
        if (StListIcon.getVisibility() == View.VISIBLE)
            flipAnimation.reverse();
        //if (!isPlayerAdOpen) {
        flipImage();
        //}
        StListIcon.startAnimation(flipAnimation);
    }

    // Display Current Playing Song Image
    public static void getName(final String s) {

        try {
            if (s != null) {
                if (!s.equals("") && s.length() > 3) {
                    String fullSongName = s.trim().replaceAll(" |-", "+");
                    fullSongName = fullSongName.trim().replaceAll("(\\d)", "");
                    String s1[] = s.trim().split("-");
                    String songName = s1[0];
                    songName = songName.trim().replaceAll(" ", "+");

                    final String url = Constant.SONG_ALBUM_ART_SEARCH_URL.replace("stxt", fullSongName);
                    final String newUrl = Constant.SONG_ALBUM_ART_SEARCH_URL.replace("stxt", songName);

                    final StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            Debugger.debugI(TAG, "url : " + url);

                            try {
                                JSONObject jsonObject = new JSONObject(response.trim());
                                resultCode = Integer.parseInt(jsonObject.getString(Constant.MM_RESULT_COUNT));
                                Debugger.debugI(TAG, String.valueOf(resultCode));
                                JSONArray jsonArray = jsonObject.getJSONArray(Constant.MM_API_DATA);

                                if (resultCode == 0 && jsonArray.length() == 0) {
                                    StringRequest request1 = new StringRequest(Request.Method.GET, newUrl, new Response.Listener<String>() {
                                        @Override
                                        public void onResponse(String response) {

                                            Debugger.debugI(TAG, "new url : " + newUrl);
                                            //Debugger.debugI(TAG, Constant.MM_RESPONSE + response);

                                            Context context = RadioPlayerActivity.radioPlayerActivity.getApplicationContext();
                                            try {
                                                JSONObject jsonObject = new JSONObject(response.trim());
                                                resultCode = Integer.parseInt(jsonObject.getString(Constant.MM_RESULT_COUNT));
                                                Debugger.debugI(TAG, String.valueOf(resultCode));
                                                JSONArray jsonArray = jsonObject.getJSONArray(Constant.MM_API_DATA);


                                                if (resultCode == 0 && jsonArray.length() == 0 || s.equals(MM_Song_Info_Not_Found)) {

                                                    Glide.with(context)
                                                            .load(R.drawable.bg_blur)
                                                            .diskCacheStrategy(DiskCacheStrategy.DATA)
                                                            .into(backGroundImageArt);

                                                } else {

                                                    JSONObject object = jsonArray.getJSONObject(0);
                                                    String songName = object.getString(Constant.SONG_NAME_URL);
                                                    Debugger.debugI(TAG, "SongName : " + songName);

                                                    String imgUrl = object.getString(Constant.MM_ARTWORKURL100);
                                                    //Debugger.debugI(TAG, "ImgUrl : " + imgUrl);
                                                    String newImgUrl = imgUrl.substring(0, imgUrl.length() - 13);
                                                    //Debugger.debugI(TAG, "NewImgUrl : " + newImgUrl);
                                                    finalUrl = newImgUrl.concat("400x400bb.jpg");
                                                    Debugger.debugI(TAG, "FinalImgUrl : " + finalUrl);

                                                    Glide.with(context)
                                                            .load(R.drawable.bg_blur)

                                                            .diskCacheStrategy(DiskCacheStrategy.DATA)
                                                            .into(backGroundImageArt);
                                                }

                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                            }

                                        }
                                    }, new Response.ErrorListener() {
                                        @Override
                                        public void onErrorResponse(VolleyError error) {

                                        }
                                    });
                                    globals.addToRequestQueue(request1);

                                } else {

                                    JSONObject object = jsonArray.getJSONObject(0);
                                    String songName = object.getString(Constant.SONG_NAME_URL);
                                    Debugger.debugI(TAG, "SongName : " + songName);
                                    String imgUrl = object.getString(Constant.MM_ARTWORKURL100);
                                    //Debugger.debugI(TAG, "ImgUrl : " + imgUrl);
                                    String newImgUrl = imgUrl.substring(0, imgUrl.length() - 13);
                                    //Debugger.debugI(TAG, "NewImgUrl : "+newImgUrl);
                                    finalUrl = newImgUrl.concat("400x400bb.jpg");
                                    Debugger.debugI(TAG, "FinalImgUrl : " + finalUrl);
                                    Context context = RadioPlayerActivity.radioPlayerActivity.getApplicationContext();

                                }

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                        }
                    });
                    globals.addToRequestQueue(stringRequest);
                }
            }
        } catch (Exception ee) {
            Debugger.debugI(TAG, "getName -> error  -> " + ee.getMessage());
        }
    }

    // onClick of youTube Button
    private void StartYoutubeActivity() {
        if (!RMusicService.currentPlayingName.equalsIgnoreCase("") && !RMusicService.currentPlayingName.equalsIgnoreCase(getString(R.string.song_info_not_found))) {
            Bundle bundle = new Bundle();
            bundle.putString(AnalyticsConstants.EVENT_CATEGORY, AnalyticsConstants.EC_player);
            bundle.putString("current_playing_name", RMusicService.currentPlayingName);
            Intent youtube = new Intent(RadioPlayerActivity.this, YoutubeListActivity.class);
            startActivity(youtube);
        } else {
            Utils.showToast(RadioPlayerActivity.this, Constant.MM_Song_Name_Required);
        }
    }

    // for adding favorites
    private void AddToFavorites() {

        try {
            tempFevList = ((Globals) getApplicationContext()).fetchFavoriteList(RadioPlayerActivity.this);
            int index = favoriteIndex(tempFevList);

            // check is already favourite or not
            if (isInFavorite) {
                // remove from favourite
                isInFavorite = false;

                if (isTablet) {
                    btn_addToFavorite.setImageResource(R.drawable.player_tab_favorite_icon);
                } else {
                    btn_addToFavorite.setImageResource(R.drawable.player_layout_favorite_icon);
                }
                //  onFavouriteUpdateClick(R.drawable.player_layout_favorite_icon);

                ProgressIndicator.showCustomMessageOK(RadioPlayerActivity.this, this.getString(R.string.app_name), Constant.favorite_remove_success);

                if (index != -99) {
                    tempFevList.remove(index);
                    Bundle bundle = new Bundle();
                    bundle.putString(AnalyticsConstants.EVENT_CATEGORY, AnalyticsConstants.EC_player);
                    bundle.putString("remove_fav", PlaylistManager.getStationList().get(PlaylistManager.getCurrentIndex()).ChannelTitle);
                }
                ((Globals) getApplicationContext()).saveFavoriteList(RadioPlayerActivity.this, tempFevList);
            } else {
                // add to favourite
                isInFavorite = true;

                if (isTablet) {
                    btn_addToFavorite.setImageResource(R.drawable.player_tab_added_favorites_icon);
                } else {
                    btn_addToFavorite.setImageResource(R.drawable.player_layout_favorite_added_icon);
                }
                //  onFavouriteUpdateClick(R.drawable.player_layout_favorite_added_icon);

                ProgressIndicator.showCustomMessageOK(RadioPlayerActivity.this, this.getString(R.string.app_name), Constant.favorite_add_success);

                if (index == -99) {
                    tempFevList.add(PlaylistManager.getStationList().get(PlaylistManager.getCurrentIndex()));

                    Bundle bundle = new Bundle();
                    bundle.putString(AnalyticsConstants.EVENT_CATEGORY, AnalyticsConstants.EC_player);
                    bundle.putString("add_fav", PlaylistManager.getStationList().get(PlaylistManager.getCurrentIndex()).ChannelTitle);
                }
                ((Globals) getApplicationContext()).saveFavoriteList(RadioPlayerActivity.this, tempFevList);
            }

        } catch (Exception ee) {
            Debugger.debugI(TAG, "AddToFavorites -> error -> " + ee.getMessage());
        }
    }

    public void recordingPurchaseDialog(String pTitle, final String pMsg) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(RadioPlayerActivity.this);
        builder.setCancelable(true);
        builder.setTitle(pTitle);
        builder.setMessage(pMsg);
        builder.setIcon(R.drawable.alert_icon);
        builder.setNegativeButton("Not Now", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        builder.setPositiveButton("Purchase Now",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        if (ConnectionDetector.internetCheck(RadioPlayerActivity.this)) {
                            Bundle bundle = new Bundle();
                            bundle.putString(AnalyticsConstants.EVENT_CATEGORY, AnalyticsConstants.EC_player);
                            //	performPurchase(Constant.PurchaseType.PremiumRecording);
                            if (ConnectionDetector.internetCheck(RadioPlayerActivity.this)) {
                                purchase(Constant.SKU_PremiumRecording);
                            }
                        }
                    }
                });

        AlertDialog alert = builder.create();
        alert.show();
    }

    public static void UpdateFavBtnView(Context activityContext) {

        try {

            String cid = PlaylistManager.getStationList().get(PlaylistManager.getCurrentIndex()).ChannelId;

            if (btn_addToFavorite != null) {
                if (cid == null || cid.isEmpty() || cid.equalsIgnoreCase("")) {
                    btn_addToFavorite.setVisibility(View.INVISIBLE);
                    btn_addToFavorite.setEnabled(false);
                } else {
                    btn_addToFavorite.setVisibility(View.VISIBLE);
                    btn_addToFavorite.setEnabled(true);

                    tempFevList = ((Globals) activityContext.getApplicationContext()).fetchFavoriteList(activityContext);
                    int index = favoriteIndex(tempFevList);
                    if (index != -99) {

                        if (isTablet) {
                            btn_addToFavorite.setImageResource(R.drawable.player_tab_added_favorites_icon);
                        } else {
                            btn_addToFavorite.setImageResource(R.drawable.player_layout_favorite_added_icon);
                        }
                        isInFavorite = true;

                    } else {

                        if (isTablet) {
                            btn_addToFavorite.setImageResource(R.drawable.player_tab_favorite_icon);
                        } else {
                            btn_addToFavorite.setImageResource(R.drawable.player_layout_favorite_icon);
                        }
                        isInFavorite = false;

                    }
                }
            }

        } catch (Exception ee) {
            Debugger.debugI(TAG, "UpdateFavBtnView -> error -> " + ee.getMessage());
        }

    }

    public static int favoriteIndex(ArrayList<Channel> tempList) {
        int index = -99;
        String cid = PlaylistManager.getStationList().get(PlaylistManager.getCurrentIndex()).ChannelId;
        for (int i = 0; i < tempList.size(); i++) {
            String tempid = tempList.get(i).ChannelId;
            if (cid != null && cid.equals(tempid)) {
                index = i;
                break;
            }
        }
        return index;
    }

    // onClick Clear Button
    private void Exit() {
        try {

            if (progressDialog != null) {
                progressDialog.show();
            }

            PlaylistManager.getStation2List().clear();
            if (RMusicService.mPlayback != null) {
                RMusicService.mPlayback.stop();
            }
            globals.radioServiceActivity = RadioPlayerActivity.this;
            RMusicService.stopStation(globals.radioServiceActivity);

            if (MainActivity.loaderLay != null) {
                MainActivity.loaderLay.setVisibility(View.GONE);
            }


//            ArrayList<Channel> lastPlayedList = new ArrayList<>();
//            for (int i = 0; i < PlaylistManager.getStationList().size(); i++) {
//                lastPlayedList.add(PlaylistManager.getStationList().get(i));
//            }
            //globals.saveLastPlayedList(this, lastPlayedList);
//            globals.setLastPlayedIndex(PlaylistManager.getCurrentIndex());
            //PlaylistManager.init();

            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {

                    try {
                        if (progressDialog != null) {
                            progressDialog.dismiss();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }


                    RadioPlayerActivity.this.finish();
                    stopService(new Intent(RadioPlayerActivity.this, RMusicService.class));
                }
            }, 1000);


        } catch (Exception e) {
            Debugger.debugI(TAG, "Exit -> error -> " + e.getMessage());
        }

    }

    // onClick Next Button
    public static void PlayNext(Context ActivityContext, Context ApplicationContext) {
        if (PlaylistManager.getCurrentIndex() < PlaylistManager.getStationList().size() - 1) {
            PlaylistManager.setCurrentIndex(PlaylistManager.getCurrentIndex() + 1);
        } else {
            PlaylistManager.setCurrentIndex(0);
        }
        playNow(ActivityContext, ApplicationContext);
    }

    // onClick Previous Button
    public static void PlayPrevious(Context ActivityContext, Context ApplicationContext) {

        if (PlaylistManager.getCurrentIndex() > 0) {
            PlaylistManager.setCurrentIndex(PlaylistManager.getCurrentIndex() - 1);
        } else {
            PlaylistManager.setCurrentIndex(PlaylistManager.getStationList().size() - 1);
        }
        playNow(ActivityContext, ApplicationContext);
    }


    // onClick Edit Button
    public void editPlaylist() {

        try {
            if (currentPlayingStationsList != null && currentPlayingStationsList.isDragEnabled()) {
                Bundle bundle = new Bundle();
                bundle.putString(AnalyticsConstants.EVENT_CATEGORY, AnalyticsConstants.EC_player);

                currentPlayingStationsList.setDragEnabled(false);
                playListEditBtn.setText(getResources().getString(R.string.edit));
            } else {
                Bundle bundle = new Bundle();
                bundle.putString(AnalyticsConstants.EVENT_CATEGORY, AnalyticsConstants.EC_player);
                if (currentPlayingStationsList != null) {
                    currentPlayingStationsList.setDragEnabled(true);
                }
                playListEditBtn.setText(getResources().getText(R.string.done));
            }
            loadPlaylist();
            dragAdapter.notifyDataSetChanged();
        } catch (Exception ee) {
            Debugger.debugI(TAG, "editPlaylist -> error -> " + ee.getMessage());
        }

    }

    // Drag & Drop List Adapter
    private class MAdapter extends SimpleDragSortCursorAdapter {

        int removePos;
        int iIndex;

        private MAdapter(Context context, int rMid, Cursor c, int something) {
            super(context, rMid, c, something);
            //mContext = context;
        }

        @Override
        public void bindView(View view, Context context, Cursor cursor) {

            final TextView station_nm_txt = view.findViewById(R.id.station_nm_txt);
            final ImageView btn_drag = view.findViewById(R.id.drag_handle);
            final ImageView btn_remove = view.findViewById(R.id.click_remove);
            final ImageView img_play = view.findViewById(R.id.image);

            String sIndex = cursor.getString(0);

            try {
                iIndex = Integer.parseInt(sIndex);
            } catch (NumberFormatException e) {
                iIndex = -99;
            }

            // change the row color based on selected state
            if (PlaylistManager.getCurrentIndex() == iIndex) {
                removePos = iIndex;
                Utils.saveInt(context,"position",iIndex);
                station_nm_txt.setTextColor(getResources().getColor(R.color.blue_color));
            } else {
                station_nm_txt.setTextColor(Color.parseColor("#FFFFFF"));
            }
            station_nm_txt.setText(cursor.getString(1));

            if (currentPlayingStationsList.isDragEnabled()) {
                btn_drag.setVisibility(View.VISIBLE);
                btn_remove.setVisibility(View.VISIBLE);
                img_play.setVisibility(View.GONE);
            } else {
                btn_drag.setVisibility(View.GONE);
                btn_remove.setVisibility(View.GONE);
                img_play.setVisibility(View.VISIBLE);
            }
        }

        @Override
        public void remove(int which) {
            super.remove(which);
            Debugger.debugI(TAG, "after remove total array size :" + PlaylistManager.getStationList().size());
            Debugger.debugI(TAG, "after remove get Current Index :" + PlaylistManager.getCurrentIndex());

            if (removePos == which){
                if (PlaylistManager.getStationList().size() == 0) {
                    saveRecordingIfInBackground();
                }
                globals.radioServiceActivity = RadioPlayerActivity.this;
                RMusicService.stopStation(RadioPlayerActivity.this);
            }

            if (PlaylistManager.getStationList().size() == 0) {
                clickOFClear();
                return;
            }

            reloadAdapterData();

        }

        /**
         * On drop, this updates the mapping between Cursor positions and
         * ListView positions. The Cursor is unchanged. Retrieve the current
         *
         * @see DragSortListView.DropListener#drop(int, int)
         */
        @Override
        public void drop(int from, int to) {
            super.drop(from, to);

            reloadAdapterData();
        }

        public void reloadAdapterData(){
            notifyDataSetChanged();
            loadPlaylist();

            //  pass updated playlist to DHU Queue
            Bundle bundle = new Bundle();
            bundle.putSerializable("list", (Serializable) PlaylistManager.getStationList());
            mMediaBrowserHelper.getTransportControls().sendCustomAction("update_playlist", bundle);
            saveArrayList(RadioPlayerActivity.this,PlaylistManager.getStationList(),"lastPlayedArray");
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_VOLUME_UP:
                if (audio.getStreamVolume(AudioManager.STREAM_MUSIC) == 0) {

                    if (isTablet) {
                        btn_mute.setImageResource(R.drawable.player_tab_mute_icon);
                    } else {
                        btn_mute.setImageResource(R.drawable.player_layout_volume_mute_icon);
                    }

                    vol_seekBar.setProgress(audio.getStreamVolume(AudioManager.STREAM_MUSIC) + 1);

                } else {

                    if (isTablet) {
                        btn_mute.setImageResource(R.drawable.player_tab_volume_up_icon);
                    } else {
                        btn_mute.setImageResource(R.drawable.player_layout_volume_up_icon);
                    }

                    vol_seekBar.setProgress(audio.getStreamVolume(AudioManager.STREAM_MUSIC) + 1);

                }

                return true;

            case KeyEvent.KEYCODE_VOLUME_DOWN:
                if (audio.getStreamVolume(AudioManager.STREAM_MUSIC) == 0) {

                    if (isTablet) {
                        btn_mute.setImageResource(R.drawable.player_tab_mute_icon);
                    } else {
                        btn_mute.setImageResource(R.drawable.player_layout_volume_mute_icon);
                    }

                    vol_seekBar.setProgress(audio.getStreamVolume(AudioManager.STREAM_MUSIC) - 1);
                } else {

                    if (isTablet) {
                        btn_mute.setImageResource(R.drawable.player_tab_volume_up_icon);
                    } else {
                        btn_mute.setImageResource(R.drawable.player_layout_volume_up_icon);
                    }

                    vol_seekBar.setProgress(audio.getStreamVolume(AudioManager.STREAM_MUSIC) - 1);

                }

                return true;

            case KeyEvent.KEYCODE_BACK:
                RadioPlayerActivity.this.finish();
                return true;

            default:
                return true;
        }
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

        if (vol_seekBar.getProgress() == 0) {
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0);

            if (isTablet) {
                btn_mute.setImageResource(R.drawable.player_tab_mute_icon);
            } else {
                btn_mute.setImageResource(R.drawable.player_layout_volume_mute_icon);
            }

        } else {
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0);

            if (isTablet) {
                btn_mute.setImageResource(R.drawable.player_tab_volume_up_icon);
            } else {
                btn_mute.setImageResource(R.drawable.player_layout_volume_up_icon);
            }
        }
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {
    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {
    }

    @Override
    protected void onStart() {
        super.onStart();
        mMediaBrowserHelper.onStart();
    }

    @Override
    protected void onStop() {
        super.onStop();
        //mMediaBrowserHelper.onStop();
    }

    @Override
    public void onDestroy() {
        Debugger.debugI(TAG, "onDestroy called.");

        try {
            globals.setLastPlayedIndex(PlaylistManager.getCurrentIndex());
            unregisterReceiver(myBroadCast1);
        } catch (Exception ee) {
            Debugger.debugI(TAG, "onDestroy -> error -> " + ee.getMessage());
        }

        super.onDestroy();
    }

}
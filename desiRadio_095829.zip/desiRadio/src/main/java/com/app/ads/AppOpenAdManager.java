package com.app.ads;

import android.app.Activity;
import android.content.Context;

import androidx.annotation.NonNull;

import com.app.ads.interfaces.OpenAdLoadListener;
import com.app.ads.interfaces.ShowOpenAdCompleteListener;
import com.app.firebase.FirebaseRemoteConfigUtils;
import com.app.utility.Debugger;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.appopen.AppOpenAd;

import java.util.Date;

public class AppOpenAdManager {

    private AppOpenAd appOpenAd = null;
    private boolean isLoadingAd = false;
    private boolean isShowingAd = false;
    private long loadTime = 0;
    Context context;
    OpenAdLoadListener openAdLoadListener;
    private String TAG = getClass().getSimpleName();

    private static AppOpenAdManager appOpenAdManagerInstance;

    public static AppOpenAdManager getInstance() {
        if (appOpenAdManagerInstance == null) {
            appOpenAdManagerInstance = new AppOpenAdManager();
        }
        return appOpenAdManagerInstance;
    }

    public void init(Context context, OpenAdLoadListener openAdLoadListener) {
        this.context = context;

        loadAppOpenAd(context, openAdLoadListener);

    }

    // load ad
    public void loadAppOpenAd(Context context, OpenAdLoadListener oAdLoadListener) {

//        if (isLoadingAd || isAdAvailable()) {
//            Debugger.debugI(TAG,"if ad available ");
//            return;
//
//        }
        Debugger.debugI(TAG,"before adRequest ");
        isLoadingAd = true;
        AdRequest adRequest = new AdRequest.Builder().build();
        Debugger.debugI(TAG,"adRequest "+adRequest.toString());
        AppOpenAd.load(context,
                FirebaseRemoteConfigUtils.getInstance().getAdmobAppOpenAdID(),
                adRequest, new AppOpenAd.AppOpenAdLoadCallback() {
                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        super.onAdFailedToLoad(loadAdError);
                        Debugger.debugI(TAG , " Fail to Ad Loaded: "+loadAdError.getMessage());
                        isShowingAd = false;
                        if (oAdLoadListener != null) {
                            openAdLoadListener = (OpenAdLoadListener) oAdLoadListener;
                            openAdLoadListener.onOpenAdFailed();
                        }
                    }

                    @Override
                    public void onAdLoaded(@NonNull AppOpenAd ad) {
                        super.onAdLoaded(appOpenAd);
                        Debugger.debugI(TAG , " Ad Loaded: ");
                        appOpenAd = ad;
                        isLoadingAd = false;
                        loadTime = (new Date()).getTime();

                        if (oAdLoadListener != null) {
                            openAdLoadListener = (OpenAdLoadListener) oAdLoadListener;
                            openAdLoadListener.onOpenAdLoaded();
                        }
                    }

                });

    }


    private boolean wasLoadTimeLessThanHourAgo(long numHour) {
        long dateDifference = (new Date()).getTime() - loadTime;
        long numMilliSecondPerHour = 36806808;
        return (dateDifference < numMilliSecondPerHour);

    }

    // if ad exist and can be shown
    private boolean isAdAvailable() {

        return appOpenAd != null /*&& wasLoadTimeLessThanHourAgo(4)*/;
    }

    // show the ad if one isn't already showing
//    private void showAdIfAvailable(@NonNull Activity activity1) {
//        showAdIfAvailable(activity1, new ShowOpenAdCompleteListener() {
//            @Override
//            public void onShowComplete() {
//                Debugger.debugI(TAG , " onShowComplete: ");
//            }
//        });
//    }

    // show the ad if one isn't already showing
    public void showAdIfAvailable(@NonNull final Activity activity,
                                  @NonNull ShowOpenAdCompleteListener onShowAdCompleteListener) {


        if (isShowingAd) {
            Debugger.debugI(TAG ,  " showAdIfAvailable: ");
            return;
        }

        // if open ad is not available yet,set callback and load the ad
        if (!isAdAvailable()) {
            Debugger.debugI(TAG ," show If not Available: ");
            onShowAdCompleteListener.onShowComplete();

//            loadAppOpenAd(activity, openAdLoadListener);
            return;
        }

        // open ad callbacks
        appOpenAd.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override
            public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                super.onAdFailedToShowFullScreenContent(adError);
                Debugger.debugI(TAG , " onAdFailedToShowFullScreenContent: ");

                // set the ref to null so isAvailable() return false
                appOpenAd = null;
                isShowingAd = false;

                onShowAdCompleteListener.onShowComplete();

            }

            @Override
            public void onAdShowedFullScreenContent() {
                super.onAdShowedFullScreenContent();

                Debugger.debugI(TAG , " onAdShowedFullScreenContent: ");
            }

            @Override
            public void onAdDismissedFullScreenContent() {
                super.onAdDismissedFullScreenContent();

                Debugger.debugI(TAG , " onAdDismissedFullScreenContent: ");

                appOpenAd = null;
                isShowingAd = false;


                onShowAdCompleteListener.onShowComplete();


            }

            @Override
            public void onAdImpression() {
                super.onAdImpression();

                Debugger.debugI(TAG , " onAdImpression: ");
            }
        });

        isShowingAd = true;
        appOpenAd.show(activity);
    }
}
package com.app.auto;

import static com.app.auto.RMusicService.isPrepare;
import static com.app.utility.Constant.mStationArrayList;
import static com.app.utility.Utils.checkPlayerIsPlay;
import static com.app.utility.Utils.isPLAY;

import static com.app.utility.Utils.lastPlayedStation;

import static com.app.player.RadioPlayerActivity.loaderLay;
import static com.app.utility.Constant.MM_Song_Info_Not_Found;
import static com.app.utility.Utils.setDefaultDataPlayer;
import static com.app.utility.Utils.setSongLabel;
import static com.app.utility.Utils.setStationLabel;

import android.content.Context;
import android.net.Uri;
import android.os.SystemClock;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.PlaybackStateCompat;

import android.view.View;

import androidx.annotation.NonNull;

import com.app.desiradio.MainActivity;
import com.app.player.LockScreenPlayer;
import com.app.player.PlaylistManager;
import com.app.player.RadioPlayerActivity;
import com.app.utility.Constant;
import com.app.utility.Debugger;
import com.app.utility.Globals;

import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.MediaMetadata;
import com.google.android.exoplayer2.PlaybackException;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.source.ConcatenatingMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.ProgressiveMediaSource;
import com.google.android.exoplayer2.source.ShuffleOrder;
import com.google.android.exoplayer2.upstream.DefaultDataSource;
import com.indianradio.R;

public final class ExoPlayerAdapter extends PlayerAdapter {

    private final Context mContext;
    private String mFilename;
    private PlayBackChangeListener mPlaybackInfoListener;
    private MediaMetadataCompat mCurrentMedia;
    private int mState;
    private boolean mCurrentMediaPlayedToCompletion;
    public String TAG = getClass().getSimpleName();

    // Work-around for a MediaPlayer bug related to the behavior of MediaPlayer.seekTo()
    // while not playing.
    private int mSeekWhileNotPlaying = -1;

    //new implement
    private ExoPlayer exoPlayer;
    private MediaNotificationManager mMediaNotificationManager;
    Globals globals;

    public ExoPlayerAdapter(Context context, PlayBackChangeListener listener) {
        super(context);
        Debugger.debugI(TAG, " MediaPlayerAdapter2: ");
        mContext = context;
        globals = (Globals) mContext.getApplicationContext();
        mPlaybackInfoListener = listener;
    }

    public static void stopPlayerChanges() {
        Debugger.debugI("ExoPlayerAdapter", " stop player changes ");
        isPLAY = false;
        RMusicService.setAlbumUris("");
        RMusicService.currentPlayingName = "";
    }

    private void initializeExoPlayer() {
        if (loaderLay != null) {
            loaderLay.setVisibility(View.VISIBLE);
        }
        if (MainActivity.loaderLay != null) {
            MainActivity.loaderLay.setVisibility(View.VISIBLE);
        }
        Debugger.debugI(TAG, "initializeExoPlayer: ");
        checkPlayerIsPlay = 0;
        exoPlayer = new ExoPlayer.Builder(mContext).build();

        exoPlayer.addListener(new Player.Listener() {

            @Override
            public void onPlaybackStateChanged(int playbackState) {
                Player.Listener.super.onPlaybackStateChanged(playbackState);
                checkPlayerIsPlay = 1;
             //   ((RMusicService) mContext).onMetadataNotGetting();
                if (mContext != null && mContext.getClass().equals(RMusicService.class)) {
                    ((RMusicService) mContext).setDefaultSessionData();
                }
                switch (playbackState) {

                    case Player.STATE_BUFFERING:
                        Debugger.debugD(TAG, "onPlaybackStateChanged -----buffering------");
                    case Player.STATE_READY:
                        Debugger.debugD(TAG, "onPlaybackStateChanged -----ready------");
                    case Player.STATE_ENDED:
                        Debugger.debugD(TAG, "onPlaybackStateChanged -----end------");
                    default:

                }

            }

            @Override
            public void onPlayWhenReadyChanged(boolean playWhenReady, int reason) {
                Player.Listener.super.onPlayWhenReadyChanged(playWhenReady, reason);

                Debugger.debugD(TAG, "onPlaybackStateChanged -----temp------");
                if (playWhenReady) {
                    RadioPlayerActivity.setPlayButtonIcon(mContext, R.drawable.player_layout_stop_icon);

                }
            }

            @Override
            public void onMediaMetadataChanged(@NonNull MediaMetadata mediaMetadata) {
                Player.Listener.super.onMediaMetadataChanged(mediaMetadata);


                /** set default text in song name && change the albumImage,isPlaying flag and current songname to empty    */
                stopPlayerChanges();

                if (loaderLay != null) {
                    loaderLay.setVisibility(View.GONE);
                }
                if (MainActivity.loaderLay != null) {
                    MainActivity.loaderLay.setVisibility(View.GONE);
                }
                RMusicService.currentPlayingName = MM_Song_Info_Not_Found;

                setSongLabel(RMusicService.currentPlayingName);

                if (mediaMetadata != null) {
                    isPrepare = true;
                    RadioPlayerActivity.setPlayButtonIcon(mContext, R.drawable.player_layout_stop_icon);
                    Debugger.debugI(TAG, "onMediaMetadataChanged:title " + mediaMetadata.title);
                    Debugger.debugI(TAG, "onMediaMetadataChanged:station " + mediaMetadata.station);
                    Debugger.debugI(TAG, "onMediaMetadataChanged:genre " + mediaMetadata.genre);

                    if (mContext != null && mContext.getClass().equals(RMusicService.class)) {
                        ((RMusicService) mContext).onMetadata(mediaMetadata);
                    }
                    /** here we set song name in radioPlayerActivity and lockscreenPlayer    */

                    try {

                        String songAlbumName = (String) mediaMetadata.title;

                        // RadioPlayerActivity.getName(RMusicService.currentPlayingName);
                        if (songAlbumName != null && songAlbumName.length() > 1) {
                            RMusicService.currentPlayingName = (String) mediaMetadata.title;
                            setSongLabel((String) mediaMetadata.title);
                        }

                        if (PlaylistManager.getCurrentIndex() > 0) {

                            setStationLabel(PlaylistManager.getStationList().get(PlaylistManager.getCurrentIndex()).ChannelTitle);
                        }

                    } catch (Exception ee) {
                        Debugger.debugI(TAG, "Error »»»»»»» " + ee.getMessage());
                    }

                }
            }

            @Override
            public void onPlayerError(PlaybackException error) {
                Player.Listener.super.onPlayerError(error);

                Debugger.debugI(TAG, "onPlayerError: " + error.getMessage());
                lastPlayedStation = null;
                ((RMusicService) mContext).onMetadataNotGetting();

                setDefaultDataPlayer(mContext, 1, 1);
            }
        });
    }

    private void playExoPlayer(String channelUrl) {
        setDefaultDataPlayer(mContext, 1, 1);
        isPrepare = false;
        Debugger.debugI(TAG, "playExoPlayer: ");
        DefaultDataSource.Factory dataSourceFactory = new DefaultDataSource.Factory(mContext);
        ConcatenatingMediaSource contentMediaSource = new ConcatenatingMediaSource(
                /* isAtomic= */ false,
                /* useLazyPreparation= */ true,
                new ShuffleOrder.DefaultShuffleOrder(/* length= */ 0));
        MediaItem mediaItem = new MediaItem.Builder().setUri(channelUrl).build();
        MediaSource mediaSource = null;
        try {
            mediaSource = new ProgressiveMediaSource.Factory(dataSourceFactory).createMediaSource(mediaItem);

        } catch (Exception ee) {
            Debugger.debugE(TAG, "error - >  " + ee.getMessage());
        }

        contentMediaSource.addMediaSource(mediaSource);
        exoPlayer.setMediaSource(contentMediaSource);
        exoPlayer.prepare();
        exoPlayer.setPlayWhenReady(true);
    }

    // Implements PlaybackControl.
    @Override
    public void playFromMedia(MediaMetadataCompat metadata) {

        if (metadata != null) {
            final String mediaId = metadata.getString(MediaMetadataCompat.METADATA_KEY_MEDIA_ID);
            Debugger.debugI(TAG, "playFromMedia: " + metadata.getDescription());

            playFile(mediaId);
        }
        //playFile(MusicLibrary.getMusicFilename(station.getChannelLink()));
    }

    @Override
    public MediaMetadataCompat getCurrentMedia() {
        return mCurrentMedia;
    }

    private void playFile(String filename) {
        Debugger.debugI(TAG, "playFile: " + filename);

        boolean mediaChanged = (mFilename == null || !filename.equals(mFilename));
        if (mCurrentMediaPlayedToCompletion) {
            // Last audio file was played to completion, the resourceId hasn't changed, but the
            // player was released, so force a reload of the media file for playback.
            mediaChanged = true;
            mCurrentMediaPlayedToCompletion = false;
        }
        if (!mediaChanged) {
            if (!isPlaying()) {
                play();

            }
            return;
        } else {
            release();

        }

        mFilename = filename;

        initializeExoPlayer();
        playExoPlayer(mFilename);

        play();
    }

    @Override
    public void onStop() {
        Debugger.debugI(TAG, "onStop: ");
        // Regardless of whether or not the MediaPlayer has been created / started, the state must
        // be updated, so that MediaNotificationManager can take down the notification.
        setNewState(PlaybackStateCompat.STATE_STOPPED);
        release();
    }

    private void release() {
        Debugger.debugI(TAG, "release: ");
        checkPlayerIsPlay = 0;
        if (exoPlayer != null) {
            exoPlayer.release();
            exoPlayer = null;
        }
    }

    @Override
    public boolean isPlaying() {
        return exoPlayer != null && exoPlayer.isPlaying();
    }

    @Override
    protected void onPlay() {
        Debugger.debugI(TAG, "onPlay: ");
        if (exoPlayer != null && !exoPlayer.isPlaying()) {
            exoPlayer.play();
            setNewState(PlaybackStateCompat.STATE_PLAYING);
        }
    }

    @Override
    protected void onPause() {
        Debugger.debugI(TAG, "onPause: ");

        if (exoPlayer != null && exoPlayer.isPlaying()) {
            exoPlayer.pause();
            setNewState(PlaybackStateCompat.STATE_PAUSED);
        }
    }

    // This is the main reducer for the player state machine.
    private void setNewState(@PlaybackStateCompat.State int newPlayerState) {
        Debugger.debugI(TAG, "setNewState: " + newPlayerState);
        mState = newPlayerState;

        // Whether playback goes to completion, or whether it is stopped, the
        // mCurrentMediaPlayedToCompletion is set to true.
        if (mState == PlaybackStateCompat.STATE_STOPPED) {
            mCurrentMediaPlayedToCompletion = true;
        }

        // Work around for MediaPlayer.getCurrentPosition() when it changes while not playing.
        final long reportPosition;
        if (mSeekWhileNotPlaying >= 0) {
            reportPosition = mSeekWhileNotPlaying;

            if (mState == PlaybackStateCompat.STATE_PLAYING) {
                // mSeekWhileNotPlaying = -1;
            }
        } else {

            reportPosition = exoPlayer == null ? 0 : exoPlayer.getCurrentPosition();
        }

        final PlaybackStateCompat.Builder stateBuilder = new PlaybackStateCompat.Builder();
        stateBuilder.setActions(getAvailableActions());
        stateBuilder.setState(mState,
                reportPosition,
                1.0f,
                SystemClock.elapsedRealtime());
        mPlaybackInfoListener.onPlaybackStateChange(stateBuilder.build());
    }

    /**
     * Set the current capabilities available on this session. Note: If a capability is not
     * listed in the bitmask of capabilities then the MediaSession will not handle it. For
     * example, if you don't want ACTION_STOP to be handled by the MediaSession, then don't
     * included it in the bitmask that's returned.
     */
    @PlaybackStateCompat.Actions
    private long getAvailableActions() {
        Debugger.debugI(TAG, "getAvailableActions: ");
        long actions = PlaybackStateCompat.ACTION_PLAY_FROM_MEDIA_ID
                | PlaybackStateCompat.ACTION_PLAY_FROM_SEARCH
                | PlaybackStateCompat.ACTION_SKIP_TO_NEXT
                | PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS;
        switch (mState) {
            case PlaybackStateCompat.STATE_STOPPED:
                actions |= PlaybackStateCompat.ACTION_PLAY;
                break;
            case PlaybackStateCompat.STATE_PLAYING:
                actions |= PlaybackStateCompat.ACTION_STOP;
                break;

            default:
                actions |= PlaybackStateCompat.ACTION_PLAY
                        | PlaybackStateCompat.ACTION_STOP;
        }
        return actions;
    }

    @Override
    public void seekTo(long position) {
        Debugger.debugI(TAG, "seekTo: ");

        if (exoPlayer != null) {

            // Set the state (to the current state) because the position changed and should
            // be reported to clients.
            setNewState(mState);
        }
    }

    @Override
    public void setVolume(float volume) {

        if (exoPlayer != null) {
            exoPlayer.setVolume(volume);
        }
    }
}

package com.app.sqlite;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.app.utility.Debugger;

public class DBHelper extends SQLiteOpenHelper {

    // All Static variables
    private static DBHelper dbHelper = null;

    // Database Version
    private static final int DATABASE_VERSION = 2;

    // Database Name
    private static final String DATABASE_NAME = "RecordingManager.db";

    // Table name
    private static final String TABLE_RECORDING = "Recording";

    // Recording Table Columns names
    private static final String KEY_ID = "id";
    private static final String KEY_NAME = "name";
    private static final String KEY_SNAME = "station";
    private static final String KEY_DURATION = "duration";
    private static final String KEY_PATH = "path";
    private static final String KEY_DATE = "date";

    public String TAG = getClass().getName();

    public static DBHelper getDBHelper(Context context) {
        return (dbHelper == null) ? dbHelper = new DBHelper(context) : dbHelper;
    }

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creating Tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_RECORDING_TABLE = "CREATE TABLE " + TABLE_RECORDING
                + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_NAME + " TEXT,"
                + KEY_SNAME + " TEXT,"
                + KEY_DURATION + " TEXT,"
                + KEY_PATH + " TEXT,"
                + KEY_DATE + " TEXT"
                + ");";
        db.execSQL(CREATE_RECORDING_TABLE);
    }

    // Upgrading database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Debugger.debugI(TAG, "Upgrading database from version " + oldVersion + " to " + newVersion + ", which will destroy all old data");

        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_RECORDING);
        // Create tables again
        onCreate(db);
    }

    /**
     * All CRUD(Create, Read, Update, Delete) Operations
     */

    // Adding new Recording
    public void addRecording(Recording recording) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_NAME, recording.getName()); // Name of Recording
        values.put(KEY_SNAME, recording.getStationName()); // Station name
        values.put(KEY_DURATION, recording.getDuration()); // Total REC Duration
        values.put(KEY_PATH, recording.getPath()); // File path
        values.put(KEY_DATE, recording.getDate()); // Date of Recording

        // Inserting Row
        db.insert(TABLE_RECORDING, null, values);
    }

    // Check Recording exist or not
    public boolean isRecordingAvailable(int rID) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_RECORDING,
                new String[]{KEY_ID},
                KEY_ID + "=?",
                new String[]{String.valueOf(rID)},
                null, null, null, null);
        try {
            if (cursor != null && cursor.moveToNext()) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            Debugger.debugI("Error ", "cursor error in getRecording");
            e.printStackTrace();
        }
        return false;
    }

    // Getting single Recording
    @SuppressLint("Range")
    public Recording getRecording(int rID) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_RECORDING,
                new String[]{KEY_ID, KEY_NAME, KEY_SNAME, KEY_DURATION, KEY_PATH, KEY_DATE},
                KEY_ID + "=?",
                new String[]{String.valueOf(rID)},
                null, null, null, null);
        Recording recording = null;
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                recording = new Recording(cursor.getInt(cursor.getColumnIndex(KEY_ID)),
                        cursor.getString(cursor.getColumnIndex(KEY_NAME)),
                        cursor.getString(cursor.getColumnIndex(KEY_SNAME)),
                        cursor.getString(cursor.getColumnIndex(KEY_DURATION)),
                        cursor.getString(cursor.getColumnIndex(KEY_PATH)),
                        cursor.getString(cursor.getColumnIndex(KEY_DATE)));
            }
        }

        if (!cursor.isClosed())
            cursor.close();
        // return contact
        return recording;
    }

    // Getting All Recordings
    public List<Recording> getAllRecordings() {
        List<Recording> recordingList = new ArrayList<Recording>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_RECORDING + " ORDER BY " + KEY_DATE + " DESC";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor != null) {
            try {
                if (cursor.moveToFirst()) {
                    do {
                        @SuppressLint("Range") int rID = cursor.getInt(cursor.getColumnIndex(KEY_ID));
                        @SuppressLint("Range") String fPath = cursor.getString(cursor.getColumnIndex(KEY_PATH));

                        File file = new File(fPath);
                        if (file.exists()) {
                            @SuppressLint("Range") Recording recording = new Recording(rID,
                                    cursor.getString(cursor.getColumnIndex(KEY_NAME)),
                                    cursor.getString(cursor.getColumnIndex(KEY_SNAME)),
                                    cursor.getString(cursor.getColumnIndex(KEY_DURATION)),
                                    fPath,
                                    cursor.getString(cursor.getColumnIndex(KEY_DATE)));
                            recordingList.add(recording);
                        } else {
                            deleteRecording(rID);
                        }
                    } while (cursor.moveToNext());
                }
            } catch (Exception ee) {
                Debugger.debugI(TAG, ee.getMessage());
            }
        }

        if (!cursor.isClosed())
            cursor.close();
        // return Recording list
        return recordingList;
    }

    // Deleting single Recording
    public boolean deleteRecording(int rID) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_RECORDING, KEY_ID + " = ?", new String[]{String.valueOf(rID)}) > 0;
    }

    // Deleting All Recording
    public boolean deleteAll() {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_RECORDING, null, null) > 0;
    }

    // Getting Recording Count
    public int getRecordingCount() {

        //use this because may be it posible recorded file deleted externally
        List<Recording> recordingList = getAllRecordings();
        return recordingList.size();

        //this return only db count not Recorded file cound that exists.
//		String countQuery = "SELECT  * FROM " + TABLE_RECORDING;
//		SQLiteDatabase db = this.getReadableDatabase();
//		Cursor cursor = db.rawQuery(countQuery, null);
//		int count = cursor.getCount();
//		if(!cursor.isClosed())
//			cursor.close();
//		return count;
    }

    // closing database
    public void closeDB() {
        SQLiteDatabase db = this.getReadableDatabase();
        if (db != null && db.isOpen()) {
            Debugger.debugI(TAG, "Database is closed.");
            db.close();
        }
    }
}

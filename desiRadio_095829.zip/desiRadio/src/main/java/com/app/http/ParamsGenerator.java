package com.app.http;

import java.lang.reflect.Type;
import java.util.HashMap;

import android.content.Context;

import com.app.utility.Debugger;
import com.app.utility.Globals;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class ParamsGenerator {
	
	public static String TAG = "ParamsGenerator";
	public static HashMap<String, Object> createDefaultParams(Context context) {
		
		Globals globals = ((Globals)context.getApplicationContext());
		
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("VersionId", globals.getApplicationVersionName());
		params.put("Platform", "android");
		params.put("app_id", globals.getApplicationPackageName());
		
		return params;
    }
	
	public static String generateGCMRegisterRequest(Context context, String DeviceToken) {
		HashMap<String, Object> params = createDefaultParams(context);
		params.put("DeviceToken", DeviceToken);

		return toJsonString(params);
    }
	
	public static String generateFetchGenreListRequest(Context context) {
		
		HashMap<String, Object> params = createDefaultParams(context);

		return toJsonString(params);
    }

	public static String toJsonString(HashMap<String, Object> params) {
		
        Type mapType = new TypeToken<HashMap<String, Object>>() {}.getType();
		Gson gson = new Gson();
		String postData = gson.toJson(params, mapType);
		
		Debugger.debugI(TAG, "Param send to API : "+ postData);
		return postData;
	}
}

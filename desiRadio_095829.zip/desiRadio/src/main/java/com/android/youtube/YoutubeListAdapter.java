package com.android.youtube;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.app.utility.Utils;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.indianradio.R;

import java.util.ArrayList;
import java.util.HashMap;

public class YoutubeListAdapter extends BaseAdapter {
    
    private Activity activity;
    private ArrayList<HashMap<String, String>> data;
    private static LayoutInflater inflater=null;
    //public ImageLoader imageLoader;
    public Glide glide;
    Context context;
    
    public YoutubeListAdapter(Activity a) {
        activity = a;
        data = new ArrayList<HashMap<String,String>>();
        inflater = (LayoutInflater)activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        //imageLoader=new ImageLoader(activity.getApplicationContext());

    }

	public void updateResults(ArrayList<HashMap<String, String>> newData) {
		this.data = newData;
        //Triggers the list update
        notifyDataSetChanged();
    }

    public int getCount() {
        return data.size();
    }

    public Object getItem(int position) {
        return position;
    }

    public long getItemId(int position) {
        return position;
    }
    
    public static class ViewHolder{
        public TextView title;
        public TextView description;
        //public TextView duration;
        public ImageView image,image1;
        LinearLayout layout1;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        View vi=convertView;
        ViewHolder holder;
        if(convertView==null){
            vi = inflater.inflate(R.layout.youtube_video_list_item, null);
            holder=new ViewHolder();
            holder.title=(TextView)vi.findViewById(R.id.txt_title);
            holder.description=(TextView)vi.findViewById(R.id.txt_description);
            //holder.duration=(TextView)vi.findViewById(R.id.txt_duration);
            holder.image=(ImageView)vi.findViewById(R.id.image);
            holder.image1=(ImageView)vi.findViewById(R.id.image1);
            holder.layout1=vi.findViewById(R.id.layout1);
            vi.setTag(holder);
        }
        else
            holder=(ViewHolder)vi.getTag();


//        if (Utils.getInt(activity, "mode", 0) == 0) {
//
//            holder.title.setTextColor(Color.BLACK);
//            holder.layout1.setBackgroundColor(Color.WHITE);
//            holder.image1.setColorFilter(Color.BLACK);
//        } else {
//
//            holder.title.setTextColor(Color.WHITE);
//            holder.layout1.setBackgroundColor(Color.BLACK);
//            holder.image1.setColorFilter(Color.WHITE);
//        }

        holder.title.setText(data.get(position).get("title"));
        holder.description.setText(data.get(position).get("description"));
        holder.description.setText("Duration: " + data.get(position).get("duration"));
        //holder.duration.setText(data.get(position).get("duration"));
        //holder.image.setTag(data.get(position).get("big_thumbnail"));
        //imageLoader.DisplayImage(data.get(position).get("big_thumbnail"), activity, holder.image);
        Glide.with(activity.getApplicationContext())
                .load(data.get(position).get("big_thumbnail"))
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(holder.image);
        return vi;
    }
}
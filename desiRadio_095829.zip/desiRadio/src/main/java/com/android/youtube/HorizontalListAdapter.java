package com.android.youtube;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.indianradio.R;

import java.util.ArrayList;
import java.util.HashMap;

public class HorizontalListAdapter extends BaseAdapter {
    
    private Activity activity;
    private ArrayList<HashMap<String, String>> data;
    private static LayoutInflater inflater=null;
    //public ImageLoader imageLoader;
    
    public HorizontalListAdapter(Activity a, ArrayList<HashMap<String, String>> d) {
        activity = a;
        data=d;
        inflater = (LayoutInflater)activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        //imageLoader=new ImageLoader(activity.getApplicationContext());
    }

    public int getCount() {
        return data.size();
    }

    public Object getItem(int position) {
        return position;
    }

    public long getItemId(int position) {
        return position;
    }
    
    public static class ViewHolder{
        public TextView title;
        //public TextView duration;
        public ImageView image;
        //public ImageView overlay;
        public FrameLayout frameLayout;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        View vi=convertView;
        ViewHolder holder;
        if(convertView==null){
            vi = inflater.inflate(R.layout.youtube_horizontal_list_item, null);
            holder=new ViewHolder();
            holder.frameLayout = (FrameLayout) vi.findViewById(R.id.videoCellFrameLayout);
            //holder.overlay = (ImageView) vi.findViewById(R.id.img_overlay);
            holder.title=(TextView)vi.findViewById(R.id.txt_title);
            //holder.duration=(TextView)vi.findViewById(R.id.txt_duration);
            holder.image=(ImageView)vi.findViewById(R.id.image);
            vi.setTag(holder);
        } else
            holder=(ViewHolder)vi.getTag();
        
        holder.title.setText(data.get(position).get("title"));
        //holder.duration.setText(data.get(position).get("duration"));
        //holder.image.setTag(data.get(position).get("big_thumbnail"));
        
        if(videoplayerActivity.currentIndex == position) {
        	 holder.frameLayout.setForeground(activity.getResources().getDrawable(R.drawable.video_cell_background_selected));
        	 /*if(videoplayerActivity.videoPlayer != null && videoplayerActivity.videoPlayer.isPlaying()) {
        		 holder.overlay.setImageResource(R.drawable.img_pause_overlay);
        	 } else {
        		 holder.overlay.setImageResource(R.drawable.img_playing_overlay);       		 
        	 }*/
        } else {
        	 holder.frameLayout.setForeground(activity.getResources().getDrawable(R.drawable.video_cell_background_normal));
             //holder.overlay.setImageResource(R.drawable.img_playing_overlay);
        }

        //imageLoader.DisplayImage(data.get(position).get("big_thumbnail"), activity, holder.image);
        Glide.with(activity.getApplicationContext())
                .load(data.get(position).get("big_thumbnail"))
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(holder.image);
        return vi;
    }
}
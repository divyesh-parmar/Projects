package com.app.genre;

import java.util.ArrayList;
import java.util.Random;

import com.app.parser.Channel;
import com.app.utility.Debugger;
import com.app.utility.Globals;

public class ChannelManager {
	
	String TAG = getClass().getName();
	public static ChannelManager listManager = null;
	public static ChannelManager searManager = null;
	
	public ArrayList<ChannelItem> channel_list;
	public String searchTerms;
	
	public ArrayList<ChannelItem> AdsList;
	public ArrayList<Integer> randomIndex;
	
	public ChannelManager() {
		super();
		init();
	}
	
	public static ChannelManager getListManager(Boolean isAllChannelview) {
       	if (isAllChannelview) {
			if(searManager == null) {
				searManager = new ChannelManager();
			}
			return searManager;
       	} else {		
			if(listManager == null) {
				listManager = new ChannelManager();
			}
			return listManager;
		}
	}
	
	public static void resetAll() {
		if(listManager != null) {
			listManager.init();
			listManager = null;
		} 
		
		if(searManager != null) {
			searManager.init();
			searManager = null;
		}
	}
	
	public void init() {
		Debugger.debugI(TAG, "init called");
		channel_list = new ArrayList<ChannelItem>();
		searchTerms = null;
		
		AdsList = new ArrayList<ChannelItem>();
		randomIndex = new ArrayList<Integer>();
	}
	
	public void resetAds() {
		AdsList.clear();
		randomIndex.clear();
	}
	
	public ArrayList<ChannelItem> getChannelList() {
		return channel_list;
	}

	public void setStationList(Globals globals, ArrayList<Channel> search_list) {
		this.channel_list = globals.convertChannelObjList(search_list);
	}
	
	public String getSearchTerms() {
		return searchTerms;
	}

	public void setSearchTerms(String searchTerms) {
		this.searchTerms = searchTerms;
	}
	
	public ArrayList<ChannelItem> getAdsList() {
		return AdsList;
	}

	public void setAdsList(ArrayList<ChannelItem> adsList) {
		AdsList = adsList;
	}
	
	public void addItem(ArrayList<ChannelItem> list, ChannelItem item) {
		if (item == null || list == null) {
			return;
		}
		list.add(item);
	}
	
	public ArrayList<ChannelItem> PrepareList() {
		
		ArrayList<ChannelItem> comboList = new ArrayList<ChannelItem>();
		if (channel_list == null || channel_list.isEmpty()) {
			return comboList;
		} else {
			comboList.addAll(channel_list);
		}

		if(AdsList == null || AdsList.isEmpty())
			return comboList;
		
		int videoCount = channel_list.size();
		int AdCount = AdsList.size();
		
		for (int i = 0; i < AdCount; i++) {
			
			Random r = new Random();
			int min = (i*10)+1;
			int max = min+7;
			if(max > videoCount) {
				max = videoCount-1;
			}
			Debugger.debugD(TAG, "MIN : "+min+" MAX : "+max);
			
			int rIndex = -99;
			try {
				rIndex = r.nextInt(max - min) + min;
			} catch (Exception e) {
				e.printStackTrace();
			}
			Debugger.debugI(TAG, "AD Random Index Number ["+i+"] : "+rIndex);
			
			if(rIndex != -99 && rIndex < comboList.size()) {
				ChannelItem adItem = AdsList.get(i);
				if (adItem != null) {
					comboList.add(rIndex,  adItem);
					randomIndex.add(rIndex);
				}
			}
		}
		return comboList;
	}
	
	public ArrayList<ChannelItem> getDisplayList() {
			
		ArrayList<ChannelItem> comboList = new ArrayList<ChannelItem>();
		
		if (channel_list == null || channel_list.isEmpty()) {
			return comboList;
		} else {
			comboList.addAll(channel_list);
		}
		
		if(AdsList == null || AdsList.isEmpty())
			return comboList;
		
		
		for (int i = 0; i < randomIndex.size(); i++) {
			if(randomIndex.get(i) < comboList.size()) {
				try {
					ChannelItem adItem = AdsList.get(i);
					if (adItem != null) {
						comboList.add(randomIndex.get(i),  adItem);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		return comboList;
	}
}

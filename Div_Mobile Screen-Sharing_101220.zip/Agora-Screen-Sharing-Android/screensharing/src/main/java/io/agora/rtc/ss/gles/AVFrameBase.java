package io.agora.rtc.ss.gles;

public class AVFrameBase {
    public long dts;
    public long pts;

    public AVFrameBase() {
    }
}

package com.app.desiradio;

import static com.app.desiradio.PrepareDrawerList.dw_entry_theme;
import static com.app.player.RadioPlayerActivity.dragAdapter;
import static com.app.player.RadioPlayerActivity.fetchStationURL;
import static com.app.player.RadioPlayerActivity.mIsPlaying;
import static com.app.player.RadioPlayerActivity.mMediaBrowserHelper;
import static com.app.player.RadioPlayerActivity.updateItemAtPosition;
import static com.app.utility.Constant.MM_PLZ_SELECT_STATION;
import static com.app.utility.Constant.MM_STOP_RECORDING_FIRST;
import static com.app.utility.Constant.MM_Song_Info_Not_Found;
import static com.app.utility.Constant.MORE_APP_ID;
import static com.app.utility.Constant.mStationArrayList;
import static com.app.utility.Utils.app_update_flag;
import static com.app.utility.Utils.checkInterstitialIsInit;
import static com.app.utility.Utils.checkPlayerIsPlay;
import static com.app.utility.Utils.flgForPlayerOpen;
import static com.app.utility.Utils.internetFlag;
import static com.app.utility.Utils.selectedStation;
import static com.app.utility.Utils.setSongLabel;
import static com.app.utility.Utils.setStationLabel;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import android.app.Activity;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;

import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.webkit.URLUtil;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.android.FirebaseAnalytics.AnalyticsConstants;
import com.android.Utility.Classes.ProgressIndicator;
import com.android.Utility.Classes.UnCaughtException;
import com.android.drawerlistview.DrawerSectionListAdapter;
import com.android.drawerlistview.EntryItem;
import com.android.drawerlistview.Item.Group;
import com.android.youtube.YoutubeListActivity;
import com.anjlab.android.iab.v3.PurchaseInfo;
import com.app.ads.BannerAdsUtil;
import com.app.ads.InterstitialAdManager;
import com.app.ads.InterstitialUtils;
import com.app.ads.NativeAdsUtils;
import com.app.ads.interfaces.InterstitialDismissListener;
import com.app.auto.ExoPlayerAdapter;
import com.app.auto.RMusicService;
import com.app.favorites.FavoritesFragment;
import com.app.genre.ChannelListFragment;
import com.app.genre.HistorylListFragment;
import com.app.genre.LanguageListFragment;
import com.app.googleservices.purchase.InAppBillingManager;
import com.app.googleservices.review.InAppReview;
import com.app.googleservices.update.InAppUpdateManager;
import com.app.http.ConnectionDetector;
import com.app.parser.Channel;
import com.app.player.LockScreenPlayer;
import com.app.player.PlayerSingleton;
import com.app.player.PlaylistManager;
import com.app.player.RadioPlayerActivity;

import com.app.player.showRecordingInterruptDialogActivity;
import com.app.recorded.RecordedFragment;
import com.app.recorded.RecordedManager;
import com.app.recorded.RecordedPlayerService;
import com.app.sqlite.DBHelper;
import com.app.utility.Constant;
import com.app.utility.ContextSingleton;
import com.app.utility.Debugger;
import com.app.utility.FragmentStateSaver;
import com.app.utility.Globals;

import com.app.utility.Utils;
import com.bumptech.glide.Glide;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.RequestConfiguration;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.play.core.install.model.AppUpdateType;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.gson.Gson;
import com.indianradio.BuildConfig;
import com.indianradio.R;
import com.jakewharton.processphoenix.ProcessPhoenix;

public class MainActivity extends AppCompatActivity implements OnItemClickListener, InterstitialDismissListener {

    private static final String SELECTED_DRAWER_ITEM = "com.drawer.selected.item";
    Globals globals;
    int mPosition = -1;
    final int RQS_GooglePlayServices = 1;
    public static boolean isAppReady = false;
    boolean requiredRecordedView = false;
    public DrawerLayout mDrawerLayout;
    public ListView mDrawerList;
    private ActionBarDrawerToggle mDrawerToggle;
    private LinearLayout mDrawer;
    DrawerSectionListAdapter mAdapter = null;
    PrepareDrawerList prepareDrawerList;
    public static ActionBar actionbar;
    private boolean doubleBackToExitPressedOnce;
    boolean isPlayerIntent = false;

    ProgressIndicator mProgress;
    public static String TAG;
    Context context;
    ArrayList<HashMap<String, String>> temp;
    LinearLayout adContainer;
    String[] themes = {"Light", "Dark", "Automatic"};
    protected Configuration mPrevConfig;

    private LanguageListFragment languageFragment;

    //bottom player variables
    public static TextView tvStationBottom, tvSongBottom;
    public static ImageView ivPreviousBottom, ivNextBottom, ivPlayBottom, ivUpBottom;
    public static LinearLayout playerBottom;
    public static RelativeLayout loaderLay;
    ImageView gifImg;
    PlayerSingleton playerSingleton;
    FragmentStateSaver fragmentStateSaver;

    /**
     * Called when the activity is first created.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Thread.setDefaultUncaughtExceptionHandler(new UnCaughtException(MainActivity.this));
        setContentView(R.layout.main_layout);
        TAG = getClass().getName();
        mPrevConfig = new Configuration(getResources().getConfiguration());
        context = this;

        //  getTestIds();

        isGooglePlayServicesAvailable();

        ContextSingleton contextSingleton = ContextSingleton.getInstance();
        contextSingleton.setContext(context);

        if (checkInterstitialIsInit == 0) {
            InterstitialAdManager.getInstance().init(MainActivity.this);
        }

        //check app update available or not
        if (app_update_flag == 0) {
            app_update_flag = 1;
            InAppUpdateManager appUpdateHelper = new InAppUpdateManager(MainActivity.this, AppUpdateType.FLEXIBLE);
            appUpdateHelper.checkForUpdate();
        }

        playerSingleton = new PlayerSingleton();

        if (playerSingleton.getmMediaBrowserHelper() == null) {
            playerSingleton.init(MainActivity.this);
        }

        fragmentStateSaver = new FragmentStateSaver(findViewById(R.id.content_frame), getSupportFragmentManager()) {
            @Override
            public Fragment getItem(int position) {

                return new LanguageListFragment();

            }
        };

        //In App Review call
        InAppReview.app_launched(MainActivity.this);

        //FCM token
        FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(new OnCompleteListener<String>() {
                    @Override
                    public void onComplete(@NonNull Task<String> task) {
                        if (!task.isSuccessful()) {
                            Debugger.debugI(task.getException().getMessage(), "Fetching FCM registration token failed");
                            return;
                        }

                        // Get new FCM registration token
                        String token = task.getResult();

                        // Log and toast
                        String msg = token.toString();
                        Debugger.debugI(TAG, msg);

                    }
                });

        adContainer = findViewById(R.id.adContainer);

        //bottom player initialize
        loaderLay = findViewById(R.id.loader_lay);
        gifImg = findViewById(R.id.gif_img);
        ivNextBottom = findViewById(R.id.iv_next_bottom);
        ivPreviousBottom = findViewById(R.id.iv_previous_bottom);
        ivPlayBottom = findViewById(R.id.iv_play_bottom);
        ivUpBottom = findViewById(R.id.iv_up_button);
        tvStationBottom = findViewById(R.id.tv_station_bottom);
        tvSongBottom = findViewById(R.id.tv_song_bottom);
        playerBottom = findViewById(R.id.player_bottom);

        Glide.with(MainActivity.this).load(R.drawable.loading).into(gifImg);

        tvStationBottom.setSelected(true);
        tvSongBottom.setSelected(true);

        if (mIsPlaying) {
            tvSongBottom.setText(RMusicService.getAlbumTitle());
            if (selectedStation != null) {
                tvStationBottom.setText(selectedStation.ChannelTitle);
            }
        }
        try {
            // get last played save array
            ArrayList<Channel> lastPlayedArraylist = Utils.getArrayList(MainActivity.this, "lastPlayedArray");

            if (lastPlayedArraylist != null && lastPlayedArraylist.size() > 0) {
                // mStationArrayList.clear();
                PlaylistManager.checkClear = 1;
                Debugger.debugE(TAG, " last station list after save - " + lastPlayedArraylist.size());
                mStationArrayList = lastPlayedArraylist;
                PlaylistManager.setStation_list(lastPlayedArraylist, 1);
                tvStationBottom.setText(lastPlayedArraylist.get(Utils.getInt(context, "position", 0)).ChannelTitle);

            }

            // get last played station
            if (Utils.getString(MainActivity.this, "lastStation", "") != null) {
                selectedStation = new Gson().fromJson(Utils.getString(MainActivity.this, "lastStation", ""), Channel.class);
                Debugger.debugE(TAG, " last station after save - " + selectedStation.ChannelTitle);

                for (int i = 0; i < lastPlayedArraylist.size(); i++) {
                    if (selectedStation.ChannelId.equals(lastPlayedArraylist.get(i).ChannelId)) {
                        Debugger.debugE(TAG, "last played index is " + i);
                        PlaylistManager.setCurrentIndex(i);
                        break;
                    }
                }
            }
            // here we check
            if (lastPlayedArraylist != null && Utils.getString(MainActivity.this, "lastStation", "") != null) {
                checkPlayerIsPlay = 1;
                //mIsPlaying = true;
            } else {
                checkPlayerIsPlay = 0;
                //mIsPlaying = false;
            }
        } catch (Exception ee) {

        }

        globals = ((Globals) getApplicationContext());

        dw_entry_theme = "Theme (" + themes[Utils.getInt(MainActivity.this, "mode", 0)] + ")";

        // Register to receive messages.
        //Push notification reg-unreg request handler
        LocalBroadcastManager.getInstance(this).registerReceiver(GCMRequestReceiver, new IntentFilter("GCM-on-off-event"));
        //app ready and show rater & update dialog handler
        //  LocalBroadcastManager.getInstance(this).registerReceiver(AppReadyReceiver, new IntentFilter("App-Ready"));

        //load detail view
        mPosition = (savedInstanceState == null) ? 0 : savedInstanceState.getInt(SELECTED_DRAWER_ITEM, 0);
        doMainOpration(PrepareDrawerList.dw_entry_Genre);

        actionbar = getSupportActionBar();

        // Getting a reference to the drawer listview
        mDrawerList = (ListView) findViewById(R.id.drawer_list);

        // Getting a reference to the sidebar drawer ( Title + ListView )
        mDrawer = (LinearLayout) findViewById(R.id.drawer);

        // Getting reference to DrawerLayout
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);

        // Creating a ToggleButton for NavigationDrawer with drawer event listener
        mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, R.string.drawer_open, R.string.drawer_close) {

            private CharSequence Title;

            /** Called when drawer is closed */
            public void onDrawerClosed(View view) {

                actionbar.setDisplayShowTitleEnabled(true);

                setActionBarArrowDependingOnFragmentsBackStack();
                if (mPosition != -1) {
                    Group currentGroup = ((EntryItem) prepareDrawerList.getItem(mPosition)).group;
                    if (currentGroup == Group.Main)
                        doMainOpration(((EntryItem) prepareDrawerList.getItem(mPosition)).title);
                    else if (currentGroup == Group.More)
                        doMoreOperation(((EntryItem) prepareDrawerList.getItem(mPosition)).title);
                    if (!"Videos".equalsIgnoreCase(mAdapter.getSelectedTitle())) {
                        actionbar.setTitle(mAdapter.getSelectedTitle());
                        Debugger.debugI(TAG, " actionTitle 1 " + mAdapter.getSelectedTitle());
                    }
                } else {
                    actionbar.setTitle(Title);
                    Debugger.debugI(TAG, " actionTitle 2 " + Title);
                }
            }

            /** Called when a drawer is opened */
            public void onDrawerOpened(View drawerView) {

                Title = actionbar.getTitle();
              //  actionbar.setTitle(getResources().getString(R.string.app_name));

                mDrawerToggle.setDrawerIndicatorEnabled(true);
                mPosition = -1;
                globals.hideKeyboard(MainActivity.this);
            }
        };

        // Setting event listener for the drawer
        mDrawerLayout.addDrawerListener(mDrawerToggle);
        getSupportFragmentManager().addOnBackStackChangedListener(new FragmentManager.OnBackStackChangedListener() {
            @Override
            public void onBackStackChanged() {
                setActionBarArrowDependingOnFragmentsBackStack();
            }
        });

        // ItemClick event handler for the drawer items
        mDrawerList.setOnItemClickListener(this);

        // Enabling Up navigation
        actionbar.setDisplayHomeAsUpEnabled(true);
        actionbar.setDisplayShowHomeEnabled(true);

        // Setting the adapter to the listView
        mDrawerList.setAdapter(mAdapter);

        ivUpBottom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (PlaylistManager.checkClear == 1) {
                    stopRecordPlayerAudio();
                }
                if (/*!RecordedManager.isPlaying() &&*/ PlaylistManager.getStationList() != null && PlaylistManager.getStationList().size() > 0 && PlaylistManager.checkClear == 1/*&& checkPlayerIsPlay == 1*/) {
                    clickCommonForAll(MainActivity.this, 564544);
                } else {
                    Utils.showToast(MainActivity.this, MM_PLZ_SELECT_STATION);
                }
            }
        });

        playerBottom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (PlaylistManager.checkClear == 1) {
                    stopRecordPlayerAudio();
                }

                ArrayList<Channel> stationList = PlaylistManager.getStationList();
                boolean recIsPlay = RecordedManager.isPlaying();

                if (/*!recIsPlay &&*/ stationList != null && stationList.size() > 0 && PlaylistManager.checkClear == 1/*&& checkPlayerIsPlay == 1*/) {
                    clickCommonForAll(MainActivity.this, 564544);
                } else {
                    Utils.showToast(MainActivity.this, MM_PLZ_SELECT_STATION);
                }
            }
        });

        ivPlayBottom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (PlaylistManager.checkClear == 1) {
                    stopRecordPlayerAudio();
                }

                if (/*!RecordedManager.isPlaying() &&*/ PlaylistManager.getStationList() != null && PlaylistManager.getStationList().size() > 0 && PlaylistManager.checkClear == 1/*&& checkPlayerIsPlay == 1*/) {

                    if (!checkIsRecording(Constant.MM_ActionID_StopPlaying)) {
                        Debugger.debugD(TAG, "click of lock screen play button - if not recording");
                        if (ConnectionDetector.internetCheck(MainActivity.this))

                            if (!mIsPlaying) {
                                Debugger.debugD(TAG, "cloudus - MainActivity play -  if");
                                playerSingleton.playTrack();
                                fetchStationURL(MainActivity.this, getApplicationContext());

                                mIsPlaying = true;
                                ivPlayBottom.setImageResource(R.drawable.player_layout_stop_icon);

                            } else {
                                Debugger.debugD(TAG, "cloudus - MainActivity stop - else");
                                RMusicService.play_stop_Event(globals, MainActivity.this);
                                playerSingleton.stopTrack();
                                mIsPlaying = false;
                                ivPlayBottom.setImageResource(R.drawable.player_layout_play_icon);
                            }

                    }
                    updateItemAtPosition();
                } else {
                    Utils.showToast(MainActivity.this, MM_PLZ_SELECT_STATION);
                }
            }
        });

        ivPreviousBottom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (PlaylistManager.checkClear == 1) {
                    stopRecordPlayerAudio();
                }
                if (/*!RecordedManager.isPlaying() &&*/ PlaylistManager.getStationList() != null && PlaylistManager.getStationList().size() > 0 && PlaylistManager.checkClear == 1 /*&& checkPlayerIsPlay == 1*/) {
                    setSongLabel(MM_Song_Info_Not_Found);
                    playerSingleton.previousTrack();
                } else {
                    Utils.showToast(MainActivity.this, MM_PLZ_SELECT_STATION);
                }
            }
        });

        ivNextBottom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (PlaylistManager.checkClear == 1) {
                    stopRecordPlayerAudio();
                }
                if (/*!RecordedManager.isPlaying() &&*/ PlaylistManager.getStationList() != null && PlaylistManager.getStationList().size() > 0 && PlaylistManager.checkClear == 1/*&& checkPlayerIsPlay == 1*/) {
                    setSongLabel(MM_Song_Info_Not_Found);
                    playerSingleton.nextTrack();
                } else {
                    Utils.showToast(MainActivity.this, MM_PLZ_SELECT_STATION);
                }
            }
        });

    }

    private void stopRecordPlayerAudio() {
        if (RecordedPlayerService.rPlayer != null && RecordedPlayerService.rPlayer.isPlaying()) {
            // RecordedManager.setIsPlayingFlag(false);
            if (RecordedFragment.seekLayout != null) {
                RecordedFragment.seekLayout.setVisibility(View.GONE);
            }
            RecordedPlayerService.stopPLaying();
            RecordedManager.init();
        }
    }

    private BroadcastReceiver GCMRequestReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (mAdapter != null)
                mAdapter.notifyDataSetChanged();
        }
    };

    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Bundle extra = intent.getExtras();
        if (extra != null) {
            if (extra.getBoolean("requiredRecordedView", false)) {
                Debugger.debugI(TAG, "New intent called");
                requiredRecordedView = true;
                setIntent(intent);
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        Globals.activityPaused();
    }

    int requestCode = 1;

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // You can use the requestCode to select between multiple child
        // activities you may have started. Here there is only one thing we launch.
        if (requestCode == this.requestCode) {
            if (resultCode == Activity.RESULT_OK) {

                switch (data.getIntExtra("actionID", 0)) {
                    case Constant.MM_ActionID_StopPlaying:
                        if (ConnectionDetector.internetCheck(MainActivity.this)) {
                            RMusicService.stopStation(MainActivity.this);
                        }
                        //RMusicService.play_stop_Event(((Globals) getApplicationContext()), LockScreenPlayer.this);
                        break;
                    case Constant.MM_ActionID_PlayPrev:
                        globals.radioServiceActivity = MainActivity.this;
                        RMusicService.stopStation(MainActivity.this);

                        PlayPrevious(MainActivity.this, getApplicationContext());
                        break;
                    case Constant.MM_ActionID_PlayNext:
                        globals.radioServiceActivity = MainActivity.this;
                        RMusicService.stopStation(MainActivity.this);
                        PlayNext(MainActivity.this, getApplicationContext());
                        break;

                    default:
                        break;
                }
            }
        }
    }

    public static void PlayNext(Context ActivityContext, Context ApplicationContext) {
        ArrayList<Channel> allStationArray = PlaylistManager.getStationList();
        int index = PlaylistManager.getCurrentIndex();
        if (index < allStationArray.size() - 1) {
            PlaylistManager.setCurrentIndex(index + 1);
        } else {
            PlaylistManager.setCurrentIndex(0);
        }

        if (allStationArray != null && !allStationArray.isEmpty() && allStationArray.size() > 0)
            setStationLabel(PlaylistManager.getStationList().get(index).ChannelTitle);
        fetchStationURL(ActivityContext, ApplicationContext);

        RMusicService.currentPlayingName = ActivityContext.getString(R.string.song_info_not_found);
        setSongLabel(RMusicService.currentPlayingName);

        Globals globals = ((Globals) ActivityContext.getApplicationContext());

        globals.setLastPlayedIndex(index);
        Bundle bundle = new Bundle();
        bundle.putString(AnalyticsConstants.EVENT_CATEGORY, AnalyticsConstants.EC_lockplayer);
        bundle.putString("playing_station_name", PlaylistManager.getStationList().get(index).ChannelTitle);
    }

    public static void PlayPrevious(Context ActivityContext, Context ApplicationContext) {

        ArrayList<Channel> allStationArray = PlaylistManager.getStationList();
        int index = PlaylistManager.getCurrentIndex();

        if (index > 0) {
            PlaylistManager.setCurrentIndex(index - 1);
        } else {
            PlaylistManager.setCurrentIndex(allStationArray.size() - 1);
        }

        if (allStationArray != null && !allStationArray.isEmpty() && allStationArray.size() > 0)
            setStationLabel(allStationArray.get(index).ChannelTitle);

        fetchStationURL(ActivityContext, ApplicationContext);

        RMusicService.currentPlayingName = ActivityContext.getString(R.string.song_info_not_found);
        setSongLabel(RMusicService.currentPlayingName);
        Globals globals = ((Globals) ActivityContext.getApplicationContext());

        globals.setLastPlayedIndex(index);
        Bundle bundle = new Bundle();
        bundle.putString(AnalyticsConstants.EVENT_CATEGORY, AnalyticsConstants.EC_lockplayer);
        bundle.putString("playing_station_name", allStationArray.get(index).ChannelTitle);
    }

    public void openInterruptActivity(Bundle bundle) {
        // Start the activity whose result we want to retrieve.
        // The result will come back with request code GET_CODE.
        Intent intent = new Intent(MainActivity.this, showRecordingInterruptDialogActivity.class);
        intent.putExtras(bundle);
        startActivityForResult(intent, requestCode);
    }

    public boolean checkIsRecording(int actionCode) {

        if (PlaylistManager.isRecording()) {
            Bundle bundle = new Bundle();
            bundle.putInt("actionID", actionCode);
            openInterruptActivity(bundle);
            return true;
        } else {
            return false;
        }
    }

    @Override
    protected void onPostResume() {
        super.onPostResume();
        Debugger.debugI(TAG, "onPostResume called");
        if (requiredRecordedView) {
            if (mPosition != 5) {
                mPosition = 5;
                ((DrawerSectionListAdapter) mDrawerList.getAdapter()).setSelectedTitle(PrepareDrawerList.dw_entry_Recorded);
                Debugger.debugI(TAG, "requiredRecordedView : true, so load Recorded Fragment as top");
                doMainOpration(PrepareDrawerList.dw_entry_Recorded);
            }
        }
        requiredRecordedView = false;
    }

    public void isGooglePlayServicesAvailable() {
        int resultCode = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(context);

        if (resultCode == ConnectionResult.SUCCESS) {
            Debugger.debugI(TAG, "isGooglePlayServicesAvailable SUCCESS");
        } else {
            GoogleApiAvailability.getInstance().getErrorDialog(this, resultCode, RQS_GooglePlayServices);
        }
    }

    //  if user change mode(dark and light) uiMode using shortcut
    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        configurationChanged(newConfig);
        mPrevConfig = new Configuration(newConfig);
    }

    //restart app code while theme change
    protected void configurationChanged(Configuration newConfig) {
        if (Utils.getInt(this, "mode", 0) == 2)
            ProcessPhoenix.triggerRebirth(context, new Intent(this, SplashScreenActivity.class));
    }

    public void setNavigationListAdapter() {
        prepareDrawerList = new PrepareDrawerList();
        if (mAdapter == null)
            mAdapter = new DrawerSectionListAdapter(this, prepareDrawerList.getDrawerList(MainActivity.this, globals));
        else
            mAdapter.refreshAdapter(prepareDrawerList.getDrawerList(MainActivity.this, globals));

        // Setting the adapter to the listView
        if (mDrawerList.getAdapter() == null)
            mDrawerList.setAdapter(mAdapter);
    }

    public void getTestIds() {
        List<String> testDeviceIds = Arrays.asList("714B0A918A761A9A072162CFFD5EDB06");
        RequestConfiguration configuration =
                new RequestConfiguration.Builder().setTestDeviceIds(testDeviceIds).build();
        MobileAds.setRequestConfiguration(configuration);
    }

    private void setActionBarArrowDependingOnFragmentsBackStack() {
        int backStackEntryCount = getSupportFragmentManager().getBackStackEntryCount();
        boolean shouldEnableDrawerIndicator = backStackEntryCount == 0;
        mDrawerToggle.setDrawerIndicatorEnabled(shouldEnableDrawerIndicator);
    }

    @Override
    public void onItemClick(AdapterView<?> arg0, View view, int position, long arg3) {

        EntryItem item = (EntryItem) prepareDrawerList.getItem(position);
        closeDrawer();
        if (item.group == Group.Notification) {
            if (!globals.isRequestPandding()) {
                ((ProgressBar) view.findViewById(R.id.GCM_progressBar)).setVisibility(View.VISIBLE);
                globals.setRequestPandding(true);
            }
        } else if (item.group == Group.More) {
            mPosition = position;
            mDrawerLayout.closeDrawer(mDrawer);
        } else if (item.group == Group.Main && !mAdapter.getSelectedTitle().equalsIgnoreCase(item.title)) {
            if (!item.title.equalsIgnoreCase(PrepareDrawerList.dw_entry_Add_Station))
                mAdapter.setSelectedTitle(item.title);
            mPosition = position;
            mDrawerLayout.closeDrawer(mDrawer);
        }
    }

    public void closeDrawer() {
        if (mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            mDrawerLayout.closeDrawer(GravityCompat.START);
        }
    }

    @Override
    public void onBackPressed() {
        if (mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            mDrawerLayout.closeDrawer(GravityCompat.START);
        } else if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
            InterstitialDismissListener interstitialDismissListener = this;
            if (InterstitialAdManager.getInstance().showInterstitial(MainActivity.this) && InterstitialUtils.getInstance().interstitialAd != null) {
                InterstitialUtils.getInstance().displayInterstitialAd(MainActivity.this, interstitialDismissListener, 0);
            }
//            Fragment currentFragment = getSupportFragmentManager().findFragmentById(R.id.content_frame);
//            if (currentFragment instanceof ChannelListFragment) {
//                boolean isHandled = ((ChannelListFragment) currentFragment).onBackPressed();
//                if (isHandled) {
//                    return;
//                }
//            }
//            getSupportFragmentManager().popBackStack();
            super.onBackPressed();
        } else {
            if (PlaylistManager.isPlaying() || RecordedManager.isPlaying()) {
                MainActivity.this.moveTaskToBack(true);
            } else {
                if (doubleBackToExitPressedOnce) {
                    DBHelper.getDBHelper(MainActivity.this).closeDB();
                    globals.clearCache();
                    internetFlag = 0;
                    checkInterstitialIsInit = 0;
                    InterstitialUtils.getInstance().removeAd();
                    BannerAdsUtil.getInstance().removeAdView();
                    NativeAdsUtils.getInstance().removeAdView();
                    super.onBackPressed();
                    return;
                }
                this.doubleBackToExitPressedOnce = true;
                Utils.showToast(this, Constant.Exit_message);

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        doubleBackToExitPressedOnce = false;
                    }
                }, 2000);
            }
        }

        if (mStationArrayList != null && mStationArrayList.size() > 0) {
            Utils.saveArrayList(MainActivity.this, mStationArrayList, "lastPlayedArray");
        }

        if (selectedStation != null) {
            Utils.saveString(MainActivity.this, "lastStation", new Gson().toJson(selectedStation));
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        // Unregister since the activity is about to be closed.
        LocalBroadcastManager.getInstance(this).unregisterReceiver(GCMRequestReceiver);
        //   LocalBroadcastManager.getInstance(this).unregisterReceiver(AppReadyReceiver);

        stopService(new Intent(MainActivity.this, RecordedPlayerService.class));
        stopService(new Intent(MainActivity.this, RMusicService.class));
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        //save current showing position
        outState.putInt(SELECTED_DRAWER_ITEM, mPosition);
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        mDrawerToggle.syncState();
    }

    @Override
    protected void onResume() {
        super.onResume();

        Globals.activityResumed();

        setNavigationListAdapter();
        BannerAdsUtil.showBannerAd(this, findViewById(R.id.adContainer));

        if (Utils.getInt(MainActivity.this, "mode", 0) == 0) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        } else if (Utils.getInt(MainActivity.this, "mode", 0) == 1) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_UNSPECIFIED);

            if (getSystemMode(MainActivity.this) == Configuration.UI_MODE_NIGHT_NO) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
            } else if (getSystemMode(MainActivity.this) == Configuration.UI_MODE_NIGHT_YES) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            }
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {

            case android.R.id.home:
                if (mDrawerToggle.isDrawerIndicatorEnabled() && mDrawerToggle.onOptionsItemSelected(item)) {
                    return true;
                } else if (item.getItemId() == android.R.id.home && getSupportFragmentManager().popBackStackImmediate()) {
                    return true;
                }

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    //select category from drawer
    public void doMainOpration(String title) {
        globals.hideKeyboard(MainActivity.this);

        if (title.equalsIgnoreCase(PrepareDrawerList.dw_entry_Genre)) {
            clickCommonForAll(MainActivity.this, 111121);

        } else if (title.equalsIgnoreCase(PrepareDrawerList.dw_entry_Search)) {
            clickCommonForAll(MainActivity.this, 111122);
        } else if (title.equalsIgnoreCase(PrepareDrawerList.dw_entry_Favorites)) {
            clickCommonForAll(MainActivity.this, 111123);

        } else if (title.equalsIgnoreCase(PrepareDrawerList.dw_entry_Video)) {
            //addFragment(new YoutubeListFragment());
            //addFragment(new LanguageListFragment());
//            actionbar.setTitle(PrepareDrawerList.dw_entry_Genre);
//            mAdapter.setSelectedTitle(PrepareDrawerList.dw_entry_Genre);
            clickCommonForAll(MainActivity.this, 511522);

        } else if (title.equalsIgnoreCase(PrepareDrawerList.dw_entry_Recorded)) {
            clickCommonForAll(MainActivity.this, 111125);
        } else if (title.equalsIgnoreCase(PrepareDrawerList.dw_entry_Add_Station)) {
            temp = globals.fetchUserAddedStationList(context);
            show();

        } else if (title.equalsIgnoreCase(PrepareDrawerList.dw_entry_History)) {
            clickCommonForAll(MainActivity.this, 111124);

        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        playerSingleton.startConnection();
    }

    //add own station dialog
    public void show() {
        // Create custom dialog object
        androidx.appcompat.app.AlertDialog.Builder builder;

        builder = new androidx.appcompat.app.AlertDialog.Builder(context);

        View dialogLayout = getLayoutInflater().inflate(R.layout.add_own_station_layout, null);
        builder.setView(dialogLayout);
        // Set dialog title
        builder.setTitle(PrepareDrawerList.dw_entry_Add_Station);
        builder.setCancelable(true);

        // set values for custom dialog components - text, image and button
        final EditText et_stationName = (EditText) dialogLayout.findViewById(R.id.et_stationName);
        final EditText et_stationURL = (EditText) dialogLayout.findViewById(R.id.et_stationURL);

        builder.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                dialog.dismiss();
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        builder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if (isValidFields(et_stationName, et_stationURL)) {
                    Utils.showToast(context, et_stationName.getText().toString().trim() + " added under Favorites");
                    HashMap<String, String> station = new HashMap<String, String>();
                    int randomNumber = Utils.generateRandomNumber(1000, 9999);
                    station.put(Constant.MM_OWN_STATION_RANDOM_ID, "" + randomNumber);
                    station.put(Constant.MM_OWN_STATION_NAME, et_stationName.getText().toString().trim());
                    station.put(Constant.MM_OWN_STATION_URL, et_stationURL.getText().toString().trim());
                    temp.add(station);
                    globals.saveUserAddedStationList(context, temp);

                    //  for refresh favourite fragment after added station
                    Fragment fragmentInstance = getSupportFragmentManager().findFragmentById(R.id.content_frame);
                    if (fragmentInstance instanceof FavoritesFragment) {
                        addFragment(new FavoritesFragment());
                    }

                    dialogInterface.dismiss();

                }
            }
        });

        builder.show();
    }

    public boolean isValidFields(EditText et_stationName, EditText et_stationURL) {

        boolean isValid = true;
        //Station name
        if (et_stationName.getText().toString().trim().length() == 0) {
            et_stationName.setError(Constant.MM_MSG_PLEASE_ENTER_STATION_NAME);
            Utils.showToast(context, Constant.MM_MSG_PLEASE_ENTER_STATION_NAME);
            isValid = false;
        } else
            et_stationName.setError(null);

        //Station URL
        if (et_stationURL.getText().toString().trim().length() == 0) {
            et_stationURL.setError(Constant.MM_MSG_PLEASE_ENTER_STATION_URL);
            Utils.showToast(context, Constant.MM_MSG_PLEASE_ENTER_STATION_URL);
            isValid = false;
            return isValid;
        } else {
            et_stationURL.setError(null);
        }

        //URL validation
        if (!URLUtil.isValidUrl(et_stationURL.getText().toString().trim())) {
            et_stationURL.setError(Constant.MM_MSG_PLEASE_ENTER_VALID_STATION_URL);
            Utils.showToast(context, Constant.MM_MSG_PLEASE_ENTER_VALID_STATION_URL);
            isValid = false;
            return isValid;
        } else {
            et_stationURL.setError(null);
        }

        //URL Exist
        if (isStationUrlAlreadyExist(et_stationURL.getText().toString().trim())) {
            et_stationURL.setError(Constant.MM_MSG_ENTERED_STATION_URL_ALREADY_EXIST);
            Utils.showToast(context, Constant.MM_MSG_ENTERED_STATION_URL_ALREADY_EXIST);
            isValid = false;
        } else {
            et_stationURL.setError(null);
        }
        return isValid;
    }

    public boolean isStationUrlAlreadyExist(String URL) {
        int count = temp.size();
        for (int i = 0; i < count; i++) {
            if (temp.get(i).get(Constant.MM_OWN_STATION_URL).equalsIgnoreCase(URL))
                return true;
        }
        return false;
    }

    // purchase product by ID
    public void purchase(String productId) {

        try {
            InAppBillingManager inAppBillingManager = InAppBillingManager.getSharedInstance();
            inAppBillingManager.purchase(MainActivity.this, productId, new InAppBillingManager.IInAppBillingPurchaseListener() {
                @Override
                public void onPurchaseSuccess(String sku, PurchaseInfo purchaseInfo) {
                    Debugger.debugI(TAG, "productID -- " + sku);
                    Debugger.debugI(TAG, "Info -- " + purchaseInfo.toString());


                    if (purchaseInfo != null) {
                        Debugger.debugI(TAG, "getInfo success");

                        if (sku.equalsIgnoreCase(getResources().getString(R.string.In_app_product_ads_id))) {

                            Debugger.debugI(TAG, "option 1");

                            Utils.saveInt(MainActivity.this, getResources().getString(R.string.In_app_product_ads_id), 1);
                            adContainer.removeAllViews();
                            adContainer.setVisibility(View.GONE);
                            doMainOpration(PrepareDrawerList.dw_entry_Genre);

                        } else if (sku.equalsIgnoreCase(Constant.SKU_PremiumRecording)) {

                            Debugger.debugI(TAG, "option 2");
                            globals.setMaxRecordingTime(30);
                            globals.showCustomMessageOK(MainActivity.this, getString(R.string.app_name) + "!", "Congratulations! You have successfully Owned to \"Premium Recording\"", false);

                        }
                        setNavigationListAdapter();
                    }

                }

                @Override
                public void onPurchaseFailed(String sku, InAppBillingManager.InAppBillingError errorCode, String error) {
                    Debugger.debugI(TAG, "onPurchaseFailed: " + error);
                }
            });
        } catch (Exception ee) {
            Debugger.debugI("CCC", ee.getMessage());
        }
    }

    protected void doMoreOperation(String title) {
        globals.hideKeyboard(MainActivity.this);

        if (title.equalsIgnoreCase(PrepareDrawerList.dw_entry_RemoveAds)) {
            if (ConnectionDetector.internetCheck(MainActivity.this)) {
                purchase(getResources().getString(R.string.In_app_product_ads_id));
            }

        } else if (title.equalsIgnoreCase(PrepareDrawerList.dw_entry_Upgrade_Recording)) {
            if (ConnectionDetector.internetCheck(MainActivity.this)) {
                purchase(Constant.SKU_PremiumRecording);
            }
        } else if (title.equalsIgnoreCase(dw_entry_theme)) {

            if (PlaylistManager.isRecording()) {
                Utils.showToast(context, MM_STOP_RECORDING_FIRST);
                return;
            }
            chooseTheme(context);

        } else if (title.equalsIgnoreCase(PrepareDrawerList.dw_entry_MoreApps)) {
            if (ConnectionDetector.internetCheck(MainActivity.this)) {
                startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://play.google.com/store/apps/dev?id=" + MORE_APP_ID)));
            }

        } else if (title.equalsIgnoreCase(PrepareDrawerList.dw_entry_AboutUs)) {
            clickCommonForAll(MainActivity.this, 577588);


        } else if (title.equalsIgnoreCase(PrepareDrawerList.dw_entry_ContactUs)) {
            if (ConnectionDetector.internetCheck(MainActivity.this))
                contactUs();

        } else if (title.equalsIgnoreCase(PrepareDrawerList.dw_entry_TellAFriends)) {
            // doShare(MainActivity.this);
            String shareBody = Constant.Sharing_Message + "\n\nhttps://play.google.com/store/apps/details?id="
                    + getPackageName();
            Intent sharingIntent = new Intent(Intent.ACTION_SEND);
            sharingIntent.setType("text/plain");
            sharingIntent.putExtra(Intent.EXTRA_TEXT, shareBody);
            startActivity(Intent.createChooser(sharingIntent, "Share using"));

        } else if (title.equalsIgnoreCase(PrepareDrawerList.dw_entry_RateUs)) {
            if (ConnectionDetector.internetCheck(MainActivity.this))
                startActivity(new Intent(
                        "android.intent.action.VIEW",
                        Uri.parse("https://play.google.com/store/apps/details?id="
                                + getPackageName())));
        } else if (title.equalsIgnoreCase(PrepareDrawerList.dw_entry_PrivacyPolicy)) {
            if (ConnectionDetector.internetCheck(MainActivity.this))
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(Constant.Privacy_Link)));
        }
    }

    private void chooseTheme(Context context) {

        androidx.appcompat.app.AlertDialog.Builder dialog = new androidx.appcompat.app.AlertDialog.Builder(context)
                .setTitle("Select Theme");

        int checkedItem = Utils.getInt(MainActivity.this, "mode", 0);
        String[] themeArray = {"Light Mode", "Dark Mode", "Automatic (Default)"};

        dialog.setSingleChoiceItems(themeArray, checkedItem, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();

                int lastSelectedMode = Utils.getInt(MainActivity.this, "mode", 0);
                if (lastSelectedMode == which) {
                    return;
                }

                switch (which) {
                    case 0:
                        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                        Utils.saveInt(MainActivity.this, "mode", 0);
                        dw_entry_theme = "Theme (" + themes[0] + ")";
                        Debugger.debugI(TAG, "Light");
                        startActivity(new Intent(MainActivity.this, SplashScreenActivity.class));
                        finish();
                        break;
                    case 1:
                        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                        Utils.saveInt(MainActivity.this, "mode", 1);
                        dw_entry_theme = "Theme (" + themes[1] + ")";
                        Debugger.debugI(TAG, "Dark");
                        startActivity(new Intent(MainActivity.this, SplashScreenActivity.class));
                        finish();
                        break;
                    case 2:
                        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_UNSPECIFIED);

                        if (getSystemMode(MainActivity.this) == Configuration.UI_MODE_NIGHT_NO) {
                            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                        } else if (getSystemMode(MainActivity.this) == Configuration.UI_MODE_NIGHT_YES) {
                            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                        }
                        Utils.saveInt(MainActivity.this, "mode", 2);
                        dw_entry_theme = "Theme (" + themes[2] + ")";
                        Debugger.debugI(TAG, "Automatic");
                        ProgressDialog progressDialog = new ProgressDialog(MainActivity.this);
                        progressDialog.setCancelable(false);
                        progressDialog.setMessage("Please wait...");
                        progressDialog.show();
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                ProcessPhoenix.triggerRebirth(MainActivity.this, new Intent(MainActivity.this, SplashScreenActivity.class));
                            }
                        }, 1000);
                        break;
                }

            }
        });

        dialog.setCancelable(true);
        dialog.show();
    }

    public int getSystemMode(Activity activity) {
        return activity.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
    }

    void addFragment(Fragment fragment) {
        getSupportFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        ft.replace(R.id.content_frame, fragment, null);
        ft.commit();
    }

    public void processAfterAd(Context context, int buttonId) {

        if (buttonId == 564544) {    //player btn
            ArrayList<Channel> playList = Utils.getArrayList(MainActivity.this, "lastPlayedArray");

            if (playList != null) {

                String stationType = Utils.getString(context, "lastType", "");
                Debugger.debugE(TAG, "station type when tap on playerView - " + stationType);
                PlaylistManager.setStationType(stationType);
                Constant.mStationArrayList = playList;

                PlaylistManager.setPlayerDetail(MainActivity.this, Utils.getInt(context, "position", 0), playList);// position get remaining
            }
            flgForPlayerOpen = true;
        } else if (buttonId == 577588) {    //about btn
            Intent about_us_activity = new Intent(MainActivity.this, AboutUsActivity.class);
            startActivity(about_us_activity);
        } else if (buttonId == 511522) {    // youtube btn
            Intent intent = new Intent(MainActivity.this, YoutubeListActivity.class);
            startActivity(intent);
        } else if (buttonId == 111121) { // genre
            //languageFragment = new LanguageListFragment();
//            addFragment(languageFragment);
            fragmentStateSaver.changeFragment(0);
        } else if (buttonId == 111122) { //search
            addFragment(ChannelListFragment.newInstance(-99, true));
        } else if (buttonId == 111123) { //favourite
            addFragment(new FavoritesFragment());
        } else if (buttonId == 111124) { //history
            addFragment(new HistorylListFragment());
        } else if (buttonId == 111125) { //record
            addFragment(new RecordedFragment());
        }

    }

    public void clickCommonForAll(Activity activity, int buttonID) {

        if (InterstitialAdManager.getInstance().showInterstitial(activity) && InterstitialUtils.getInstance().interstitialAd != null) {
            InterstitialUtils.getInstance().displayInterstitialAd(MainActivity.this, MainActivity.this, buttonID);
        } else {
            processAfterAd(activity, buttonID);
        }
    }

    @Override
    public void onInterstitialDismissListener(Activity activity, int ButtonId) {
        processAfterAd(activity, ButtonId);
    }

    private void contactUs() {

        String stringBuilder = "\n\n\n\n\n\n\n-------------------------------------------" +
                "\nModel: " + globals.getDeviceName() +
                "\nSystemVersion: " + globals.getOsVersion() +
                "\nSystemName: " + globals.getOsName() +
                "\nCountry: " + globals.getDeviceCountry() +
                "\nCarrier: " + globals.getDeviceCarriers() +
                "\nCurrent Version Code (" + BuildConfig.VERSION_CODE + ")";

        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:"));
        intent.putExtra(Intent.EXTRA_EMAIL, new String[]{Constant.MAIL_ID});
        intent.putExtra(Intent.EXTRA_SUBJECT, "Indian Radio Android Feedback v" + BuildConfig.VERSION_NAME + "(" + globals.getDeviceName() + ", v" + globals.getOsVersion() + ")");
        intent.putExtra(Intent.EXTRA_TEXT, stringBuilder);
        startActivity(Intent.createChooser(intent, "Send Feedback"));
    }
}
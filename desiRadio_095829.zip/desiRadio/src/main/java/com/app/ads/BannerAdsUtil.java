package com.app.ads;

import android.app.Activity;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;

import com.app.firebase.FirebaseRemoteConfigUtils;
import com.app.utility.Constant;
import com.app.utility.Debugger;
import com.app.utility.Utils;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.indianradio.R;

public class BannerAdsUtil {

    public static AdView adView;
    Activity activity;
    AdRequest adRequest;
    private static BannerAdsUtil bannerInstance;
    public String TAG = getClass().getSimpleName();
    int height;

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public static BannerAdsUtil getInstance() {
        if (bannerInstance == null) {
            bannerInstance = new BannerAdsUtil();
            Debugger.debugI("Banner", "---------new instance-------------");
        }
        Debugger.debugI("Banner", "---------old instance-------------");
        return bannerInstance;
    }

    public void initBanner(Activity mActivity, LinearLayout parentView) {

        activity = mActivity;
        adView = new AdView(mActivity);

        adView.setAdUnitId(FirebaseRemoteConfigUtils.getInstance().getAdmobBannerID());
        parentView.addView(adView);

        adView.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                super.onAdClosed();
                Debugger.debugI(TAG, "onAdClosed: ");
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                super.onAdFailedToLoad(loadAdError);
                Debugger.debugI(TAG, "onAdFailedToLoad: " + loadAdError.getMessage());
            }

            @Override
            public void onAdOpened() {
                super.onAdOpened();
                Debugger.debugI(TAG, "onAdOpened: ");
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                Debugger.debugI(TAG, "onAdLoaded: ");

            }

            @Override
            public void onAdClicked() {
                super.onAdClicked();
                Debugger.debugI(TAG, "onAdClicked: ");
            }

            @Override
            public void onAdImpression() {
                super.onAdImpression();
                Debugger.debugI(TAG, "onAdImpression: ");
            }
        });


        loadBanner(parentView);

    }

    public void removeAdView() {
        adView = null;
    }

    private void loadBanner(LinearLayout parentView) {

        Debugger.debugI(TAG, "------------------Load Banner-------------------");

        adRequest = new AdRequest.Builder()
                .build();

        AdSize adSize = getAdSize();
        // Step 4 - Set the adaptive ad size on the ad view.
        adView.setAdSize(adSize);

        Debugger.debugI(TAG, "Banner Height -> " + adSize.getHeight());
        // Step 5 - Start loading the ad in the background.
        adView.loadAd(adRequest);
        setHeight(adSize.getHeightInPixels(activity));
        parentView.getLayoutParams().height = adSize.getHeightInPixels(activity);  //set view height

    }

    private AdSize getAdSize() {
        // Step 2 - Determine the screen width (less decorations) to use for the ad width.
        Display display = activity.getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);

        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;

        int adWidth = (int) (widthPixels / density);

        // Step 3 - Get adaptive ad size and return for setting on the ad view.
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(activity, adWidth);
    }

    public static void showBannerAd(Activity activity, LinearLayout layout) {
        Debugger.debugI("Banner", "---------call banner method------------");
        if (Utils.checkConnection(activity)) {
            Debugger.debugI("Banner", "---------check internet------------");
            if (Utils.getInt(activity, activity.getResources().getString(R.string.In_app_product_ads_id), 0) == 0)
            {
                Debugger.debugI("Banner", "---------check purchase------------");
                if (FirebaseRemoteConfigUtils.getInstance().getBannerType() == Constant.BannerEnum.ADMOB.ordinal()) {
                    Debugger.debugI("Banner", "---------check banner remote config------------");
                    if (adView != null) {
                        Debugger.debugI("Banner", "------------display banner---------");
                        ViewGroup parent = (ViewGroup) adView.getParent();
                        if (parent != null) {
                            parent.removeView(adView);
                        }

                        layout.addView(adView);
                        layout.getLayoutParams().height = getInstance().getHeight();
                    } else {
                        Debugger.debugI("Banner", "------------init banner---------");
                        BannerAdsUtil.getInstance().initBanner(activity, layout);
                    }
                }else {
                    layout.setVisibility(View.GONE);
                }
            } else {
                layout.setVisibility(View.GONE);
            }
        } else {

            layout.setVisibility(View.GONE);

        }
    }

}

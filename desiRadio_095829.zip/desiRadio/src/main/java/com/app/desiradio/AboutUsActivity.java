package com.app.desiradio;

import android.app.Activity;
import android.app.UiModeManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.core.app.NavUtils;

import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.android.youtube.YoutubeListActivity;
import com.app.ads.InterstitialAdManager;
import com.app.ads.InterstitialUtils;
import com.app.ads.interfaces.InterstitialDismissListener;
import com.app.utility.BaseActionBarActivity;
import com.app.utility.Constant;
import com.app.utility.Debugger;
import com.app.utility.Globals;
import com.app.utility.Utils;
import com.indianradio.R;
import com.jakewharton.processphoenix.ProcessPhoenix;

public class AboutUsActivity extends BaseActionBarActivity {

    Globals globals;
    String TAG;
    ProgressBar mProgress;
    RelativeLayout main_layout;
    protected Configuration mPrevConfig;

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        configurationChanged(newConfig);
        mPrevConfig = new Configuration(newConfig);
    }

    protected void configurationChanged(Configuration newConfig) {
        if (Utils.getInt(this, "mode", 0) == 2)
            ProcessPhoenix.triggerRebirth(AboutUsActivity.this, new Intent(this, SplashScreenActivity.class));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about_us_actiivity);

        globals = ((Globals) getApplicationContext());
        globals.hideKeyboard(AboutUsActivity.this);

        TAG = getClass().getName();
        mPrevConfig = new Configuration(getResources().getConfiguration());
        getSupportActionBar().setDisplayShowTitleEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(PrepareDrawerList.dw_entry_AboutUs);

        mProgress = (ProgressBar) findViewById(R.id.webProgressBar);

        WebView webView = (WebView) findViewById(R.id.webPage);
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webView.setVerticalScrollBarEnabled(false);
        webView.setBackgroundColor(0x00000000);
        webView.setWebViewClient(new webViewClient());
        webView.loadUrl(Constant.ShortLink_Aboutus);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        Globals.activityPaused();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Globals.activityResumed();
    }

    @Override
    public void onBackPressed() {
        if (InterstitialAdManager.getInstance().showInterstitial(AboutUsActivity.this) && InterstitialUtils.getInstance().interstitialAd != null) {
            InterstitialUtils.getInstance().displayInterstitialAd(AboutUsActivity.this, new InterstitialDismissListener() {
                @Override
                public void onInterstitialDismissListener(Activity activity, int ButtonId) {
                   finish();
                }
            }, 787875);
        } else {
            finish();
        }
    }

    private class webViewClient extends WebViewClient {

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            Debugger.debugI(TAG, "Web Page Loading...");
            view.loadUrl(url);
            return true;
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            Debugger.debugI(TAG, url);
            if (mProgress != null)
                mProgress.setVisibility(View.GONE);
        }

        @Override
        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            super.onReceivedError(view, errorCode, description, failingUrl);
            //page could not be loaded
            Debugger.debugI(TAG, "error :" + description);
            Utils.showToast(AboutUsActivity.this, "Failed to load page");
            AboutUsActivity.this.finish();
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            Debugger.debugI(TAG, "Webview loading URL: " + url);
            super.onPageStarted(view, url, favicon);
            if (mProgress == null) {
                mProgress = (ProgressBar) findViewById(R.id.webProgressBar);
                mProgress.setVisibility(View.VISIBLE);
            } else if (mProgress.getVisibility() != View.VISIBLE)
                mProgress.setVisibility(View.VISIBLE);
        }
    }
}

package com.app.utility;


import static com.app.auto.RMusicService.setAlbumTitle;
import static com.app.utility.Constant.MM_Song_Info_Not_Found;

import android.app.ActivityManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.support.v4.media.MediaBrowserCompat;
import android.support.v4.media.MediaDescriptionCompat;
import android.support.v4.media.MediaMetadataCompat;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;


import com.app.auto.RMusicService;
import com.app.desiradio.MainActivity;
import com.app.desiradio.PrepareDrawerList;
import com.app.firebase.FirebaseRemoteConfigUtils;
import com.app.parser.Channel;
import com.app.player.LockScreenPlayer;
import com.app.player.PlaylistManager;
import com.app.player.RadioPlayerActivity;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.indianradio.R;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Utils {

    public static String TAG = "Utils";

    public static int flagSplash = 0;
    public static int internetFlag = 0;
    public static int checkInterstitialIsInit = 0;      //check interstitial init already or not
    public static int app_update_flag;
    public static int appOpenAdFlag = 0;                //check app is in recent list
    public static int afterSplashFlag = 0;

    /** android auto start */

    public static int selectedPlayListCategory;     // for selection of current tab in android auto
    public static String SELECTED_MAIN_CATEGORY = "";

    public static ArrayList<Channel> channelInPlayListTemp = new ArrayList<>();
    public static ArrayList<Channel> channelInPlayList = new ArrayList<>();

    public static int checkPlayerIsPlay = 0;    //to check before recording to play or not

    public static String lastPlayedStation = null;

    //for selected channel's json data
    public static Channel selectedStation;

    //to check player is playing or not
    public static boolean isPLAY = false;

    public static boolean flgForPlayerOpen = false;

    //for get current album image's url
    public static String currentAlbumUrl = "";
    //for get current album title
    public static String albumTitle = "";

    public static String[] mainCategories = {"Browse", "Favourite", "History"};
    public static String[] mainCategoryIds = {Constant.BROWSE, Constant.FAVOURITE, Constant.HISTORY};

    public static List<MediaBrowserCompat.MediaItem> getCategories() {

        List<MediaBrowserCompat.MediaItem> mediaItemList = new ArrayList<>();
        int index = 0;
        for (String category : mainCategories) {

            MediaDescriptionCompat mediaDesc = new MediaDescriptionCompat.Builder()
                    .setMediaId(mainCategoryIds[index++])
                    .setTitle(category)
                    .build();

            mediaItemList.add(new MediaBrowserCompat.MediaItem(mediaDesc, MediaBrowserCompat.MediaItem.FLAG_BROWSABLE));
        }

        return mediaItemList;
    }

    public static void showToast(Context context,String msg){
        try {
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
        }catch (Exception ee){

        }
    }

    public static boolean showNativeOrNot(Context context){

        boolean bool = false;

        if (Utils.checkConnection(context)) {
            Debugger.debugI("Native", "---------check internet------------");
            if (Utils.getInt(context, context.getResources().getString(R.string.In_app_product_ads_id), 0) == 0) {
                Debugger.debugI("Native", "---------check purchase------------");
                if (FirebaseRemoteConfigUtils.getInstance().getNativeType() == Constant.NativeEnum.ADMOB.ordinal()) {
                    Debugger.debugI("Native", "---------check Native remote config------------");
                    bool = true;
                }
            }
        }
        return bool;
    }

    public static int getMediaPosition(String mediaId) {
        int selectedId = 0;

        ArrayList<Channel> channelsList = new ArrayList<>();
        channelsList = PlaylistManager.getStationList();

        for (int i = 0; i < channelsList.size(); i++) {

            if (channelsList.get(i).ChannelId.equals(mediaId)) {
                selectedId = i;
            }
        }

        return selectedId;
    }

    public static Channel nextStationModel(int currentIndex) {

        if (currentIndex < PlaylistManager.getStationList().size() - 1) {
            currentIndex = currentIndex + 1;
        } else {
            currentIndex = 0;
        }
        return PlaylistManager.getStationList().get(currentIndex);
    }

    public static Channel previousStationModel(int currentIndex) {

        if (currentIndex > 0) {
            currentIndex = currentIndex - 1;
        } else {
            currentIndex = PlaylistManager.getStationList().size() - 1;
        }

        return PlaylistManager.getStationList().get(currentIndex);
    }

    /** android auto end */

    public static boolean isMyServiceRunning(Context context,Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    public static int generateRandomNumber(int min , int max) {

        return new Random().nextInt((max - min) + 1) + min;
    }

    public static int generateRandomNumber(int arraySize) {

        int min = 1;
        int max = 4;

        if (arraySize < 5) {
            max = arraySize;
        }

        return new Random().nextInt((max - min) + 1) + min;
    }

    public static ArrayList<Integer> generateRandomListNative(int arraySize) {

        int randNo = generateRandomNumber(arraySize);

        ArrayList<Integer> nativeArrayList = new ArrayList<>();

        nativeArrayList.clear();
        for (int j = 0; j < arraySize; j++) {

            if (randNo < arraySize) {
                Debugger.debugI(TAG, "generateRandomListNative: " + randNo);
                nativeArrayList.add(randNo);
                randNo = randNo + 20;

            }

        }
        return nativeArrayList;
    }

    public static void showAlert(Context context, String message, String buttonTitle, DialogInterface.OnClickListener onClickListener) {
        AlertDialog.Builder dialog = new AlertDialog.Builder(context)
                .setTitle(R.string.app_name)
                .setMessage(message);

        dialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        dialog.setPositiveButton(buttonTitle, onClickListener);
        dialog.setCancelable(false);
        dialog.show();
    }

    //alert with two Button
    public static void showAlertPermission(Context context, String message, String buttonTitle, DialogInterface.OnClickListener onClickListener) {
        AlertDialog.Builder dialog = new AlertDialog.Builder(context)
                .setTitle("Permission Required")
                .setMessage(message);

        dialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        dialog.setPositiveButton(buttonTitle, onClickListener);
        dialog.setCancelable(false);
        dialog.show();
    }

    public static Uri getImageUri(Context mContext, Bitmap bitmap, String fileName) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(
                mContext.getContentResolver(), bitmap, fileName, null);
        return Uri.parse(path);
    }

    public static boolean saveInt(Context mContext, String key, int value) {
        if (key.equals("position")) {
            Debugger.debugE(TAG, "lastPosition is " + value);
        }
        SharedPreferences settings = mContext.getSharedPreferences("sp", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = settings.edit();
        editor.putInt(key, value);
        return editor.commit();
    }

    public static void changeActionBar(Context context, ActionBar actionBar,int actionBarColor, int backIcon, int textColor, String actionText) {
        Drawable upArrow = context.getResources().getDrawable(backIcon);
        upArrow.setColorFilter(textColor, PorterDuff.Mode.SRC_ATOP);
        actionBar.setHomeAsUpIndicator(upArrow);
        actionBar.setDisplayShowTitleEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);

        Spannable spannableTitle = new SpannableString(actionText);
        spannableTitle.setSpan(new ForegroundColorSpan(textColor), 0, spannableTitle.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        actionBar.setTitle(spannableTitle);

        actionBar.setBackgroundDrawable(new ColorDrawable(actionBarColor));
    }

    public static Spannable getTextWithColor(int textColor,String actionText){
        Spannable spannableTitle = new SpannableString(actionText);
        spannableTitle.setSpan(new ForegroundColorSpan(textColor), 0, spannableTitle.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        return spannableTitle;
    }

    //:GET INT FROM SP
    public static int getInt(Context mContext, String key, int defaultval) {
        SharedPreferences settings = mContext.getSharedPreferences("sp", Context.MODE_PRIVATE);
        return settings.getInt(key, defaultval);
    }

    //:SAVE STRING IN SP
    public static boolean saveString(Context mContext, String key, String value) {
        SharedPreferences settings = mContext.getSharedPreferences("sp", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = settings.edit();
        editor.putString(key, value);
        return editor.commit();
    }

    //:GET STRING FROM SP
    public static String getString(Context mContext, String key, String defaultval) {
        SharedPreferences settings = mContext.getSharedPreferences("sp", Context.MODE_PRIVATE);
        return settings.getString(key, defaultval);
    }

    public static boolean isNetworkConnected(Context c) {
        ConnectivityManager connectivityManager =
                (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    public static boolean checkConnection(Context con) {
        boolean isConnected = false;
        try {
            ConnectivityManager cm = (ConnectivityManager) con.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo netInfo = cm.getActiveNetworkInfo();
            if (netInfo != null && netInfo.isConnected()) {
                isConnected = true;
            } else {
                isConnected = false;
            }
        } catch (Exception ee) {

        }
        return isConnected;
    }

    public static void saveArrayList(Context context,ArrayList<Channel> list, String key){
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = prefs.edit();
        Gson gson = new Gson();
        String json = gson.toJson(list);
        editor.putString(key, json);
        editor.apply();     // This line is IMPORTANT !!!
    }

    public static ArrayList<Channel> getArrayList(Context context,String key){
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        Gson gson = new Gson();
        String json = prefs.getString(key, null);
        Type type = new TypeToken<ArrayList<Channel>>() {}.getType();
        return gson.fromJson(json, type);
    }

    public static void setStationLabel(String text){
        if (RadioPlayerActivity.stationNameLabel != null) {
            RadioPlayerActivity.stationNameLabel.setText(text);
        }
        if (MainActivity.tvStationBottom != null) {
            MainActivity.tvStationBottom.setText(text);
        }
        if (LockScreenPlayer.stationNameLabel != null) {
            LockScreenPlayer.stationNameLabel.setText(text);
        }
    }

    public static void setSongLabel(String text){
        Log.e(TAG, "setSongLabel: "+text );
        if (RadioPlayerActivity.songNameLabel != null ) {
            RadioPlayerActivity.songNameLabel.setText(text);
        }
        if (MainActivity.tvSongBottom != null) {
            MainActivity.tvSongBottom.setText(text);
        }
        if (LockScreenPlayer.songNameLabel != null ) {
            LockScreenPlayer.songNameLabel.setText(text);
        }
        setAlbumTitle(text);
    }

    public static void setDefaultDataPlayer(Context context,int songLabel,int imgAlbum){

        if (songLabel == 1) {

            if (RadioPlayerActivity.songNameLabel != null) {
                RadioPlayerActivity.songNameLabel.setText(MM_Song_Info_Not_Found);
            }
            if (LockScreenPlayer.songNameLabel != null) {
                LockScreenPlayer.songNameLabel.setText(MM_Song_Info_Not_Found);
            }
            RMusicService.setAlbumTitle(MM_Song_Info_Not_Found);
            RMusicService.currentPlayingName = MM_Song_Info_Not_Found;
        }

        if (imgAlbum == 1) {

            if (RadioPlayerActivity.currentSongImage != null) {
                RadioPlayerActivity.currentSongImage.setImageResource(R.drawable.player_img_view);
            }
            if (LockScreenPlayer.albumArtView != null) {
                LockScreenPlayer.albumArtView.setImageResource(R.drawable.player_img_view);
            }
            RMusicService.setAlbumUris(String.valueOf(Uri.parse("android.resource://" + context.getPackageName() + "/" + R.drawable.player_img_view)));
        }

    }

}

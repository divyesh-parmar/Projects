package com.app.player;

import android.annotation.SuppressLint;
import android.app.Activity;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnPreparedListener;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import com.app.sqlite.DBHelper;
import com.app.sqlite.Recording;
import com.app.utility.Debugger;
import com.app.utility.Globals;
import com.app.utility.Utils;
import com.indianradio.R;

import java.io.File;

public class showRecordingCompleteDialogActivity extends Activity {

	InputMethodManager imm;
	AlertDialog alert;
	TextView btn_ok;
	EditText input;
	
	String fName;
	File to;
	String stationName = "";
	String songName = "";
	String tempFilePath = "";
	int duration = 0;
	public String TAG; 
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		TAG = getClass().getName();
		
		Bundle data = getIntent().getExtras();
		if(data != null) {
			stationName = data.getString("stationName");
			songName = data.getString("songName");
			tempFilePath = data.getString("tempFilePath");
			duration = data.getInt("duration");
		}
		
		AlertDialog.Builder builder = new AlertDialog.Builder(this);

		builder.setCancelable(false);
		
//		builder.setIcon(R.drawable.ic_launcher);
//		builder.setTitle(getString(R.string.app_name));
		builder.setTitle("Save As");
		
		LayoutInflater factory = LayoutInflater.from(this);
		View view = factory.inflate(R.layout.custom_alert_layout, null);
		builder.setView(view);
		
		// Use an EditText view to get user input.
		TextView msg = (TextView)view.findViewById(R.id.tv_msg);
		msg.setText("Save As:");
		msg.setVisibility(View.GONE);
		
        input = (EditText)view.findViewById(R.id.input);
    	input.setInputType(InputType.TYPE_CLASS_TEXT);
    	input.setHint("Enter File Name");
    	input.setText((songName.length() > 0) ? songName : stationName);
		input.setSelection(input.getText().length());

    	input.setCursorVisible(false);
		input.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				input.setSelection(input.getText().length());
				input.setCursorVisible(true);
			}
		});

        input.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            	
            	if(input.getText().toString().trim().length() > 0) {
            		btn_ok.setEnabled(true);
            	} else {
            		btn_ok.setEnabled(false);
            	}
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

            @Override
            public void afterTextChanged(Editable s) { }
        });
		
		alert = builder.create();
		alert.show();
		
		btn_ok = view.findViewById(R.id.btn_ok);
		btn_ok.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				btn_ok.setEnabled(false);
				fName = input.getText().toString().trim();

				//Rename Existing file.
				Debugger.debugI(TAG, "tempFilePath : "+tempFilePath);
				
			    MediaPlayer mp = new MediaPlayer();
			    mp.setAudioStreamType(AudioManager.STREAM_MUSIC);
			    mp.setOnPreparedListener(new OnPreparedListener() {
					@Override
					public void onPrepared(MediaPlayer mp) {
						insertRecordingDetail(mp.getDuration(), mp);
					}
				});
			    
			    try {
					mp.setDataSource(tempFilePath);
					mp.prepare();
				} catch (Exception e) {
					e.printStackTrace();
					insertRecordingDetail(duration, mp);
				}
			}
		});
	}
	
	@SuppressLint("SuspiciousIndentation")
	private void insertRecordingDetail(long duration, MediaPlayer mp) {
		
		long timeStamp = System.currentTimeMillis();
		File from = new File(tempFilePath);
		to = new File(((Globals)getApplicationContext()).getDir(showRecordingCompleteDialogActivity.this), fName+"_"+timeStamp+".mp3");
	    from.renameTo(to);

		Utils.showToast(showRecordingCompleteDialogActivity.this, "Recorded File save successfully");
		
		DBHelper.getDBHelper(showRecordingCompleteDialogActivity.this).addRecording(new Recording(fName, stationName, String.valueOf(duration), to.getAbsolutePath(),       String.valueOf              (timeStamp)));
		if(mp != null) {
			mp.release();
			mp = null;
			Debugger.debugI(TAG, "Media player is release.");
		}
		
		// Wait 200ms to quit the Activity
		(new Handler()).postDelayed(mRunnerHide, 200);
	}

	Runnable mRunnerHide = new Runnable() {
	    public void run() {
	    	alert.dismiss();
	    	finish();
	    }
	};
}
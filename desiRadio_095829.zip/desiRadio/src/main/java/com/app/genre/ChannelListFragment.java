package com.app.genre;

import static com.app.utility.Utils.channelInPlayList;
import static com.app.utility.Utils.flgForPlayerOpen;

import static com.app.utility.Utils.lastPlayedStation;
import static com.app.utility.Utils.selectedPlayListCategory;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewSwitcher;

import com.app.ads.InterstitialAdManager;
import com.app.ads.InterstitialUtils;
import com.app.ads.NativeAdsUtils;
import com.app.ads.interfaces.InterstitialDismissListener;
import com.app.auto.RMusicService;
import com.app.desiradio.MainActivity;
import com.app.http.ConnectionDetector;
import com.app.parser.Channel;
import com.app.parser.Language;
import com.app.parser.Parser;
import com.app.player.PlaylistManager;
import com.app.player.RadioPlayerActivity;

import com.app.player.showRecordingInterruptDialogActivity;
import com.app.recorded.RecordedFragment;
import com.app.recorded.RecordedManager;
import com.app.recorded.RecordedPlayerService;
import com.app.utility.Constant;
import com.app.utility.Constant.PlayingMode;

import com.app.utility.Debugger;
import com.app.utility.Globals;
import com.app.utility.Utils;
import com.google.android.gms.ads.AdView;
import com.indianradio.R;

public class ChannelListFragment extends Fragment implements
        OnItemClickListener {

    View view;
    Globals globals;
    public static String TAG;

    Menu mOptionsMenu;
    MenuInflater mMenuInflater;

    TextView txt_title;
    EditText search_txt;
    Button btn_clear_search;

    ListView Channellist;
    public static RecyclerView rvChannels;
    // ChannelListAdapter adapter;
    public static ChannelListRAdapter adapter;
    ViewSwitcher switcher;
    ArrayList<Channel> mTempChannels;
    int mPosition;

    boolean isFirstAds = true;
    LinearLayout contentLayout, admoblayout, ad_dummyLayout;

    int tempPosition = -99;
    boolean onActivityResultCalled = false;
    int counter = 0;
    int flag = 0;
    String cname;


    // call through LanguageList fragment
    public static ChannelListFragment newInstance(int index, boolean isAllChannelview) {
        ChannelListFragment f = new ChannelListFragment();

        Bundle args = new Bundle();
        args.putInt("langIndex", index);
        args.putBoolean("isAllChannelview", isAllChannelview);
        f.setArguments(args);
        return f;
    }

    public int getSelectedIndex() {
        return getArguments().getInt("langIndex", 0);
    }

    public boolean isAllChannelview() {
        return getArguments().getBoolean("isAllChannelview", true);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        globals = ((Globals) getActivity().getApplicationContext());
        TAG = getClass().getName();
        setHasOptionsMenu(true);

        // remove native if already having
        NativeAdsUtils.getInstance().removeAdView();

        // clear native arraylist
        Constant.nativePlaceList.clear();


        // check - from come through searchFragment or languageListFragment
        if (isAllChannelview()) {
            selectedPlayListCategory = 4;
            ChannelManager.getListManager(isAllChannelview()).setStationList(globals, globals.getChannelList());
            cname = "Search";
        } else {
            ArrayList<Language> allLanguageList = globals.getLanguageList();
            if (allLanguageList != null && allLanguageList.size() > 0) {
                Language LanguageObj = (Language) allLanguageList.get(getSelectedIndex());
                if (LanguageObj.channels.size() > 0) {
                    ChannelManager.getListManager(isAllChannelview()).setStationList(globals, LanguageObj.channels);
                }else {

                }
                cname = LanguageObj.LanguageName;
            }
        }

        // set adapter
        adapter = new ChannelListRAdapter(getActivity(), PlayingMode.OTHER, new com.app.genre.OnItemClickListener() {

            //click of the recyclerview item
            @Override
            public void onItemClick(int position) {


                if (Utils.checkConnection(getActivity())) {

                    if (RecordedPlayerService.rPlayer != null /*&& RecordedPlayerService.rPlayer.isPlaying()*/) {
                        // RecordedManager.setIsPlayingFlag(false);
                        if (RecordedFragment.seekLayout != null) {
                            RecordedFragment.seekLayout.setVisibility(View.GONE);
                        }
                            RecordedPlayerService.stopPLaying();
                            RecordedManager.init();

                    }

                    // get channelItem
                    ChannelItem station = adapter.getItem(position);

                    {
                        ArrayList<Channel> tempChannels = globals.convertChannelMapList(adapter.getCurrentVisibleList());
                        int indexMap = globals.getCurrentIndexOfChannel(station.getChannelMap(), tempChannels);

                        // here we check the recording is already start  or not
                        if (!checkIsRecording(Constant.MM_ActionID_onSelectStation, indexMap)) {
                            // play station
//                            if (lastPlayedStation != null && lastPlayedStation.equals(tempChannels.get(position).ChannelLink)) {
//                                flgForPlayerOpen = true;
//                                PlaylistManager.playerIntent(getActivity());
//                            } else {
//                                playStation(indexMap, tempChannels);
//                                lastPlayedStation = tempChannels.get(position).ChannelLink;
//                            }

//                            PlaylistManager.setStationType("favorites");
                            playStation(indexMap, tempChannels);
                        } else {
                            // if that item is already play
                            tempPosition = indexMap;
                        }
                    }

                } else {
                    Utils.showToast(getActivity(), "Please check your Internet Connection");
                }

            }
        });


    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (cname != null && !cname.equalsIgnoreCase("search")) {
            ((MainActivity) getActivity()).mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);
            ((MainActivity) getActivity()).actionbar.setTitle("Genre");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.channel_list_fragment, container, false);

        ((MainActivity) getActivity()).actionbar.setTitle(cname);
        globals.hideKeyboard(getActivity());

        if (cname != null && !cname.equalsIgnoreCase("search")) {
            ((MainActivity) getActivity()).mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
        }

        rvChannels = view.findViewById(R.id.rv_channels);
        Channellist = (ListView) view.findViewById(R.id.ChannelList);
        Channellist.setOnItemClickListener(this);

        rvChannels.setLayoutManager(new GridLayoutManager(getActivity(), 1));

        btn_clear_search = (Button) view.findViewById(R.id.btn_clear_search);
        btn_clear_search.setVisibility(View.INVISIBLE);
        btn_clear_search.setClickable(false);


        btn_clear_search.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                btn_clear_search.setVisibility(View.INVISIBLE);
                btn_clear_search.setClickable(false);
                search_txt.setText(null);
            }
        });

        search_txt = (EditText) view.findViewById(R.id.search_txt);
        search_txt.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence cs, int arg1, int arg2, int arg3) {
                // When user changed the Text
                if (cs.toString().length() > 0) {
                    flag = 1;
                    btn_clear_search.setVisibility(View.VISIBLE);
                    btn_clear_search.setClickable(true);
                } else {
                    flag = 0;
                    btn_clear_search.setVisibility(View.INVISIBLE);
                    btn_clear_search.setClickable(false);
                }

                if (isAllChannelview())
                    ChannelManager.getListManager(isAllChannelview()).setSearchTerms(cs.toString());
                adapter.getFilter().filter(cs);
            }

            @Override
            public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
            }

            @Override
            public void afterTextChanged(Editable arg0) {
            }
        });

        switcher = (ViewSwitcher) view.findViewById(R.id.channelSwitcher);

        //Ads
        contentLayout = (LinearLayout) view.findViewById(R.id.contentLayout);
        ad_dummyLayout = (LinearLayout) view.findViewById(R.id.adLayout);
        admoblayout = (LinearLayout) view.findViewById(R.id.admoblayout);
        return view;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        if (!isAllChannelview())
            ChannelManager.getListManager(isAllChannelview()).init();
    }

    @Override
    public void onResume() {
        super.onResume();
        Debugger.debugI(TAG, "on resume called");

        globals.radioServiceActivity = getActivity();

        ArrayList<Channel> tempList = new ArrayList<Channel>();

        // here fetch all favourite list data and checkout all channels which one is add in favourite
        tempList = globals.fetchFavoriteList(getActivity());

        ArrayList<ChannelItem> channelArray = ChannelManager.getListManager(isAllChannelview()).getChannelList();
        int channelCount = channelArray.size();
        for (int i = 0; i < channelCount; i++) {
            String id = (channelArray.get(i)).getChannelMap().ChannelId;
            (channelArray.get(i)).getChannelMap().isFavorite = (favoriteIndex(tempList, id)) ? true : false;
        }

        // set searchable text
        String searchText = ChannelManager.getListManager(isAllChannelview()).getSearchTerms();
        if (isAllChannelview() && searchText != null) {
            search_txt.setText(searchText);
        }

        // if adapter is null
        if (rvChannels.getAdapter() == null) {

//        if (Channellist.getAdapter() == null) {
            // check total channel list is greater 0 or not
            if (channelCount > 0) {
                // set adapter
                setChannelAdapter(ChannelManager.getListManager(isAllChannelview()).getDisplayList());
            } else {
                // set text - data is empty
                switcher.setDisplayedChild(0);
            }
        } else {
            // if adapter not null then notify adapter
            adapter.notifyDataSetChanged();

            if (search_txt.getText().toString().trim().length() > 0) {
                adapter.getFilter().filter(search_txt.getText().toString().trim());
            }
        }

        // create menus
        invalidOptionsMenuHelper();

        if (onActivityResultCalled)
            counter++;


        if (counter == 2 && tempPosition != -99) {
            if (!PlaylistManager.isPlaying()) {
                playStation(tempPosition, globals.convertChannelMapList(adapter.getCurrentVisibleList()));
            }
            tempPosition = -99;
            counter = 0;
            onActivityResultCalled = false;
        }
    }

    // set channel adapter
    private void setChannelAdapter(ArrayList<ChannelItem> channelList) {
        switcher.setDisplayedChild(1);
        adapter.refreshList(channelList);

        if (rvChannels.getAdapter() == null) {
            if (Utils.showNativeOrNot(getActivity())) {
                // generate random number for native display
                Constant.nativePlaceList = Utils.generateRandomListNative(channelList.size());
            }
            rvChannels.setAdapter(adapter);
        }
        if (search_txt.getText().toString().trim().length() > 0) {
            adapter.getFilter().filter(search_txt.getText().toString().trim());
        }
    }

    // get favourite item
    public Boolean favoriteIndex(ArrayList<Channel> tempList, String id) {
        for (int i = 0; i < tempList.size(); i++) {
            String tempid = tempList.get(i).ChannelId;
            if (id.equals(tempid)) {
                return true;
            }
        }
        return false;
    }

    // when user interrupt while recording audio
    public void openInterruptActivity(Bundle bundle) {
        // Start the activity whose result we want to retrieve.
        // The result will come back with request code GET_CODE.

        Intent intent = new Intent(getActivity(), showRecordingInterruptDialogActivity.class);
        intent.putExtras(bundle);
        someActivityResultLauncher.launch(intent);
    }

    // callback from showRecordingInterruptDialog
    ActivityResultLauncher<Intent> someActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        // There are no request codes
                        Intent data = result.getData();
                        switch (data.getIntExtra("actionID", 0)) {
                            case Constant.MM_ActionID_onSelectStation:
                                onActivityResultCalled = true;
                                counter = 0;

                                // set activity in global object
                                globals.radioServiceActivity = getActivity();

                                // stop station
                                RMusicService.stopStation(getActivity());
//                                    RMusicService.stopRecording(globals);

                                break;
                        }
                    }
                }
            });


    // check recording is on or off
    public boolean checkIsRecording(int actionCode, int position) {
        Debugger.debugI(TAG, "recording boolean - " + PlaylistManager.isRecording());

        // if recording is ON then call InterruptDialog
        if (PlaylistManager.isRecording() /*&& PlaylistManager.isIntentFromActivity((adapter.getCurrentVisibleList().get(position).getChannelMap()))*/) {

            Bundle bundle = new Bundle();
            bundle.putInt("actionID", actionCode);
            openInterruptActivity(bundle);
            return true;
        } else {
            return false;
        }
    }

    public void invalidOptionsMenuHelper() {
        if (mOptionsMenu != null && mMenuInflater != null) {
            mOptionsMenu.clear();
            onCreateOptionsMenu(mOptionsMenu, mMenuInflater);
        }
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        mOptionsMenu = menu;
        mMenuInflater = inflater;
//        inflater.inflate(R.menu.now_playing_menu, menu);
//
//        if (!RecordedManager.isPlaying() && Constant.mStationArrayList != null && Constant.mStationArrayList.size() > 0) {
//            menu.findItem(R.id.now_playing).setVisible(true);
//        } else {
//            menu.findItem(R.id.now_playing).setVisible(false);
//        }

        super.onCreateOptionsMenu(menu, inflater);
    }

    // not calling
    @Override
    public void onItemClick(AdapterView<?> arg0, View arg1, int position, long arg3) {
        selectedPlayListCategory = 0;
        ChannelItem station = adapter.getItem(position);

        ArrayList<Channel> tempChannels = globals.convertChannelMapList(adapter.getCurrentVisibleList());
        int indexMap = globals.getCurrentIndexOfChannel(station.getChannelMap(), tempChannels);
        channelInPlayList = tempChannels;
        if (!checkIsRecording(Constant.MM_ActionID_onSelectStation, indexMap)) {
            playStation(indexMap, tempChannels);
        } else {
            tempPosition = indexMap;
        }

    }

    String sType;
    // here we pass the channelList and index to play
    void playStation(int index, ArrayList<Channel> tempChannels) {
        mTempChannels = tempChannels;
        Constant.mStationArrayList = mTempChannels;
        mPosition = index;

        if (flag == 1){
            sType = "after_remove";
        }else {
            if (cname.equalsIgnoreCase("search")) {
                sType = "search";
            } else {
                sType = "channel";
            }
        }



        if (InterstitialAdManager.getInstance().showInterstitial(getActivity()) && InterstitialUtils.getInstance().interstitialAd != null) {
            InterstitialUtils.getInstance().displayInterstitialAd(getActivity(), new InterstitialDismissListener() {
                @Override
                public void onInterstitialDismissListener(Activity activity, int ButtonId) {
                    PlaylistManager.setStationType(sType);
                    PlaylistManager.setPlayerDetail(getActivity(), mPosition, mTempChannels);
                }
            }, 616269);
        } else {
            PlaylistManager.setStationType(sType);
            PlaylistManager.setPlayerDetail(getActivity(), mPosition, mTempChannels);
        }
    }

}
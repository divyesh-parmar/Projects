package io.agora.rtc.ss.app;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import static io.agora.rtc.ss.app.SavedActivity.translate_Array;

public class ExtraAdapter extends BaseAdapter {

    private Context mContext;
    private ArrayList<String> image;
    LayoutInflater inflater = null;
    int[] tab_col = {R.drawable.a1_unpress, R.drawable.a2_unpress, R.drawable.a3_unpress};

    public ExtraAdapter(Context context, ArrayList<String> myimage) {
        this.mContext = context;
        this.image = myimage;
        inflater = LayoutInflater.from(mContext);
    }

    public int getCount() {
        return image.size();
    }

    public Object getItem(int position) {
        return position;
    }

    public long getItemId(int position) {
        return position;
    }

    public View getView(final int position, View convertView, ViewGroup parent) {

        convertView = inflater.inflate(R.layout.extra_adapter, null);

        TextView t = (TextView) convertView.findViewById(R.id.text);
        ImageView delete_save = (ImageView) convertView.findViewById(R.id.delete_save);
        LinearLayout imglayi = (LinearLayout) convertView.findViewById(R.id.imglayi);

        Utl.SetUIRelative(mContext, imglayi, 1021, 173);
        Utl.SetUILinear(mContext, delete_save, 105, 125);

        imglayi.setBackgroundResource(tab_col[position % 3]);

        delete_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                translate_Array.remove(position);
                final ArrayList<String> rajjo = new ArrayList<>();
                rajjo.clear();
                for (int i = translate_Array.size() - 1; i >= 0; i--) {
                    rajjo.add(translate_Array.get(i));
                }

                Toast.makeText(mContext, "Delete Successfully.!", Toast.LENGTH_SHORT).show();
                android.os.Handler handler = new android.os.Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Constant.saveArrayList(mContext, rajjo, "key1");
                        notifyDataSetChanged();
                    }
                }, 500);
            }
        });

        t.setText(image.get(position));

        return convertView;
    }

    public void SetUIRelative(View mview, int WIDTH, int HEIGHT) {
        RelativeLayout.LayoutParams layoutParamsi = new RelativeLayout.LayoutParams(
                mContext.getResources().getDisplayMetrics().widthPixels * WIDTH / 1080,
                mContext.getResources().getDisplayMetrics().widthPixels * HEIGHT / 1080);

        mview.setLayoutParams(layoutParamsi);
    }

}



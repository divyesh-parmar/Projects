package com.app.genre;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.app.ads.NativeAdsLanguageUtils;
import com.app.ads.NativeAdsUtils;
import com.app.firebase.FirebaseRemoteConfigUtils;
import com.app.parser.Language;
import com.app.utility.Constant;
import com.app.utility.Debugger;
import com.app.utility.Globals;
import com.app.utility.Utils;
import com.indianradio.R;

import java.util.ArrayList;

public class LanguageListRAdapter extends RecyclerView.Adapter<LanguageListRAdapter.MyHolder> {


    private Activity activity;
    private ArrayList<Language> data;
    private static LayoutInflater inflater = null;
    OnItemClickListener itemClickListener;
    Globals globals;

    public LanguageListRAdapter(Activity a, OnItemClickListener itemClickListener) {
        activity = a;
        globals = ((Globals) activity.getApplicationContext());
        this.itemClickListener = itemClickListener;

    }

    public void updateResults(Activity activity, ArrayList<Language> d) {
        this.data = d;
        //Triggers the list update
        notifyDataSetChanged();
    }

    public int getCount() {
        return data.size();
    }


    public Object getItem(int position) {
        return data.get(position);
    }

    public long getItemId(int position) {
        return position;
    }

    public Language getselectedLanguage(int position) {
        return ((Language) getItem(position));
    }


    @NonNull
    @Override
    public LanguageListRAdapter.MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(activity).inflate(R.layout.language_item,parent,false);

        MyHolder myHolder = new MyHolder(view);
        return myHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull LanguageListRAdapter.MyHolder holder, int position) {



        if (position == 2 && FirebaseRemoteConfigUtils.getInstance().getNativeType() == Constant.NativeEnum.ADMOB.ordinal()) {
            if (Utils.getInt(activity, activity.getResources().getString(R.string.In_app_product_ads_id), 0) == 0) {
                Debugger.debugI("LanguageAdapter", "getView: " + position);
                holder.templateView.setVisibility(View.VISIBLE);
                holder.div1.setVisibility(View.VISIBLE);
                if (holder.templateView != null) {
                    NativeAdsLanguageUtils.getInstance().showNative(activity, holder.templateView);
                }
            }else {
                holder.templateView.setVisibility(View.GONE);
                holder.div1.setVisibility(View.GONE);
            }

        }else {
            holder.templateView.setVisibility(View.GONE);
            holder.div1.setVisibility(View.GONE);
        }

        Language info = getselectedLanguage(position);
        if (Integer.parseInt(info.LanguageIsNew) == 1)
            holder.isNew.setVisibility(View.VISIBLE);
        else
            holder.isNew.setVisibility(View.GONE);

        holder.name.setText(info.LanguageName);
        holder.count.setText(info.TotalChannels + " stations");

        holder.my_item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                itemClickListener.onItemClick(position);
            }
        });


    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder {

        public TextView name;
        public TextView count;
        public LinearLayout isNew;
        public LinearLayout my_item;
        public LinearLayout div1;
        LinearLayout templateView;

        public MyHolder(@NonNull View itemView) {
            super(itemView);

            name = (TextView) itemView.findViewById(R.id.txt_language_name);
            count = (TextView) itemView.findViewById(R.id.txt_channel_count);
            isNew = (LinearLayout) itemView.findViewById(R.id.isNew);
            my_item = (LinearLayout) itemView.findViewById(R.id.my_item);
            div1 = (LinearLayout) itemView.findViewById(R.id.div1);
            templateView = itemView.findViewById(R.id.templateView);

        }
    }
}

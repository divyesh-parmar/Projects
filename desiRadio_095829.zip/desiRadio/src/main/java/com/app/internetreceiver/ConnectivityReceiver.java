package com.app.internetreceiver;

import static com.app.utility.Utils.afterSplashFlag;
import static com.app.utility.Utils.internetFlag;
import static com.app.utility.Utils.isNetworkConnected;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.app.ads.InterstitialAdManager;
import com.app.firebase.FirebaseRemoteConfigUtils;
import com.app.firebase.RemoteConfigLoadListener;
import com.app.googleservices.purchase.InAppBillingManager;
import com.app.utility.Constant;
import com.app.utility.ContextSingleton;
import com.app.utility.Debugger;
import com.app.utility.Globals;
import com.app.utility.Utils;
import com.indianradio.R;


public class ConnectivityReceiver extends BroadcastReceiver implements RemoteConfigLoadListener {

    public String TAG = getClass().getSimpleName();

    @Override
    public void onReceive(Context context, Intent intent) {

        if (isNetworkConnected(context)) {
            Debugger.debugI(TAG," onReceive: connected");

            //internetFlag for one time call receiver default value 0
            if (internetFlag == 0) {
                Debugger.debugI(TAG,"onReceive: Internet Connection");

                //when user come after the splash load
                if (afterSplashFlag == 1) {

                   checkPurchase(context);
                }
            }

        } else {

            Debugger.debugI(TAG," onReceive: not connected");

        }

    }

    //check in app purchase
    private void checkPurchase(Context context) {

        InAppBillingManager inAppBillingManager = new InAppBillingManager(context, context.getResources().getString(R.string.In_app_license_key), null);
        inAppBillingManager.initInAppBilling(new InAppBillingManager.IInAppBillingInitializeListener() {
            @Override
            public void onInitializeSuccess() {
                Debugger.debugI(TAG,"------------onInitializeSuccess:------- ");
            }

            @Override
            public void onInitializePurchaseLoaded() {
                Debugger.debugI(TAG,"------------onPurchaseLoaded:------------- ");

                purchaseLoaded(context,inAppBillingManager);
//                            if (inAppBillingManager.checkPurchased(context.getResources().getString(R.string.In_app_product_id))) {
//                                Debugger.debugI.e(TAG, "Share purchase - true: ");
//                                Utils.saveInt(context, context.getResources().getString(R.string.In_app_product_id), 1);
//                            } else {
//                                Debugger.debugI.e(TAG, "Share purchase - false: ");
//                                Utils.saveInt(context, context.getResources().getString(R.string.In_app_product_id), 0);
//                            }
            }

            @Override
            public void onInitializeFailed(InAppBillingManager.InAppBillingError errorCode, String error) {
                Debugger.debugI(TAG,"------------onInitializeFail------- ");
                if (afterSplashFlag == 1) {

                    initRemoteConfig(context);
                }

            }
        });

    }

    private void initRemoteConfig(Context context) {
       // RemoteConfigLoadListener listener = (RemoteConfigLoadListener) context;
        //call remote config
        FirebaseRemoteConfigUtils.getInstance().init(context,this);
    }


    public void purchaseLoaded(Context context, InAppBillingManager inAppBillingManager){
        if (inAppBillingManager.checkPurchased(context.getResources().getString(R.string.In_app_product_ads_id))) {
            Debugger.debugI(TAG,"Ads purchase - true: ");
            Utils.saveInt(context, context.getResources().getString(R.string.In_app_product_ads_id), 1);
        } else {
            Debugger.debugI(TAG,"Ads purchase - false: ");
            Utils.saveInt(context, context.getResources().getString(R.string.In_app_product_ads_id), 0);
        }
        Globals globals = ((Globals)context);
        if (inAppBillingManager.checkPurchased(Constant.SKU_PremiumRecording)) {
            Debugger.debugI(TAG,"record purchase - true: ");
            Utils.saveInt(context, Constant.SKU_PremiumRecording, 1);

            globals.setMaxRecordingTime(30);
        } else {
            Debugger.debugI(TAG,"record purchase - false: ");
            Utils.saveInt(context, Constant.SKU_PremiumRecording, 0);
            globals.setMaxRecordingTime(1);
        }
        //here we set internetFlag 1 for not call receiver multiple time
        internetFlag = 1;

        //call remote config
        initRemoteConfig(context);
    }

    @Override
    public void onRemoteConfigSuccessListener() {
        InterstitialAdManager.getInstance().init(ContextSingleton.getInstance().getContext());
    }

    @Override
    public void onRemoteConfigFailListener() {

    }
}

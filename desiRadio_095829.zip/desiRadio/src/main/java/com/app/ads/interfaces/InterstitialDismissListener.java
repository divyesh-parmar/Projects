package com.app.ads.interfaces;

import android.app.Activity;

public interface InterstitialDismissListener {
    //callback interstitial dismiss
    void onInterstitialDismissListener(Activity activity, int ButtonId);
}

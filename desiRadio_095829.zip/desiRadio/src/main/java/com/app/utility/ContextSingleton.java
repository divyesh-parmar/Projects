package com.app.utility;

import android.content.Context;

public class ContextSingleton {

    Context context;

    private static ContextSingleton ourInstance;

    public static ContextSingleton getInstance() {
        if (ourInstance == null) {
            ourInstance = new ContextSingleton();
        }
        return ourInstance;
    }

    private ContextSingleton() {
    }

    public void setContext(Context context) {
        this.context=context;
    }

    public Context getContext(){
        return context;
    }
}
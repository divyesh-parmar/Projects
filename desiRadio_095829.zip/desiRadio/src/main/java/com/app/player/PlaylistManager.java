package com.app.player;

import static com.app.utility.Constant.mStationArrayList;
import static com.app.utility.Utils.channelInPlayList;
import static com.app.utility.Utils.channelInPlayListTemp;
import static com.app.utility.Utils.flgForPlayerOpen;
import static com.app.utility.Utils.selectedStation;

import java.util.ArrayList;

import android.content.Context;
import android.content.Intent;

import com.app.http.ConnectionDetector;
import com.app.parser.Channel;
import com.app.utility.Debugger;
import com.app.utility.Globals;
import com.app.utility.Utils;
import com.google.gson.Gson;

public class PlaylistManager {

    public static int currentIndex = -99;
    public static ArrayList<Channel> Channels = new ArrayList<Channel>();
    public static ArrayList<Channel> Channels2 = new ArrayList<Channel>();
    public static String playingURL;
    public static Channel channelModel;
    public static Boolean isPlayingFlag = false;
    public static Boolean isIntentFromActivty = false;
    public static boolean isRecording;
    public static boolean isError;
    public static String stationType;
    public static int checkClear = 0;
    public static String TAG = "PlaylistManager";

    public static void init() {
        currentIndex = -99;
        Channels = new ArrayList<Channel>();
        playingURL = null;
        isPlayingFlag = false;
        isIntentFromActivty = false;
        isRecording = false;
        isError = false;
        stationType = "channel";
    }

    public static boolean isError() {
        return isError;
    }

    public static void setError(boolean isError) {
        PlaylistManager.isError = isError;
    }

    public static String getStationType() {
        return stationType;
    }

    public static void setStationType(String stationType) {
        PlaylistManager.stationType = stationType;
    }

    public static boolean isRecording() {
        return isRecording;
    }

    public static void setRecording(boolean isRecording) {
        PlaylistManager.isRecording = isRecording;
    }

    public static Boolean isIntentFromActivty() {
        return isIntentFromActivty;
    }

    public static void setIsIntentFromActivty(Boolean isIntentFromActivty) {
        PlaylistManager.isIntentFromActivty = isIntentFromActivty;
    }

    public static Boolean isPlaying() {
        return isPlayingFlag;
    }

    public static void setIsPlayingFlag(Boolean isPlayingFlag) {
        PlaylistManager.isPlayingFlag = isPlayingFlag;
        Debugger.debugI(TAG, "isPlayingFlag : " + isPlayingFlag);
    }

    public static String getPlayingURL() {
        return playingURL;
    }

    public static void setPlayingURL(String playingURL) {
        PlaylistManager.playingURL = playingURL;
    }

    public static Channel getPlayingChannel() {
        return channelModel;
    }

    public static void setPlayingChannel(Channel chModel) {
        PlaylistManager.channelModel = chModel;
    }

    public static int getCurrentIndex() {
        return currentIndex;
    }

    public static void setCurrentIndex(int currentIndex) {
        PlaylistManager.currentIndex = currentIndex;
        Debugger.debugI(TAG, "currentIndex : " + currentIndex);
    }

    public static ArrayList<Channel> getStationList() {
        return Channels;
    }

    public static ArrayList<Channel> getStation2List() {
        return Channels2;
    }

    public static void setStation_list(ArrayList<Channel> list,int val) {
        checkClear = val;
        Debugger.debugI(TAG, "times of set station --> ");
        if (!Channels.isEmpty()) {
            Channels2.clear();
            Channels.clear();
        }
        Channels2.addAll(list);
        Channels.addAll(list);
    }

    public static void setPlayerDetail(Context context, int currentIndex, ArrayList<Channel> channels) {

        if (!ConnectionDetector.internetCheck(context))
            return;

        if (!isPlaying() || isIntentFromActivity(channels.get(currentIndex))) {
            setIsIntentFromActivty(true);
        } else {
            setIsIntentFromActivty(false);
        }

        setCurrentIndex(currentIndex);
        channelInPlayListTemp = channels;
        setStation_list(channels,1);

        if (!isIntentFromActivty()) {
            //to update history even if same station is playing.
            Channel currentChannel = PlaylistManager.getStationList().get(PlaylistManager.getCurrentIndex());
            Debugger.debugI(TAG, "setPlayerDetail :" + currentChannel.ChannelTitle);
            currentChannel.lastPlayedDate = System.currentTimeMillis();
            ((Globals) context.getApplicationContext()).AddStationToHistory(context, currentChannel);
        } else {
        }

        if (channels != null && channels.size() > 0) {
            Debugger.debugE(TAG, " last station list size - " + channels.size());
            Utils.saveArrayList(context, channels, "lastPlayedArray");
            Utils.saveString(context,"lastType",PlaylistManager.getStationType());
            Utils.saveInt(context,"position",currentIndex);
        }

        if (channels != null) {
            String lastStation = new Gson().toJson(channels.get(currentIndex));
            Debugger.debugE(TAG, " last station before save - " + lastStation);
            Utils.saveString(context, "lastStation", lastStation);
        }

        flgForPlayerOpen = false;
        playerIntent(context);
    }

    public static void playerIntent(Context context) {
        Intent i = new Intent(context, RadioPlayerActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(i);
        //	((Activity) context).overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    public static boolean checkIsAlreadyPlay(Channel currentChannel) {
        boolean playBool = false;

        if (PlaylistManager.getPlayingChannel() == currentChannel) {
            playBool = true;
        }
        return playBool;
    }

    public static boolean isIntentFromActivity(Channel currentChannel) {

        String current_URL = currentChannel.ChannelLink;
        String playing_URL = null;

        try {
            if (PlaylistManager.getStationList().size() > 0)
                playing_URL = (getStationList().get(getCurrentIndex())).ChannelLink;
        } catch (Exception e) {
            e.printStackTrace();
        }

//		if(!playing_URL.equals(null) && !playing_URL.equals(current_URL)) {
//			Debugger.debugI(TAG, "size :"+getStationList().size()+"playing_URL :"+playing_URL +"current_URL :"+current_URL);
//			return true;
//		} else {
        Debugger.debugI(TAG, "size :" + getStationList().size() + "playing_URL : NULL" + "current_URL :" + current_URL);
        return false;
//		}
    }

    public static boolean isStationPlaying(Channel currentChannel) {

        String current_URL = currentChannel.ChannelLink;
        String current_ID = currentChannel.ChannelId;

        String playing_URL = null;
        String playing_ID = null;

        try {
            if (mStationArrayList != null && mStationArrayList.size() > 0) {
                playing_URL = (mStationArrayList.get(getCurrentIndex())).ChannelLink;
                playing_ID = (mStationArrayList.get(getCurrentIndex())).ChannelId;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (playing_URL != null && playing_ID != null && playing_URL.equals(current_URL) && playing_ID.equals(current_ID)) {
            return true;
        } else {
            return false;
        }
    }
}

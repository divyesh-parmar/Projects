package com.app.genre;

public interface ChangeStationListener {
    void updateAllPlayerData();
}

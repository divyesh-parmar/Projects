package com.app.parser;

import java.util.Comparator;

public class LanguageSortOrder implements Comparator<Language>{

    @Override
    public int compare(Language sp1, Language sp2) {
        return (sp1.LanguageSortOrder < sp2.LanguageSortOrder ) ? -1: (sp1.LanguageSortOrder > sp2.LanguageSortOrder) ? 1:0 ;
    }
  
}

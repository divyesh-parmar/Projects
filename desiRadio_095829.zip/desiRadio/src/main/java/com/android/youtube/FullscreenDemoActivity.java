package com.android.youtube;

import static android.view.ViewGroup.LayoutParams.MATCH_PARENT;
import static android.view.ViewGroup.LayoutParams.WRAP_CONTENT;

import static com.app.utility.Constant.Youtube_Appkey;

import com.app.desiradio.SplashScreenActivity;
import com.app.player.RadioPlayerActivity;
import com.app.utility.Debugger;
import com.app.utility.Utils;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.indianradio.R;
import com.jakewharton.processphoenix.ProcessPhoenix;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.FullscreenListener;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.options.IFramePlayerOptions;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import kotlin.Unit;
import kotlin.jvm.functions.Function0;

/**
 * Sample activity showing how to properly enable custom fullscreen behavior.
 * <p>
 * This is the preferred way of handling fullscreen because the default fullscreen implementation
 * will cause re-buffering of the video.
 */
public class FullscreenDemoActivity extends AppCompatActivity {

    private static final int PORTRAIT_ORIENTATION = Build.VERSION.SDK_INT < 9
            ? ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            : ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT;

    ImageView iv_back;
    TextView tvTitle;
    private boolean isFullscreen = false;
    private boolean fullscreen;
    String yt_Id;
    String yt_title;
    Button btn_fullscreen;
    YouTubePlayerView youTubePlayerView;
//    protected Configuration mPrevConfig;

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
//        configurationChanged(newConfig);
//        mPrevConfig = new Configuration(newConfig);
    }

    protected void configurationChanged(Configuration newConfig) {
        if (Utils.getInt(this, "mode", 0) == 2)
            ProcessPhoenix.triggerRebirth(FullscreenDemoActivity.this, new Intent(this, SplashScreenActivity.class));
//        if (isNightConfigChanged(newConfig)) { // night mode has changed
//            recreate();
//            // do your thing
//            Log.e(TAG, "configurationChanged: "+newConfig.uiMode );
//        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.fullscreen_demo);

//        mPrevConfig = new Configuration(getResources().getConfiguration());
        Intent DATA = getIntent();
        yt_Id = DATA.getStringExtra("ID");
        yt_title = DATA.getStringExtra("title");


        youTubePlayerView = findViewById(R.id.youtube_player_view);
        iv_back = findViewById(R.id.iv_back);
        tvTitle = findViewById(R.id.tv_title);

        tvTitle.setText(yt_title);

        FrameLayout fullscreenViewContainer = findViewById  (R.id.full_screen_view_container);

        IFramePlayerOptions iFramePlayerOptions = new IFramePlayerOptions.Builder()
                .controls(1)
                .fullscreen(1) // enable full screen button
                .build();

        // we need to initialize manually in order to pass IFramePlayerOptions to the player
        youTubePlayerView.setEnableAutomaticInitialization(false);

        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        youTubePlayerView.addFullscreenListener(new FullscreenListener() {
            @Override
            public void onEnterFullscreen(@NonNull View view, @NonNull Function0<Unit> function0) {
                isFullscreen = true;

                // the video will continue playing in fullscreenView
                youTubePlayerView.setVisibility(View.GONE);
                fullscreenViewContainer.setVisibility(View.VISIBLE);
                fullscreenViewContainer.addView(view);
            }

            @Override
            public void onExitFullscreen() {
                isFullscreen = false;

                youTubePlayerView.setVisibility(View.VISIBLE);
                fullscreenViewContainer.setVisibility(View.GONE);
                fullscreenViewContainer.removeAllViews();
            }
        });

        youTubePlayerView.initialize(new AbstractYouTubePlayerListener() {
            @Override
            public void onReady(@NonNull com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer youTubePlayer) {
                super.onReady(youTubePlayer);
                youTubePlayer.cueVideo(yt_Id, 0f);
                youTubePlayer.toggleFullscreen();
//                btn_fullscreen.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
//                        youTubePlayer.toggleFullscreen();
//                    }
//                });

            }
        },iFramePlayerOptions);



        getLifecycle().addObserver(youTubePlayerView);


    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        youTubePlayerView.release();
    }
}

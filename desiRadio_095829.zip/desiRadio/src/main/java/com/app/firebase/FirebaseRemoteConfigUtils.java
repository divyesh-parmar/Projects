package com.app.firebase;


import android.content.Context;

import androidx.annotation.NonNull;


import com.app.utility.Constant;
import com.app.utility.Debugger;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings;


import com.indianradio.BuildConfig;
import com.indianradio.R;




public class FirebaseRemoteConfigUtils {

    private FirebaseRemoteConfig mFirebaseRemoteConfig;
    private String TAG = getClass().getSimpleName();
    Context context;
    //todo set 12 hr time for release mode
    int defaultIntervalTime = 43200; //12 hour for fetch default remote config
//        int defaultIntervalTime = 0; //live update for fetch default remote config
    int intervalTime;
    int bannerType;
    int adOpenType;
    int nativeType;
    int interstitialType;
    String admobBanner;
    String admobInterstitial;
    String admobAppOpenAd;
    String admobNativeAd;

    private static FirebaseRemoteConfigUtils ourInstance;
    private RemoteConfigLoadListener listener;

    public static FirebaseRemoteConfigUtils getInstance() {
        if (ourInstance == null) {
            ourInstance = new FirebaseRemoteConfigUtils();
            Debugger.debugI("FirebaseRemote", "---------new instance-------------");
        }
        Debugger.debugI("FirebaseRemote", "---------old instance-------------");
        return ourInstance;
    }

    private FirebaseRemoteConfigUtils() {

    }


    public void init(Context context, RemoteConfigLoadListener listener) {

        mFirebaseRemoteConfig = FirebaseRemoteConfig.getInstance();
        Debugger.debugI("FirebaseRemote", "---------get instance of firebase-------------");
        if (BuildConfig.DEBUG) {
            defaultIntervalTime = 0;
        }

        FirebaseRemoteConfigSettings configSettings = new FirebaseRemoteConfigSettings.Builder()
                .setMinimumFetchIntervalInSeconds(defaultIntervalTime)    //3600 default
                .build();

        mFirebaseRemoteConfig.setDefaultsAsync(R.xml.remote_config_defaults);
        mFirebaseRemoteConfig.setConfigSettingsAsync(configSettings);

        fetchRemoteConfig(context, listener);
    }

    public void fetchRemoteConfig(Context context, RemoteConfigLoadListener remoteConfigLoadListener) {
        Debugger.debugI("FirebaseRemote", "---------fetch remote config call-------------");
        mFirebaseRemoteConfig.fetchAndActivate()
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Debugger.debugI(TAG, "----------------Remote config onFailure-----------");
                        e.printStackTrace();

                        if (remoteConfigLoadListener != null) {
                            FirebaseRemoteConfigUtils.this.listener = remoteConfigLoadListener;
                            FirebaseRemoteConfigUtils.this.listener.onRemoteConfigFailListener();
                        }

                    }
                })
                .addOnCompleteListener(new OnCompleteListener<Boolean>() {
                    @Override
                    public void onComplete(@NonNull Task<Boolean> task) {
                        if (task.isSuccessful()) {
                            boolean updated = task.getResult();
                            Debugger.debugI(TAG, "-----------Fetch success------- ");
                            setValues();

                            if (remoteConfigLoadListener != null) {
                                FirebaseRemoteConfigUtils.this.listener = remoteConfigLoadListener;
                                FirebaseRemoteConfigUtils.this.listener.onRemoteConfigSuccessListener();
                            }


                        } else {
                            Debugger.debugI(TAG, "----------Fetch failed-------------- ");
                            if (remoteConfigLoadListener != null) {
                                FirebaseRemoteConfigUtils.this.listener = remoteConfigLoadListener;
                                FirebaseRemoteConfigUtils.this.listener.onRemoteConfigFailListener();
                            }

                        }

                    }
                });

    }

    public void setValues() {
        setAdOpenType((int) mFirebaseRemoteConfig.getLong(Constant.MM_ANDROID_ADOPEN_TYPE));
        setInterstitialInterval((int) mFirebaseRemoteConfig.getLong(Constant.MM_ANDROID_INTERSTITIAL_INTERVAL));

        setInterstitialType((int) mFirebaseRemoteConfig.getLong(Constant.MM_ANDROID_INTERSTITIAL_TYPE));
        setBannerType((int) mFirebaseRemoteConfig.getLong(Constant.MM_ANDROID_BANNER_TYPE));
        setNativeType((int) mFirebaseRemoteConfig.getLong(Constant.MM_ANDROID_NATIVE_TYPE));

        setAdmobBannerID(mFirebaseRemoteConfig.getString(Constant.MM_ANDROID_ADMOB_BANNER_PLACEMENT));
        setAdmobInterstitialID(mFirebaseRemoteConfig.getString(Constant.MM_ANDROID_ADMOB_INTERSTITIAL_PLACEMENT));
        setAdmobAppOpenAdID(mFirebaseRemoteConfig.getString(Constant.MM_ANDROID_ADMOB_APPOPEN_PLACEMENT));
        setAdmobNativeAdID(mFirebaseRemoteConfig.getString(Constant.MM_ANDROID_ADMOB_NATIVE_ADVANCE_PLACEMENT));

        //  todo comment below lines for release mode
        //  for debug mode
//        setAdmobBannerID("ca-app-pub-3940256099942544/6300978111");
//        setAdmobInterstitialID("ca-app-pub-3940256099942544/1033173712");
//        setAdmobAppOpenAdID("ca-app-pub-3940256099942544/3419835294");
//        setAdmobNativeAdID("ca-app-pub-3940256099942544/2247696110");
//        setInterstitialInterval((int) 500000);


        Debugger.debugI(TAG, "Remote Config interval --> " + getInterstitialInterval());
        Debugger.debugI(TAG, "Remote Config banner type --> " + getBannerType());
        Debugger.debugI(TAG, "Remote Config interstitial type --> " + getInterstitialType());
        Debugger.debugI(TAG, "Remote Config adOpen type --> " + getAdOpenType());
        Debugger.debugI(TAG, "Remote Config admob banner  --> " + getAdmobBannerID());
        Debugger.debugI(TAG, "Remote Config admob interstitial  --> " + getAdmobInterstitialID());
        Debugger.debugI(TAG, "Remote Config admob adOpen  --> " + getAdmobAppOpenAdID());
        Debugger.debugI(TAG, "Remote Config admob native advance  --> " + getAdmobNativeAdID());
        Debugger.debugI(TAG, "Remote Config native type --> " + getNativeType());
    }

    public void setInterstitialInterval(int intervalTime) {
        this.intervalTime = intervalTime;
    }

    public int getInterstitialInterval() {
        return intervalTime;
    }

    public void setBannerType(int bannerType) {
        this.bannerType = bannerType;
    }

    public int getBannerType() {
        return bannerType;
    }

    public void setNativeType(int nativeType) {
        this.nativeType = nativeType;
    }

    public int getNativeType() {
        return nativeType;
    }

    public void setInterstitialType(int interstitialType) {
        this.interstitialType = interstitialType;
    }

    public int getInterstitialType() {
        return interstitialType;
    }

    public void setAdOpenType(int adOpenType) {
        this.adOpenType = adOpenType;
    }

    public int getAdOpenType() {
        return adOpenType;
    }

    public String getAdmobBannerID() {
        return admobBanner;
    }

    public void setAdmobBannerID(String admobBanner) {
        this.admobBanner = admobBanner;
    }

    public String getAdmobInterstitialID() {
        return admobInterstitial;
    }

    public void setAdmobInterstitialID(String admobInterstitial) {
        this.admobInterstitial = admobInterstitial;
    }

    public String getAdmobAppOpenAdID() {
        return admobAppOpenAd;
    }

    public void setAdmobAppOpenAdID(String admobAppOpenAd) {
        this.admobAppOpenAd = admobAppOpenAd;
    }

    public String getAdmobNativeAdID() {
        return admobNativeAd;
    }

    public void setAdmobNativeAdID(String admobNativeAd) {
        this.admobNativeAd = admobNativeAd;
    }

}

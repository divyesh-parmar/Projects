package com.app.auto;

import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;

/**
 * Listener to provide state updates from { MediaPlayerAdapter & ExoPlayerAdapter} (the media player)
 * to {@link RMusicService} (the service that holds our {@link MediaSessionCompat}.
 */
public interface PlayBackChangeListener {

    void onPlaybackStateChange(PlaybackStateCompat state);
}

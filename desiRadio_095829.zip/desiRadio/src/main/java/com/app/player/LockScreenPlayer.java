package com.app.player;

import static com.app.auto.RMusicService.checkExoIsPlaying;
import static com.app.auto.RMusicService.getAlbumUris;
import static com.app.auto.RMusicService.mPlayback;
import static com.app.player.RadioPlayerActivity.fetchStationURL;
import static com.app.player.RadioPlayerActivity.mIsPlaying;
import static com.app.player.RadioPlayerActivity.mMediaBrowserHelper;
import static com.app.player.RadioPlayerActivity.updateItemAtPosition;
import static com.app.utility.Constant.MM_Song_Info_Not_Found;
import static com.app.utility.Constant.mStationArrayList;
import static com.app.utility.Utils.selectedStation;
import static com.app.utility.Utils.setSongLabel;
import static com.app.utility.Utils.setStationLabel;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.PowerManager;
import android.support.v4.media.MediaBrowserCompat;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaControllerCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.android.FirebaseAnalytics.AnalyticsConstants;
import com.android.Utility.Classes.UnCaughtException;
import com.app.auto.MediaBrowserHelper;
import com.app.auto.RMusicService;
import com.app.desiradio.MainActivity;
import com.app.http.ConnectionDetector;
import com.app.parser.Channel;
import com.app.utility.Constant;
import com.app.utility.Debugger;
import com.app.utility.Globals;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.indianradio.R;

import java.util.ArrayList;
import java.util.List;

public class LockScreenPlayer extends Activity implements OnClickListener {

    public static Globals globals;
    public static String TAG;
    public static Context act;
    PowerManager pm;
    public static PowerManager.WakeLock wl;
    boolean screenOn;
    public static ImageView btn_play;
    public static ImageButton btn_next, btn_previous;
    public static TextView stationNameLabel;
    public static TextView songNameLabel;
    public static Boolean isVisible = false;
    LinearLayout unlock_layout;
    public static ImageView blurBack, albumArtView;
    int requestCode = 1;
    static Context ctx;
    public static Boolean isTablet = false;

    @SuppressLint("InvalidWakeLockTag")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Thread.setDefaultUncaughtExceptionHandler(new UnCaughtException(LockScreenPlayer.this));
        setContentView(R.layout.lockscreen_player);
        TAG = getClass().getName();
        globals = ((Globals) this.getApplicationContext());
        act = LockScreenPlayer.this;

        ctx = getApplicationContext();

        if (mMediaBrowserHelper == null) {
            mMediaBrowserHelper = new MediaBrowserConnection(this);

            //MediaControllerCompatListener register
            mMediaBrowserHelper.registerCallback(new MediaBrowserListener());
        }

        isTablet = getResources().getBoolean(R.bool.isTablet);
        Debugger.debugI(TAG, "isTablet :" + isTablet);

        pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        screenOn = pm.isInteractive();// check id screen is on
        // if not turn it on or wakeup the screen
        if (!screenOn) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            try {
                wl.acquire();
            } catch (Exception ee) {

            }
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_ALLOW_LOCK_WHILE_SCREEN_ON);

        init();
    }

    /**
     * Customize the connection to our {@link .MediaBrowserServiceCompat}
     * and implement our app specific desires.
     */
    private class MediaBrowserConnection extends MediaBrowserHelper {
        private MediaBrowserConnection(Context context) {
            super(context, RMusicService.class);
            Debugger.debugI(TAG, "MediaBrowserConnection: ");
        }

        @Override
        protected void onConnected(@NonNull MediaControllerCompat mediaController) {
            Debugger.debugI(TAG, "onConnected: ");

            Channel currentChannel;
            if (PlaylistManager.getCurrentIndex() >= 0) {
                currentChannel = mStationArrayList.get(PlaylistManager.getCurrentIndex());

                if (currentChannel != null) {
                    Debugger.debugI(TAG, "media connected url ---" + currentChannel.ChannelLink);
                    selectedStation = currentChannel;

                    Debugger.debugI(TAG, "ui selected station  --  " + selectedStation);

                    Bundle  bundle = new Bundle();
                    bundle.putString(Constant.CHANNEL_DATA, new Gson().toJson(currentChannel));
                    bundle.putString(Constant.CHANNEL_TYPE, PlaylistManager.getStationType());
//                    bundle.putString(currentChannel.ChannelId, currentChannel.toJsonData());
                    mediaController.getTransportControls().playFromMediaId(currentChannel.ChannelId, bundle);


                }
            }
        }

        @Override
        protected void onDisconnected() {
            Debugger.debugI(TAG, "onDisConnected");
            super.onDisconnected();
        }

        @Override
        protected void onChildrenLoaded(@NonNull String parentId,
                                        @NonNull List<MediaBrowserCompat.MediaItem> children) {
            super.onChildrenLoaded(parentId, children);
            Debugger.debugI(TAG, "onChildrenLoaded: ");
            final MediaControllerCompat mediaController = getMediaController();

            // Queue up all media items for this simple sample.
            for (final MediaBrowserCompat.MediaItem mediaItem : children) {
                mediaController.addQueueItem(mediaItem.getDescription());
            }

            // Call prepare now so pressing play just works.
            mediaController.getTransportControls().prepare();
        }
    }

    /**
     * Implementation of the {@link MediaControllerCompat.Callback} methods we're interested in.
     * <p>
     * Here would also be where one could override
     * {@code onQueueChanged(List<MediaSessionCompat.QueueItem> queue)} to get informed when items
     * are added or removed from the queue. We don't do this here in order to keep the UI
     * simple.
     */
    private class MediaBrowserListener extends MediaControllerCompat.Callback {
        @Override
        public void onPlaybackStateChanged(PlaybackStateCompat playbackState) {

            RadioPlayerActivity.mIsPlaying = playbackState != null &&
                    playbackState.getState() == PlaybackStateCompat.STATE_PLAYING;
            if (mPlayback.isPlaying()) {

                btn_play.setBackgroundResource(R.drawable.player_layout_stop_icon);

                if (LockScreenPlayer.btn_play != null) {
                    LockScreenPlayer.btn_play.setBackgroundResource(R.drawable.player_layout_stop_icon);
                }
                if (MainActivity.ivPlayBottom !=  null){
                    MainActivity.ivPlayBottom.setImageResource(R.drawable.player_layout_stop_icon);
                }
            } else {
                setSongLabel(MM_Song_Info_Not_Found);
                btn_play.setBackgroundResource(R.drawable.player_layout_play_icon);
                if (LockScreenPlayer.btn_play != null) {
                    LockScreenPlayer.btn_play.setBackgroundResource(R.drawable.player_layout_play_icon);
                }
                if (MainActivity.ivPlayBottom !=  null){
                    MainActivity.ivPlayBottom.setImageResource(R.drawable.player_layout_play_icon);
                }
            }

            // mMediaControlsImage.setPressed(mIsPlaying);
        }

        @Override
        public void onMetadataChanged(MediaMetadataCompat mediaMetadata) {

            if (mediaMetadata == null) {
                return;
            }

        }

        @Override
        public void onSessionDestroyed() {
            super.onSessionDestroyed();
        }

        @Override
        public void onQueueChanged(List<MediaSessionCompat.QueueItem> queue) {
            super.onQueueChanged(queue);
        }
    }

    public void init() {
        stationNameLabel = findViewById(R.id.stationName);
        setStationLabel(PlaylistManager.getStationList().get(PlaylistManager.getCurrentIndex()).ChannelTitle);
        stationNameLabel.setSelected(true);

        songNameLabel = findViewById(R.id.songName);
        setSongLabel(RMusicService.currentPlayingName);
        songNameLabel.setSelected(true);

        btn_play = findViewById(R.id.play_btn);
        btn_previous = findViewById(R.id.previous_btn);
        btn_next = findViewById(R.id.next_btn);

        blurBack = findViewById(R.id.img_art);
        albumArtView = findViewById(R.id.lock_scrren_album_art);

        btn_previous.setOnClickListener(this);
        btn_next.setOnClickListener(this);
        btn_play.setOnClickListener(this);

        unlock_layout = findViewById(R.id.unlock_layout);
        unlock_layout.setOnClickListener(this);

        Bundle bundle = new Bundle();
        bundle.putString(AnalyticsConstants.SCREEN_NAME, AnalyticsConstants.SN_lockplayer);

        if (getAlbumUris() != null) {
            Glide.with(LockScreenPlayer.this).load(getAlbumUris()).placeholder(R.drawable.player_img_view).into(albumArtView);
        }else {
            Glide.with(LockScreenPlayer.this).load(R.drawable.player_img_view).into(albumArtView);
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // You can use the requestCode to select between multiple child
        // activities you may have started. Here there is only one thing we launch.
        if (requestCode == this.requestCode) {
            if (resultCode == Activity.RESULT_OK) {

                switch (data.getIntExtra("actionID", 0)) {
                    case Constant.MM_ActionID_StopPlaying:
                        if (ConnectionDetector.internetCheck(LockScreenPlayer.this)) {
                            RMusicService.stopStation(LockScreenPlayer.this);
                        }
                        //RMusicService.play_stop_Event(((Globals) getApplicationContext()), LockScreenPlayer.this);
                        break;
                    case Constant.MM_ActionID_PlayPrev:
                        globals.radioServiceActivity = LockScreenPlayer.this;
                        RMusicService.stopStation(LockScreenPlayer.this);

                        PlayPrevious(LockScreenPlayer.this, getApplicationContext());
                        break;
                    case Constant.MM_ActionID_PlayNext:
                        globals.radioServiceActivity = LockScreenPlayer.this;
                        RMusicService.stopStation(LockScreenPlayer.this);
                        PlayNext(LockScreenPlayer.this, getApplicationContext());
                        break;

                    default:
                        break;
                }
            }
        }
    }

    public void openInterruptActivity(Bundle bundle) {
        // Start the activity whose result we want to retrieve.
        // The result will come back with request code GET_CODE.
        Intent intent = new Intent(LockScreenPlayer.this, showRecordingInterruptDialogActivity.class);
        intent.putExtras(bundle);
        startActivityForResult(intent, requestCode);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.unlock_layout:
                if (!screenOn)
                    try {
                        wl.release();
                    } catch (Exception ee) {

                    }
                if (PlaylistManager.isPlaying())
                    moveTaskToBack(true);
                finish();
                break;

            case R.id.play_btn:

                Debugger.debugD(TAG, "click of lock screen play button");

                if (!checkIsRecording(Constant.MM_ActionID_StopPlaying)) {
                    Debugger.debugD(TAG, "click of lock screen play button - if not recording");
                    if (ConnectionDetector.internetCheck(LockScreenPlayer.this))
                        if (globals.isPlayedFromSp()) {

                            if (!mIsPlaying) {
                                Debugger.debugD(TAG, "lock screen play - sharedpref - if");
                                fetchStationURL(LockScreenPlayer.this, getApplicationContext());
                                mMediaBrowserHelper.getTransportControls().play();
                                mIsPlaying = true;
                            } else {
                                Debugger.debugD(TAG, "lock screen stop - sharedpref - else");
                                RMusicService.play_stop_Event(globals, LockScreenPlayer.this);
                                mMediaBrowserHelper.getTransportControls().stop();
                                mIsPlaying = false;
                            }

                        } else {
                            if (!mIsPlaying) {
                                Debugger.debugD(TAG, "lock screen play - not sharedpref - if");
                                fetchStationURL(LockScreenPlayer.this, getApplicationContext());
                                mMediaBrowserHelper.getTransportControls().play();

                            } else {
                                Debugger.debugD(TAG, "lock screen play - not sharedpref - else");
                                RMusicService.play_stop_Event(globals, LockScreenPlayer.this);
                                mMediaBrowserHelper.getTransportControls().stop();

                            }
                        }
                }
                updateItemAtPosition();

                break;

            case R.id.previous_btn:

                Debugger.debugD(TAG, "lock screen previous");
                Glide.with(LockScreenPlayer.this).load(R.drawable.player_img_view).into(albumArtView);
                setSongLabel(MM_Song_Info_Not_Found);

                if (!checkIsRecording(Constant.MM_ActionID_PlayPrev))
                    if (ConnectionDetector.internetCheck(LockScreenPlayer.this)) {

                        /** android auto start **/
                        mMediaBrowserHelper.getTransportControls().skipToPrevious();
                        /** android auto end **/
                        updateItemAtPosition();
                    }

                break;

            case R.id.next_btn:
                Debugger.debugD(TAG, "lock screen next");

                Glide.with(LockScreenPlayer.this).load(R.drawable.player_img_view).into(albumArtView);
                setSongLabel(MM_Song_Info_Not_Found);

                if (!checkIsRecording(Constant.MM_ActionID_PlayNext))
                    if (ConnectionDetector.internetCheck(LockScreenPlayer.this)) {

                        /** android auto start **/
                        mMediaBrowserHelper.getTransportControls().skipToNext();
                        /** android auto end **/
                        updateItemAtPosition();
                    }

                break;

            default:
                break;
        }
    }

    public boolean checkIsRecording(int actionCode) {

        if (PlaylistManager.isRecording()) {
            Bundle bundle = new Bundle();
            bundle.putInt("actionID", actionCode);
            openInterruptActivity(bundle);
            return true;
        } else {
            return false;
        }
    }

    public static void PlayNext(Context ActivityContext, Context ApplicationContext) {
        ArrayList<Channel> allStationArray = PlaylistManager.getStationList();
        int index = PlaylistManager.getCurrentIndex();
        if (index < allStationArray.size() - 1) {
            PlaylistManager.setCurrentIndex(index + 1);
        } else {
            PlaylistManager.setCurrentIndex(0);
        }

        if (allStationArray != null && !allStationArray.isEmpty() && allStationArray.size() > 0)
            setStationLabel(PlaylistManager.getStationList().get(index).ChannelTitle);
        fetchStationURL(ActivityContext, ApplicationContext);

        RMusicService.currentPlayingName = ctx.getString(R.string.song_info_not_found);
        setSongLabel(RMusicService.currentPlayingName);

        globals.setLastPlayedIndex(index);

    }

    public static void PlayPrevious(Context ActivityContext, Context ApplicationContext) {

        ArrayList<Channel> allStationArray = PlaylistManager.getStationList();
        int index = PlaylistManager.getCurrentIndex();

        if (index > 0) {
            PlaylistManager.setCurrentIndex(index - 1);
        } else {
            PlaylistManager.setCurrentIndex(allStationArray.size() - 1);
        }

        if (allStationArray != null && !allStationArray.isEmpty() && allStationArray.size() > 0)
            setStationLabel(allStationArray.get(index).ChannelTitle);

        fetchStationURL(ActivityContext, ApplicationContext);

        RMusicService.currentPlayingName = ctx.getString(R.string.song_info_not_found);
        setSongLabel(RMusicService.currentPlayingName);

        globals.setLastPlayedIndex(index);

    }

    @Override
    public void onBackPressed() {
        // TODO Auto-generated method stub
    }

    @Override
    protected void onPause() {
        super.onPause();
        isVisible = false;
    }

    @Override
    protected void onResume() {
        super.onResume();
        isVisible = true;
        globals.radioServiceActivity = LockScreenPlayer.this;
        if (checkExoIsPlaying()) {
            btn_play.setBackgroundResource(R.drawable.player_layout_stop_icon);
            if (MainActivity.ivPlayBottom !=  null){
                MainActivity.ivPlayBottom.setImageResource(R.drawable.player_layout_stop_icon);
            }
        } else {
            btn_play.setBackgroundResource(R.drawable.player_layout_play_icon);
            if (MainActivity.ivPlayBottom !=  null){
                MainActivity.ivPlayBottom.setImageResource(R.drawable.player_layout_play_icon);
            }
        }

        if (RMusicService.getAlbumUris() != null) {
            Glide.with(LockScreenPlayer.this).load(RMusicService.getAlbumUris()).placeholder(R.drawable.player_img_view).into(albumArtView);
        }

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Debugger.debugE(TAG, "onDestroy");
        if (!PlaylistManager.isPlaying()) {
            //stopService(new Intent(LockScreenPlayer.this, RadioService.class));
        }
    }
}
package com.app.firebase;

public interface RemoteConfigLoadListener {

    void onRemoteConfigSuccessListener();

    void onRemoteConfigFailListener();
}

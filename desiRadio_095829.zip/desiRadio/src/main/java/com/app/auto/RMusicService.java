package com.app.auto;

import static android.content.Intent.FLAG_ACTIVITY_NEW_TASK;
import static com.app.favorites.FavoritesFragment.LoadFavoriteList;
import static com.app.favorites.FavoritesFragment.adapter;
import static com.app.favorites.FavoritesFragment.fList;
import static com.app.favorites.FavoritesFragment.ownStationList;
import static com.app.favorites.FavoritesFragment.savedFevoList;
import static com.app.favorites.FavoritesFragment.switcher;
import static com.app.player.RadioPlayerActivity.UpdateFavBtnView;
import static com.app.player.RadioPlayerActivity.btn_addToFavorite;
import static com.app.player.RadioPlayerActivity.favoriteIndex;
import static com.app.player.RadioPlayerActivity.isTablet;
import static com.app.player.RadioPlayerActivity.loaderLay;
import static com.app.player.RadioPlayerActivity.updateItemAtPosition;
import static com.app.utility.Constant.MM_Song_Info_Not_Found;
import static com.app.utility.Constant.mStationArrayList;
import static com.app.utility.Utils.SELECTED_MAIN_CATEGORY;
import static com.app.utility.Utils.albumTitle;

import static com.app.utility.Utils.channelInPlayList;
import static com.app.utility.Utils.channelInPlayListTemp;
import static com.app.utility.Utils.checkPlayerIsPlay;
import static com.app.utility.Utils.currentAlbumUrl;
import static com.app.utility.Utils.getMediaPosition;
import static com.app.utility.Utils.isPLAY;
import static com.app.utility.Utils.lastPlayedStation;
import static com.app.utility.Utils.nextStationModel;
import static com.app.utility.Utils.previousStationModel;
import static com.app.utility.Utils.saveArrayList;
import static com.app.utility.Utils.saveString;
import static com.app.utility.Utils.selectedPlayListCategory;
import static com.app.utility.Utils.selectedStation;
import static com.app.utility.Utils.setSongLabel;
import static com.app.utility.Utils.setStationLabel;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.v4.media.MediaBrowserCompat;
import android.support.v4.media.MediaDescriptionCompat;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaControllerCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyCallback;
import android.telephony.TelephonyManager;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.annotation.RequiresPermission;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.media.MediaBrowserServiceCompat;

import com.android.FirebaseAnalytics.AnalyticsConstants;
import com.app.auto.apicall.DataProvider;
import com.app.auto.apicall.OnApiCallListener;

import com.app.desiradio.MainActivity;
import com.app.genre.ChannelItem;
import com.app.genre.ChannelListFragment;
import com.app.genre.ChannelManager;
import com.app.http.ConnectionDetector;
import com.app.parser.Channel;
import com.app.parser.Language;
import com.app.parser.Parser;
import com.app.player.LockScreenPlayer;
import com.app.player.PlaylistManager;
import com.app.player.RadioPlayerActivity;
import com.app.player.Stopwatch;
import com.app.player.showRecordingCompleteDialogActivity;
import com.app.recorded.RecordedManager;
import com.app.recorded.RecordedPlayerService;
import com.app.sqlite.DBHelper;
import com.app.sqlite.Recording;
import com.app.utility.Constant;

import com.app.utility.Debugger;
import com.app.utility.Globals;
import com.app.utility.Utils;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.android.exoplayer2.MediaMetadata;
import com.google.gson.Gson;
import com.indianradio.BuildConfig;
import com.indianradio.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;

public class RMusicService extends MediaBrowserServiceCompat {

    private static final String TAG = RMusicService.class.getSimpleName();
    private MediaSessionCompat mSession;
    public static PlayerAdapter mPlayback;
    private MediaNotificationManager mMediaNotificationManager;
    private boolean mServiceInStartedState;
    Context mContext;
    List<MediaBrowserCompat.MediaItem> cateMediaItemList = new ArrayList<>();
    public static List<MediaBrowserCompat.MediaItem> stationMediaItemList = new ArrayList<>();
    public static List<MediaBrowserCompat.MediaItem> favMediaItemList = new ArrayList<>();
    public static List<MediaBrowserCompat.MediaItem> historyMediaItemList = new ArrayList<>();
    String ROOT = "root";
    MediaBrowserHelper mMediaBrowserHelper;
    ArrayList<Channel> tempFavArray;
    ArrayList<Channel> tempHistoryArray;
    public static ArrayList<Channel> tempBrowseArray = new ArrayList<>();
    public static ArrayList<Channel> queueUpdateArray = new ArrayList<>();

    /**
     * local code start
     */
    private boolean callStateListenerRegistered = false;
    boolean mWasPlayingWhenCalled = false;
    private static Stopwatch m_stopwatch;
    static Animation animation;
    public static Context myContext;
    static String Station_Url;
    public static String currentPlayingName = "";
    static File cacheDir;
    static String tempFilePath;
    public static Boolean isPrepare = false, isBuffering = false;
    public MediaControllerCompat mediaController;
    List<MediaSessionCompat.QueueItem> mPlaylist = new ArrayList<>();

    public static Service me = null;
    public Context context;

    static long mili;
    public static Handler SleepoffHandler = new Handler();

    static File f = null;
    static OutputStream recordedoutput = null;
    static int rMaxMillis; // in millis
    public static Handler RecordingTimerHandler = new Handler();

    public static RecordingTask recordAsync;
    public static OutputStream outputStream;
    public static InputStream inputStream;

    public static Globals globals;
    public boolean flag_for_item = true;
    public static UpdateMediaItemTask umiTask;

    // Receiver for lock and unlock screen
    BroadcastReceiver myBroadcast = new BroadcastReceiver() {

        //When Event is published, onReceive method is called
        @Override
        public void onReceive(Context context, Intent intent) {
            // TODO Auto-generated method stub
            Debugger.debugI("[BroadcastReceiver]", "MyReceiver");

            if (intent.getAction().equals(Intent.ACTION_SCREEN_ON)) {
                Debugger.debugI("[BroadcastReceiver]", "Service Screen ON");
            } else if (intent.getAction().equals(Intent.ACTION_SCREEN_OFF)) {
                Debugger.debugI("[BroadcastReceiver]", "Service OFF");

                if (PlaylistManager.isPlaying()) {
                    Intent it = new Intent("intent.my.action");
                    it.setComponent(new ComponentName(context.getPackageName(), LockScreenPlayer.class.getName()));
                    it.setFlags(FLAG_ACTIVITY_NEW_TASK);
                    context.getApplicationContext().startActivity(it);
                }
            }
        }
    };

    // for incoming call - states
    @RequiresApi(api = Build.VERSION_CODES.S)
    private static abstract class CallStateListener extends TelephonyCallback implements TelephonyCallback.CallStateListener {
        @Override
        abstract public void onCallStateChanged(int state);
    }

    @RequiresPermission(android.Manifest.permission.READ_PHONE_STATE)
    private CallStateListener callStateListener = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) ?
            new CallStateListener() {
                @Override
                public void onCallStateChanged(int state) {
                    // Handle call state change
                    performStateOperation(state);
                }
            }
            : null;

    private PhoneStateListener phoneStateListener = (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) ?
            new PhoneStateListener() {
                @Override
                public void onCallStateChanged(int state, String phoneNumber) {
                    // Handle call state change
                    Debugger.debugE(TAG, " call perform state operation ");
                    performStateOperation(state);
                }
            }
            : null;

    // when state is ringing or receive than stop playing station and if recording is running than also stop
    public void performStateOperation(int state) {

        if (state == TelephonyManager.CALL_STATE_RINGING || state == TelephonyManager.CALL_STATE_OFFHOOK) {
            Debugger.debugI(TAG, "CALL_STATE_RINGING");// Incoming call: Pause music
            if (PlaylistManager.isPlaying()) {
                mWasPlayingWhenCalled = true;

                mPlayback.stop();
                mSession.setActive(false);

                if (PlaylistManager.isRecording()) {
                    stopRecording(globals.radioServiceActivity);
                }
            }
        } else if (state == TelephonyManager.CALL_STATE_IDLE) {
            Debugger.debugI(TAG, "CALL_STATE_IDLE");// Not in call: Play music
            if (mWasPlayingWhenCalled) {
                playStation(((Globals) context.getApplicationContext()), context);
                mWasPlayingWhenCalled = false;
            }
        }

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // TODO Auto-generated method stub
        Debugger.debugD(TAG, "onStartCommand");
        me = this;
        context = me.getApplicationContext();
        rMaxMillis = (((Globals) context).getMaxRecordingTime() * 60 * 1000); // in millis
        animation = AnimationUtils.loadAnimation(context, R.anim.rotation);
        // initializeRadioPlayer();
        return START_NOT_STICKY;
    }


    //show time picker
    public static void ShowTimePicker(RadioPlayerActivity radioPlayerActivity, final Context context) {

        AlertDialog.Builder builder = new AlertDialog.Builder(radioPlayerActivity);

        LayoutInflater factory = LayoutInflater.from(radioPlayerActivity);
        @SuppressLint("InflateParams") View layout = factory.inflate(R.layout.timepicker_dialogview, null);

        builder.setCancelable(true);
        builder.setTitle("Set Timer");
        builder.setIcon(R.drawable.ic_baseline_access_alarm_24);
        builder.setView(layout);

        final TimePicker timePicker = layout.findViewById(R.id.timePicker1);
        timePicker.setIs24HourView(true);
        timePicker.setCurrentHour(0);
        timePicker.setCurrentMinute(1);

        builder.setPositiveButton("Disable",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        SleepoffHandler.removeCallbacks(mSleepTask);
                        RadioPlayerActivity.txt_timer.setVisibility(View.GONE);
                        dialog.dismiss();
                    }
                });

        builder.setNegativeButton("Set",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mili = (timePicker.getCurrentHour() * 3600000) + (timePicker.getCurrentMinute() * 60000);
                        if (mili == 0) {
                            Utils.showToast(context, "Please set valid timer.");
                        } else {
                            SleepoffHandler.removeCallbacks(mSleepTask);
                            OnTimer();
                            Bundle bundle = new Bundle();
                            bundle.putString(AnalyticsConstants.EVENT_CATEGORY, AnalyticsConstants.EC_player);
                            bundle.putString("timer", (timePicker.getCurrentHour() * 60) + timePicker.getCurrentMinute() + "");
                        }
                        dialog.dismiss();
                    }
                });

        AlertDialog alert = builder.create();
        alert.show();
    }

    public static void OnTimer() {
        SleepoffHandler.postDelayed(mSleepTask, 0);
    }

    /**
     * Background Runnable thread
     */
    private static Runnable mSleepTask = new Runnable() {
        @SuppressLint("SetTextI18n")
        public void run() {

            RadioPlayerActivity.txt_timer.setVisibility(View.VISIBLE);
            @SuppressLint("DefaultLocale") String hms = String.format("%02d:%02d:%02d",
                    TimeUnit.MILLISECONDS.toHours(mili),
                    TimeUnit.MILLISECONDS.toMinutes(mili) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(mili)),
                    TimeUnit.MILLISECONDS.toSeconds(mili) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(mili)));
            RadioPlayerActivity.txt_timer.setText("Time until sleep: " + hms);

            if (mili > 0) {
                mili -= 1000;
                SleepoffHandler.postDelayed(this, 1000);
            } else {
                RadioPlayerActivity.txt_timer.setVisibility(View.GONE);
                Debugger.debugI(TAG, "Stop due to timer completed!");
                if (mPlayback.isPlaying()) {
                    Debugger.debugI(TAG, " timer completed!");
                    //RMusicService.play_stop_Event((Globals) myContext.getApplicationContext(), myContext);

                    stopStation(globals.radioServiceActivity);
                    mPlayback.stop();
                }
            }
        }
    };

    public static void start() {
        Debugger.debugI(TAG, "Timer start");
        m_stopwatch.start();
    }

    public static void pause() {
        Debugger.debugI(TAG, "Timer pause");
        m_stopwatch.pause();
    }

    public static void reset() {
        Debugger.debugI(TAG, "Timer reset");
        m_stopwatch.reset();
    }

    public static long getElapsedTime() {
        return m_stopwatch.getElapsedTime();
    }

    public static void resetRecordingParams() {
        reset();
        rMaxMillis = (((Globals) myContext).getMaxRecordingTime() * 60 * 1000); // in millis
        Debugger.debugI(TAG, "total ms: " + rMaxMillis);
    }

    public static void startRecordingTimer() {
        resetRecordingParams();
        Debugger.debugI(TAG, "---startRecordingTimer---");
        try {
            RecordingTimerHandler.removeCallbacks(mRecordingTimerTask);
            if (isPrepare) {
                start();
                RecordingTimerHandler.postDelayed(mRecordingTimerTask, 0);
            }
        } catch (Exception ee) {
            Debugger.debugI(TAG, ee.getMessage());
        }
    }

    /**
     * Background Runnable thread
     */
    private static Runnable mRecordingTimerTask = new Runnable() {
        public void run() {

            if (rMaxMillis > getElapsedTime()) {

                RecordingTimerHandler.postDelayed(this, 100);

            } else {

                if (Globals.isActivityVisible()) {
                    stopStation(globals.radioServiceActivity);
                } else {
                    //   mPlayback.stop(); //if station want to stop
                    saveRecordingIfInBackground();
                }
                // stopRecording(globals.radioServiceActivity);

            }
        }
    };

    public static void startRecordingThread() {
        cacheDir = ((Globals) myContext.getApplicationContext()).makeDir(myContext);

        if (cacheDir != null) {

            Utils.showToast(myContext.getApplicationContext(), "Start recording");
            if (isTablet) {
                RadioPlayerActivity.btn_record.setImageResource(R.drawable.player_tab_recording_icon);
            } else {
                RadioPlayerActivity.btn_record.setImageResource(R.drawable.player_layout_recording_icon);
            }
            startRecordingTimer();
            PlaylistManager.setRecording(true);

            try {
                if (cacheDir != null) {
                    f = new File(cacheDir, "Temp.mp3");
                    tempFilePath = f.getAbsolutePath();
                    Debugger.debugI(TAG, "Path :" + tempFilePath);
                    recordedoutput = new FileOutputStream(f);

                    recordAsync = new RecordingTask();
                    recordAsync.execute();
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }

        }
    }

    public static class RecordingTask extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... voids) {

            try {
                Channel channel;
                if (PlaylistManager.getPlayingChannel() != null) {
                    channel = PlaylistManager.getPlayingChannel();

                    URL url = new URL(channel.ChannelLink);
                    inputStream = url.openStream();
                    outputStream = new FileOutputStream(new File(tempFilePath));

                    Debugger.debugI(TAG, " -------------------==================>> || START RECORDING || <<=====================--------------------- ");
                    int read;
                    while ((read = inputStream.read()) != -1) {

                        if (!PlaylistManager.isRecording()) {
                            inputStream.close();

                            if (outputStream != null) {
                                outputStream.flush();
                                outputStream.close();
                            }
                            return null;
                        }
                        outputStream.write(read);

                    }
                }


            } catch (Exception ee) {
                Debugger.debugI(TAG, "recordingError: " + ee.getMessage());
            }

            return null;
        }
    }

    public static void stopRecording(Context context1) {
        if (Globals.isActivityVisible()) {
            PlaylistManager.setRecording(false);

            RecordingTimerHandler.removeCallbacks(mRecordingTimerTask);
            pause();
            Debugger.debugI(TAG, "onStop Recording");
            if (isTablet) {
                RadioPlayerActivity.btn_record.setImageResource(R.drawable.player_tab_record_icon);
            } else {
                RadioPlayerActivity.btn_record.setImageResource(R.drawable.player_layout_record_icon);
            }

            recordAsync.cancel(true);

            showRecordingCompleteDialog(context1);
        } else {
            saveRecordingIfInBackground();
        }

    }

    private static void showRecordingCompleteDialog(Context context1) {

        Debugger.debugD(TAG, "Activity Context: " + context1.getClass().getSimpleName());
        ArrayList<Channel> channelArray = PlaylistManager.getStationList();
        final String stationName;
        if (channelArray != null && channelArray.size() > 0) {
            stationName = channelArray.get(PlaylistManager.getCurrentIndex()).ChannelTitle;
        } else {
            stationName = MM_Song_Info_Not_Found;
        }
        String songName = currentPlayingName;
        Context con = context1;
        Dialog dialog = new Dialog(con);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setTitle("Save As");
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.custom_alert_layout);

        TextView textView = dialog.findViewById(R.id.tv_msg);
        EditText etInput = dialog.findViewById(R.id.input);
        TextView btnOk = dialog.findViewById(R.id.btn_ok);

        textView.setText("Save As");

        etInput.setInputType(InputType.TYPE_CLASS_TEXT);
        etInput.setHint("Enter File Name");
        etInput.setText((songName.length() > 0) ? songName : stationName);
        etInput.setSelection(etInput.getText().length());

        etInput.setCursorVisible(false);
        etInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etInput.setSelection(etInput.getText().length());
                etInput.setCursorVisible(true);
            }
        });

        etInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if (etInput.getText().toString().trim().length() > 0) {
                    btnOk.setEnabled(true);
                } else {
                    btnOk.setEnabled(false);
                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        btnOk.setOnClickListener(new View.OnClickListener() {
            String fName = "";
            File to;
            int duration = 0;

            @Override
            public void onClick(View v) {
                btnOk.setEnabled(false);
                fName = etInput.getText().toString().trim();

                //Rename Existing file.
                Debugger.debugI(TAG, "tempFilePath : " + tempFilePath);

                MediaPlayer mp = new MediaPlayer();
                mp.setAudioStreamType(AudioManager.STREAM_MUSIC);
                mp.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                    @Override
                    public void onPrepared(MediaPlayer mp) {
                        insertRecordingDetail(mp.getDuration(), mp);
                    }
                });

                try {
                    mp.setDataSource(tempFilePath);
                    mp.prepare();
                } catch (Exception e) {
                    e.printStackTrace();
                    insertRecordingDetail(duration, mp);
                }
            }

            private void insertRecordingDetail(long duration, MediaPlayer mp) {

                long timeStamp = System.currentTimeMillis();
                File from = new File(tempFilePath);
                to = new File(((Globals) context1.getApplicationContext()).getDir(context1), fName + "_" + timeStamp + ".mp3");
                from.renameTo(to);

                Utils.showToast(context1, "Recorded File save successfully");

                DBHelper.getDBHelper(context1).addRecording(new Recording(fName, stationName, String.valueOf(duration), to.getAbsolutePath(), String.valueOf(timeStamp)));
                if (mp != null) {
                    mp.release();
                    mp = null;
                    Debugger.debugI(TAG, "Media player is release.");
                }

                // Wait 200ms to quit the Activity
                (new Handler()).postDelayed(mRunnerHide, 200);
            }

            Runnable mRunnerHide = new Runnable() {
                public void run() {
                    dialog.dismiss();
                }
            };

        });


        try {
            dialog.show();
        } catch (Exception ee) {
            Debugger.debugE(TAG, "Errror ---> " + ee.getMessage());
        }

    }

    /**
     * Function to play a song
     */
    public static void playStation(Globals globals, Context activityContext) {

        myContext = activityContext.getApplicationContext();

        stopPlayerOfRecordFragmentBeforeAction();

        Station_Url = PlaylistManager.getPlayingURL();
        Debugger.debugI(TAG, "<<<<<<<<<<<<<<<<< New playing url : " + Station_Url + " >>>>>>>>>>>>>>>>>>>>>>");

        Channel currentChannel = PlaylistManager.getStationList().get(PlaylistManager.getCurrentIndex());
        //currentChannel.put("last_played_date", Long.toString(System.currentTimeMillis()));
        currentChannel.lastPlayedDate = System.currentTimeMillis();
        globals.AddStationToHistory(activityContext, currentChannel);

        // here set the current playing station
        selectedStation = PlaylistManager.getStationList().get(PlaylistManager.getCurrentIndex());

        try {

            PlaylistManager.setError(false);

            MediaMetadataCompat mPreparedMedia = new MediaMetadataCompat.Builder()
                    .putString(MediaMetadataCompat.METADATA_KEY_MEDIA_ID, currentChannel.ChannelLink)
                    .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, (String) "")
                    .putString(MediaMetadataCompat.METADATA_KEY_GENRE, (String) "")
                    .putString(MediaMetadataCompat.METADATA_KEY_TITLE, (String) currentChannel.ChannelTitle)
                    .build();

            mPlayback.playFromMedia(mPreparedMedia);
            PlaylistManager.setIsPlayingFlag(true);

        } catch (IllegalArgumentException | IllegalStateException e) {
            e.printStackTrace();
            Debugger.debugI(TAG, e.toString());
        }
    }

    // stop stations also stop record if is ON
    public static void stopStation(Context context1) {

        //changes
        stopPlayerOfRecordFragmentBeforeAction();

        if (mPlayback.isPlaying()) {
            Debugger.debugI(TAG, "test stop station");

            changePlayerStopLayout(context1);
            mPlayback.stop();
        }

    }

    public static void changePlayerStopLayout(Context context1) {

        if (PlaylistManager.isRecording()) {
            Debugger.debugI(TAG, "test changePlayerStopLayout");
            stopRecording(context1);
        }

        PlaylistManager.setIsPlayingFlag(false);
        Debugger.debugI(TAG, "changePlayerStopLayout ->  call ");
        if (me != null) {
            me.stopForeground(true);
        }

        currentPlayingName = myContext.getString(R.string.song_info_not_found);

        setSongLabel(currentPlayingName);

        if (LockScreenPlayer.isVisible) {
            LockScreenPlayer.songNameLabel.setText(currentPlayingName);

            //  LockScreenPlayer.btn_play.clearAnimation();
            LockScreenPlayer.btn_play.setBackgroundResource(R.drawable.player_layout_play_icon);

        } else if (RadioPlayerActivity.isVisible) {
            RadioPlayerActivity.songNameLabel.setText(currentPlayingName);

            //   RadioPlayerActivity.btn_play.clearAnimation();
            RadioPlayerActivity.btn_play.setBackgroundResource(R.drawable.player_layout_play_icon);
        }

        if (MainActivity.ivPlayBottom != null) {
            MainActivity.ivPlayBottom.setImageResource(R.drawable.bottom_layout_play_icon);
        }
    }

    public static void play_stop_Event(Globals globals, Context context) {
        Debugger.debugI(TAG, "play_stop_Event");

        // changes ( when player in ready state )
        if (isPLAY) {
            Debugger.debugI(TAG, "before stop");
            // if (exoPlayer != null && exoPlayer.getPlaybackState() == ExoPlayer.STATE_READY) {
            stopStation(context);
            try {
                Bundle bundle = new Bundle();
                bundle.putString(AnalyticsConstants.EVENT_CATEGORY, AnalyticsConstants.EC_player);
                bundle.putString("stopping_st_name", PlaylistManager.getStationList().get(PlaylistManager.getCurrentIndex()).ChannelTitle);
            } catch (Exception ee) {
                Debugger.debugI(TAG, "play_stop_Event -> error -> " + ee.getMessage());
            }
            Debugger.debugI(TAG, "stop");
        } else {
            if ((RadioPlayerActivity.isVisible && RadioPlayerActivity.btn_play.getBackground().getConstantState()
                    .equals(ContextCompat.getDrawable(context.getApplicationContext(), R.drawable.player_layout_play_icon).getConstantState()))
                    || (LockScreenPlayer.isVisible && LockScreenPlayer.btn_play.getBackground().getConstantState()
                    .equals(ContextCompat.getDrawable(context.getApplicationContext(), R.drawable.player_layout_play_icon).getConstantState()))
            ) {
                Debugger.debugI(TAG, "btn_play");
                if (RadioPlayerActivity.isVisible)
                    RadioPlayerActivity.btn_play.setBackgroundResource(R.drawable.player_layout_stop_icon);
                else if (LockScreenPlayer.isVisible)
                    LockScreenPlayer.btn_play.setBackgroundResource(R.drawable.player_layout_stop_icon);


                if (MainActivity.ivPlayBottom != null) {
                    MainActivity.ivPlayBottom.setImageResource(R.drawable.player_layout_stop_icon);
                }
                playStation(globals, context);

            } else {
                Debugger.debugI(TAG, "load btn");
                playStation(globals, context);
                //stopStation();

            }
        }
    }


    /**
     * local code end
     */

    @Override
    public void onCreate() {
        super.onCreate();
        Debugger.debugI(TAG, "onCreate: ");
        myContext = this;
        mContext = this;

        globals = (Globals) getApplicationContext();

        mSession = new MediaSessionCompat(this, "RMusicService");
        MediaSessionCallback mCallback = new MediaSessionCallback();
        mSession.setCallback(mCallback);
        mSession.setFlags(
                MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS
                        | MediaSessionCompat.FLAG_HANDLES_QUEUE_COMMANDS
                        | MediaSessionCompat.FLAG_HANDLES_TRANSPORT_CONTROLS);

        setSessionToken(mSession.getSessionToken());

        mMediaNotificationManager = new MediaNotificationManager(this);

        mPlayback = new ExoPlayerAdapter(this, new MediaPlayerListener());

        registerReceiver(myBroadcast, new IntentFilter(Intent.ACTION_SCREEN_ON));
        registerReceiver(myBroadcast, new IntentFilter(Intent.ACTION_SCREEN_OFF));

        TelephonyManager telephonyManager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);

        if (!callStateListenerRegistered) {

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                    telephonyManager.registerTelephonyCallback(getMainExecutor(), callStateListener);
                    callStateListenerRegistered = true;
                }
            } else {
                telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_CALL_STATE);
                callStateListenerRegistered = true;
            }
        }

        m_stopwatch = new Stopwatch();

        Debugger.debugI(TAG, "onCreate: MusicService creating MediaSession, and MediaNotificationManager");
    }

    // call when onMetadataChange in exoPlayer
    public void onMetadata(MediaMetadata mediaMetadata) {

        if (selectedStation != null) {
            Debugger.debugD(TAG, "onMetadata Service: " + selectedStation);
            umiTask = new UpdateMediaItemTask((String) mediaMetadata.title, selectedStation, mediaMetadata, new OnPostCallback() {
                @Override
                public void onPostListener(String albumUrl, Channel stationModel) {
                    setAlbumUris(albumUrl);
                    checkPlayerIsPlay = 1;
                    String songAlbumName = (String) mediaMetadata.title;
                    String replaceSongAlbumName;

                    // RadioPlayerActivity.getName(RMusicService.currentPlayingName);
                    if (songAlbumName != null && songAlbumName.length() > 1) {
                        replaceSongAlbumName = (String) mediaMetadata.title;
                    } else {
                        replaceSongAlbumName = MM_Song_Info_Not_Found;
                    }
                    setAlbumTitle(replaceSongAlbumName);
                    MediaMetadataCompat mPreparedMedia;
                    if (stationModel != null) {
                        mPreparedMedia = new MediaMetadataCompat.Builder()
                                .putString(MediaMetadataCompat.METADATA_KEY_MEDIA_ID, stationModel.ChannelLink)
                                .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, replaceSongAlbumName)
                                .putString(MediaMetadataCompat.METADATA_KEY_ALBUM_ART_URI, (String) albumUrl)
                                .putString(MediaMetadataCompat.METADATA_KEY_TITLE, (String) stationModel.ChannelTitle)
                                .build();

                        mSession.setMetadata(mPreparedMedia);
                    }

                    setSongLabel(replaceSongAlbumName);

                    if (MainActivity.tvStationBottom != null && MainActivity.tvStationBottom.getText().toString().equals(Constant.MM_DEFAULT_TEXT_WHEN_CLEAR)) {
                        MainActivity.tvSongBottom.setText(MM_Song_Info_Not_Found);
                        RMusicService.stopStation(context);
                    }

                    if (RadioPlayerActivity.currentSongImage != null) {
                        Glide.with(context)
                                .load(albumUrl)
                                .diskCacheStrategy(DiskCacheStrategy.DATA)
                                .placeholder(R.drawable.player_img_view)
                                .into(RadioPlayerActivity.currentSongImage);
                    }


                    if (LockScreenPlayer.albumArtView != null) {
                        Glide.with(context)
                                .load(albumUrl)
                                .diskCacheStrategy(DiskCacheStrategy.DATA)
                                .placeholder(R.drawable.player_img_view)
                                .into(LockScreenPlayer.albumArtView);
                    }
                }
            });
            umiTask.execute();
        }
    }

    // call when exoplayer error occur
    public void onMetadataNotGetting() {

        setDefaultSessionData();
        if (RadioPlayerActivity.loaderLay != null) {
            loaderLay.setVisibility(View.GONE);
        }
        if (MainActivity.loaderLay != null) {
            MainActivity.loaderLay.setVisibility(View.GONE);
        }
        stopStation(mContext);
        mPlayback.onStop();
    }

    public void setDefaultSessionData() {
        if (selectedStation != null) {
            MediaMetadataCompat mPreparedMedia = new MediaMetadataCompat.Builder()
                    .putString(MediaMetadataCompat.METADATA_KEY_MEDIA_ID, "")
                    .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, MM_Song_Info_Not_Found)
                    .putString(MediaMetadataCompat.METADATA_KEY_ALBUM_ART_URI, String.valueOf(Uri.parse("android.resource://" + getPackageName() + "/" + R.drawable.player_img_view)))
                    .putString(MediaMetadataCompat.METADATA_KEY_TITLE, (String) selectedStation.ChannelTitle)
                    .build();

            mSession.setMetadata(mPreparedMedia);
            mSession.isActive();
        }
    }

    //call when user remove app from recentList
    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);

        // save file when user's recording ON and clear app from recent
        saveRecordingIfInBackground();

        Utils.saveInt(globals.getApplicationContext(), "position", PlaylistManager.getCurrentIndex());

        ExoPlayerAdapter.stopPlayerChanges();
        stopSelf();
    }

    public static void saveRecordingIfInBackground() {
        if (PlaylistManager.isRecording()) {
            Debugger.debugI(TAG, "test changePlayerStopLayout");

            PlaylistManager.setRecording(false);

            RecordingTimerHandler.removeCallbacks(mRecordingTimerTask);
            pause();
            Debugger.debugI(TAG, "onStop Recording");
            if (isTablet) {
                RadioPlayerActivity.btn_record.setImageResource(R.drawable.player_tab_record_icon);
            } else {
                RadioPlayerActivity.btn_record.setImageResource(R.drawable.player_layout_record_icon);
            }

            recordAsync.cancel(true);

            final String stationName;
            ArrayList<Channel> channelArray = PlaylistManager.getStationList();
            if (channelArray != null && channelArray.size() > 0)
                stationName = channelArray.get(PlaylistManager.getCurrentIndex()).ChannelTitle;
            else
                stationName = MM_Song_Info_Not_Found;
            String songName = currentPlayingName;
            String fName = (songName.length() > 0) ? songName : stationName;


            //Rename Existing file.
            Debugger.debugI(TAG, "tempFilePath : " + tempFilePath);

            MediaPlayer mp = new MediaPlayer();
            mp.setAudioStreamType(AudioManager.STREAM_MUSIC);
            mp.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    // insertRecordingDetail(mp.getDuration(), mp);

                    long timeStamp = System.currentTimeMillis();
                    File from = new File(tempFilePath);
                    File to = new File(((Globals) globals.getApplicationContext()).getDir(globals.getApplicationContext()), fName + "_" + timeStamp + ".mp3");
                    from.renameTo(to);

                    Utils.showToast(globals.getApplicationContext(), "Recorded File save successfully");

                    DBHelper.getDBHelper(globals.getApplicationContext()).addRecording(new Recording(fName, stationName, String.valueOf(mp.getDuration()), to.getAbsolutePath(), String.valueOf(timeStamp)));
                    if (mp != null) {
                        mp.release();
                        mp = null;
                        Debugger.debugI(TAG, "Media player is release.");
                    }

                }
            });

            try {
                mp.setDataSource(tempFilePath);
                mp.prepare();
            } catch (Exception e) {
                e.printStackTrace();
//                insertRecordingDetail(duration, mp);

                long timeStamp = System.currentTimeMillis();
                File from = new File(tempFilePath);
                File to = new File(((Globals) globals.getApplicationContext().getApplicationContext()).getDir(globals.getApplicationContext()), fName + "_" + timeStamp + ".mp3");
                from.renameTo(to);

                Utils.showToast(globals.getApplicationContext(), "Recorded File save successfully");
                Utils.saveInt(globals.getApplicationContext(), "position", PlaylistManager.getCurrentIndex());

                DBHelper.getDBHelper(globals.getApplicationContext()).addRecording(new Recording(fName, stationName, String.valueOf(0), to.getAbsolutePath(), String.valueOf(timeStamp)));
                if (mp != null) {
                    mp.release();
                    mp = null;
                    Debugger.debugI(TAG, "Media player is release.");
                }
            }
        }
    }

    interface OnPostCallback {
        public void onPostListener(String albumUrl, Channel stationModel);
    }

    // update all data when metadata is come
    public static class UpdateMediaItemTask extends AsyncTask<Void, Void, Void> {

        String responseStr;
        String s;
        String albumUrl;
        Channel stationModel;
        MediaMetadata mediaMetadata;
        OnPostCallback onPostCallback;

        UpdateMediaItemTask(String url, Channel station, MediaMetadata mediaMetadata, OnPostCallback onPostCallback) {
            s = url;
            this.stationModel = station;
            this.mediaMetadata = mediaMetadata;
            this.onPostCallback = onPostCallback;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            Debugger.debugI(TAG, "  TRUE WORD --> " + s);

            albumUrl = getAlbumArtUri("player_img_view");

            if (s != null) {
                if (!s.equals("") && s.length() > 3) {
                    String fullSongName = s.trim().replaceAll(" |-", "+");
                    fullSongName = fullSongName.trim().replaceAll("(\\d)", "");
                    String s1[] = s.trim().split("-");
                    String songName = s1[0];
                    songName = songName.trim().replaceAll(" ", "+");

                    final String url = Constant.SONG_ALBUM_ART_SEARCH_URL.replace("stxt", fullSongName);
                    final String newUrl = Constant.SONG_ALBUM_ART_SEARCH_URL.replace("stxt", songName);
                    try {
                        Debugger.debugI(TAG, "  FULL NAME SONG URL --> " + url);
                        Debugger.debugI(TAG, "  SONG URL --> " + newUrl);

                        //  FULL NAME SONG URL
                        responseStr = runAlbumApi(url);
                        if (responseStr == null || responseStr.contains("<html>")) {
                            Debugger.debugI(TAG, " not getting any album uri ");
                        } else {
                            JSONArray jsonArray = new JSONObject(responseStr).getJSONArray("results");
                            if (jsonArray != null && jsonArray.length() > 0) {
                                String tempUrl = jsonArray.getJSONObject(0).getString("artworkUrl100");
                                albumUrl = tempUrl.replace("100x100bb.jpg", "800x800bb.jpg");
                            } else {
                                // SONG NAME URL
                                responseStr = runAlbumApi(newUrl);
                                if (responseStr == null || responseStr.equals("")) {
                                    Debugger.debugI(TAG, " not getting any album uri ");
                                } else {
                                    JSONArray jsonArray2 = new JSONObject(responseStr).getJSONArray("results");
                                    if (jsonArray2 != null && jsonArray2.length() > 0) {
                                        String tempUrl = jsonArray2.getJSONObject(0).getString("artworkUrl100");
                                        albumUrl = tempUrl.replace("100x100bb.jpg", "800x800bb.jpg");
                                    }
                                }

                            }
                        }

                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void unused) {
            super.onPostExecute(unused);
            Debugger.debugE(TAG, "OnPost UpdateMediaTask");
            onPostCallback.onPostListener(albumUrl, stationModel);

        }

    }

    // get resource path from drawable
    private static String getAlbumArtUri(String albumArtResName) {
        return ContentResolver.SCHEME_ANDROID_RESOURCE + "://" +
                BuildConfig.APPLICATION_ID + "/drawable/" + albumArtResName;
    }

    // get api response
    public static String runAlbumApi(String url) throws IOException {
        OkHttpClient client = new OkHttpClient();
        okhttp3.Request request = new okhttp3.Request.Builder()
                .url(url)
                .build();

        try (okhttp3.Response response = client.newCall(request).execute()) {
            return response.body().string();
        }
    }

    // check exoplayer is playing or not
    public static boolean checkExoIsPlaying() {
        if (mPlayback != null) {
            if (mPlayback.isPlaying()) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void onDestroy() {
        Debugger.debugI(TAG, "--------- onDestroy: ----------");
        ExoPlayerAdapter.stopPlayerChanges();
        //local code start
        stopForeground(true);
        unregisterReceiver(myBroadcast);
        //local code end

        mMediaNotificationManager.onDestroy();
        mPlayback.stop();
        mSession.release();
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.cancelAll();
        Debugger.debugI(TAG, "onDestroy: MediaPlayerAdapter stopped, and MediaSession released");
    }

    @Override
    public BrowserRoot onGetRoot(@NonNull String clientPackageName, int clientUid, Bundle rootHints) {
        Debugger.debugI(TAG, "onGetRoot: ");

        return new BrowserRoot(ROOT, null);
    }

    @Override
    public void onLoadChildren(@NonNull final String parentMediaId, @NonNull final Result<List<MediaBrowserCompat.MediaItem>> result) {
        Globals globals = (Globals) getApplicationContext();

        Debugger.debugI(TAG, "onLoadChildren");

        mMediaBrowserHelper = new MediaBrowserConnection(mContext);

        if (parentMediaId.equals(ROOT)) {

            result.sendResult(Utils.getCategories());

        } else {

            Debugger.debugI(TAG, "selected parentMediaId --->> " + parentMediaId);

            if (parentMediaId.equals(Constant.FAVOURITE)) {
                //favourite list contents

                selectedPlayListCategory = 1;
                result.detach();

                ArrayList<Channel> favouriteFetchArray = globals.fetchFavoriteList(globals.getApplicationContext());
                //////////////////////////////////////
                ArrayList<HashMap<String, String>> ownFetchArray = globals.fetchUserAddedStationList(globals.getApplicationContext());

                //change here
                for (int i = 0; i < ownFetchArray.size(); i++) {
                    HashMap<String, String> ownStation = ownFetchArray.get(i);

                    Channel ownChannel = new Channel(ownStation.get(Constant.MM_OWN_STATION_RANDOM_ID).toString(), ownStation.get(Constant.MM_OWN_STATION_NAME).toString(), ownStation.get(Constant.MM_OWN_STATION_URL).toString(), ownStation.get(Constant.MM_OWN_STATION_URL).toString(), "", 0, "", "", "", 0);
                    Debugger.debugI(TAG, "Added channel == " + ownChannel.ChannelTitle);
                    favouriteFetchArray.add(ownChannel);

                }
                ///////////////////////////////////////
                if (favouriteFetchArray != null && favouriteFetchArray.size() > 0) {

                    Debugger.debugD(TAG, " Fetch favourite list");

                    Gson gson = new Gson();
                    tempFavArray = new ArrayList<>();
                    tempFavArray.clear();
                    tempFavArray.addAll(favouriteFetchArray);
                    favMediaItemList.clear();
                    for (Channel channel : tempFavArray) {

                        Bundle bundle = new Bundle();
//                        bundle.putString(channel.ChannelId, gson.toJson(channel));
//                        bundle.putSerializable("data", channel);
                        bundle.putString(Constant.CHANNEL_DATA, gson.toJson(channel));
                        bundle.putString(Constant.CHANNEL_TYPE, "favorites");

                        MediaDescriptionCompat mediaDesc = new MediaDescriptionCompat.Builder()
                                .setMediaId(channel.ChannelId)
                                .setTitle(channel.ChannelTitle)
                                .setExtras(bundle)
                                .build();

                        favMediaItemList.add(new MediaBrowserCompat.MediaItem(mediaDesc, MediaBrowserCompat.MediaItem.FLAG_PLAYABLE));

                    }
                    Debugger.debugD(TAG, " - fav tab - ");
                    channelInPlayListTemp = tempFavArray;

                    result.sendResult(favMediaItemList);

                    //here we call the mediaConnection & MediaBrowserListeners
                    mMediaBrowserHelper.onStart();


                } else {
                    result.sendResult(Collections.emptyList());
                }

                return;
            } else if (parentMediaId.equals(Constant.HISTORY)) {

                result.detach();
                selectedPlayListCategory = 2;

                ArrayList<Channel> historyArray = globals.fetchHistoryList(globals.getApplicationContext());
                if (historyArray != null && historyArray.size() > 0) {

                    Gson gson = new Gson();
                    tempHistoryArray = new ArrayList<>();
                    tempHistoryArray.clear();
                    tempHistoryArray.addAll(historyArray);

                    historyMediaItemList.clear();
                    for (Channel channel : tempHistoryArray) {
                        Bundle bundle = new Bundle();
//                        bundle.putString(channel.ChannelId, gson.toJson(channel));
//                        bundle.putSerializable("data", channel);
                        bundle.putString(Constant.CHANNEL_DATA, gson.toJson(channel));
                        bundle.putString(Constant.CHANNEL_TYPE, "history");

                        MediaDescriptionCompat mediaDesc = new MediaDescriptionCompat.Builder()
                                .setMediaId(channel.ChannelId)
                                .setExtras(bundle)
                                .setTitle(channel.ChannelTitle)
                                .build();

                        historyMediaItemList.add(new MediaBrowserCompat.MediaItem(mediaDesc, MediaBrowserCompat.MediaItem.FLAG_PLAYABLE));

                    }
                    Debugger.debugD(TAG, " - history tab - ");
                    channelInPlayListTemp = tempHistoryArray;
                    result.sendResult(historyMediaItemList);

                    //here we call the mediaConnection & MediaBrowserListeners
                    mMediaBrowserHelper.onStart();

                } else {
                    result.sendResult(Collections.emptyList());
                }
                return;
            } else if (parentMediaId.equals(Constant.BROWSE)) {
                result.detach();

                /**
                 // LANGUAGES
                 here we load all languages by calling getCategories()  **/
                Debugger.debugD(TAG, " - browse main tab - ");
                SELECTED_MAIN_CATEGORY = Constant.BROWSE;
                getLanguages(globals, result);

            } else {
                Debugger.debugD(TAG, " stations - " + parentMediaId);
                /**
                 // STATIONS
                 here we get all station list of selected language
                 here parentMediaId provides all json data of that language so we can easily parse  **/
                result.detach();
                selectedPlayListCategory = 0;
                getStations(parentMediaId, result, globals);

                //here we call the mediaConnection & MediaBrowserListeners
                mMediaBrowserHelper.onStart();

            }

        }

    }

    // set album title from station metadata
    public static void setAlbumTitle(String title) {
        albumTitle = title;
    }

    // get album title from station metadata
    public static String getAlbumTitle() {
        return albumTitle;
    }

    // set album uri from station metadata
    public static void setAlbumUris(String url) {
        currentAlbumUrl = url;
    }

    // get album uri from station metadata
    public static String getAlbumUris() {
        return currentAlbumUrl;
    }


    @Override
    public void onLoadItem(String itemId, @NonNull Result<MediaBrowserCompat.MediaItem> result) {
        super.onLoadItem(itemId, result);
    }

    // get all stations from language parentMediaId
    public static void getStations(String parentMediaId, Result<List<MediaBrowserCompat.MediaItem>> result, Globals globals) {
        Debugger.debugI(TAG, "Parent ID for get stations :" + parentMediaId);

        if (parentMediaId == null || globals.getLanguageList().size() <= 0) {
            return;
        }

        if (parentMediaId.length() > 1) {

            try {
                JSONObject jsonObject = new JSONObject(parentMediaId);
                parentMediaId = jsonObject.getString("LanguageId");
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }

        Gson gson = new Gson();
        Language LanguageObj = null;

        // here we get language model from language id
        for (Language language : globals.getLanguageList()) {
            if (language.LanguageId.equals(parentMediaId)) {
                LanguageObj = language;
                break;
            }
        }

        // set stationList by selected model
        ChannelManager.getListManager(false).setStationList(globals, LanguageObj.channels);
        tempBrowseArray.clear();

        for (ChannelItem chItem : ChannelManager.getListManager(false).getChannelList()) {
            tempBrowseArray.add(chItem.getChannelMap());
        }

        Debugger.debugI(TAG, "PLAYLIST :" + tempBrowseArray.toString());
        stationMediaItemList.clear();
        for (Channel channel : tempBrowseArray) {

            Bundle bundle = new Bundle();
            bundle.putString(Constant.CHANNEL_DATA, gson.toJson(channel));
//            bundle.putSerializable("data", channel);
            bundle.putString(Constant.CHANNEL_TYPE, "channel");

            MediaDescriptionCompat mediaDesc = new MediaDescriptionCompat.Builder()
                    .setMediaId(channel.ChannelId)
                    .setExtras(bundle)
                    .setTitle(channel.ChannelTitle)
                    .build();

            stationMediaItemList.add(new MediaBrowserCompat.MediaItem(mediaDesc, MediaBrowserCompat.MediaItem.FLAG_PLAYABLE));


        }
        Debugger.debugI("TAG", "Selected lang from DHU -->  " + tempBrowseArray.get(0).LanguageName);
        channelInPlayListTemp = tempBrowseArray;

        result.sendResult(stationMediaItemList);
    }

    public void updateCategoryList(String parentId) {
        // Notify all subscribed clients that the children of the parent item have changed
        notifyChildrenChanged(parentId);
    }

    // get all language list
    private void getLanguages(Globals globals, @NonNull final Result<List<MediaBrowserCompat.MediaItem>> resultx) {

        if (globals.getLanguageList() != null && globals.getLanguageList().size() > 0) {

            Debugger.debugI(TAG, "if api data is already having");
            ArrayList<Language> allLanguages = new ArrayList<>();
            allLanguages = globals.getLanguageList();

            cateMediaItemList.clear();

            for (Language languageModel : allLanguages) {

                MediaDescriptionCompat mediaDesc = new MediaDescriptionCompat.Builder()
                        .setMediaId(languageModel.LanguageId + "")   // for getting the index of language and fetch stations
                        .setTitle(languageModel.LanguageName)
                        .build();

                cateMediaItemList.add(new MediaBrowserCompat.MediaItem(mediaDesc, MediaBrowserCompat.MediaItem.FLAG_BROWSABLE));

            }
            resultx.sendResult(cateMediaItemList);

        } else {

            Debugger.debugI(TAG, "call Api for new data");

            new DataProvider(globals, new OnApiCallListener() {
                @Override
                public void onSuccessListener(String result) {

                    if (!result.trim().equalsIgnoreCase("error_in_response")) {
                        try {
                            JSONObject main = new JSONObject(result.trim());
                            if (main.get("result").toString().trim().equals("true")) {
                                JSONArray data = main.getJSONArray("data");
                                //  globals.setLanguageList(Parser.getGenreList(globals, data));

                                ArrayList<Language> allLanguages = new ArrayList<>();
                                allLanguages = Parser.getGenreList(globals, data);

                                cateMediaItemList.clear();

                                for (Language category : allLanguages) {

                                    MediaDescriptionCompat mediaDesc = new MediaDescriptionCompat.Builder()
                                            .setMediaId("" + category.LanguageId)
                                            .setTitle(category.LanguageName)
                                            .build();

                                    cateMediaItemList.add(new MediaBrowserCompat.MediaItem(mediaDesc, MediaBrowserCompat.MediaItem.FLAG_BROWSABLE));

                                }

                                resultx.sendResult(cateMediaItemList);

                            } else {
                                JSONObject error = main.getJSONObject("error");
                                globals.showCustomMessageOK(mContext, Constant.MM_ALERT_TITLE_ERROR, error.getString("info"), true);
                            }
                        } catch (JSONException e) {
                            Debugger.debugI(TAG, e.toString());
                            e.printStackTrace();
                            Utils.showToast(mContext, Constant.MM_PARSING_FAILD);
                        }
                    } else
                        ConnectionDetector.showAlertDialog(mContext, Constant.MM_ALERT_TITLE_ERROR, Constant.MM_NO_INTERNET_RESPOND_MSG, true);

                }

                @Override
                public void onFailListener(String error) {
                    Debugger.debugI(TAG, error);
                }
            }).execute();
        }

    }

    private class MediaBrowserConnection extends MediaBrowserHelper {

        private MediaBrowserConnection(Context context) {
            super(context, RMusicService.class);
            Debugger.debugI(TAG, "MediaBrowserConnection: ");
        }

        @Override
        protected void onConnected(@NonNull MediaControllerCompat mediaController) {
            Debugger.debugI(TAG, "onConnected: ");
        }

        @Override
        protected void onChildrenLoaded(@NonNull String parentId,
                                        @NonNull List<MediaBrowserCompat.MediaItem> children) {
            super.onChildrenLoaded(parentId, children);
            Debugger.debugI(TAG, "onChildrenLoaded: ## " + queueUpdateArray.size());
            mediaController = getMediaController();
            addAllQueueItems();

        }
    }

    private void addAllQueueItems() {

        mPlaylist.clear();
        Gson gson = new Gson();
        for (Channel channel : queueUpdateArray) {
            Bundle bundle = new Bundle();
//            bundle.putString(channel.ChannelId, gson.toJson(channel));
            bundle.putString(Constant.CHANNEL_DATA, gson.toJson(channel));
//                bundle.putSerializable("data", channel);
            bundle.putString(Constant.CHANNEL_TYPE, "channel");

            MediaDescriptionCompat mediaDesc = new MediaDescriptionCompat.Builder()
                    .setMediaId(channel.ChannelId)
                    .setTitle(channel.ChannelTitle)
                    .setExtras(bundle)
                    .build();

            mediaController.addQueueItem(mediaDesc);

        }

        mediaController.getTransportControls().prepare();
    }

    public static int getMusicIndexOnQueue(List<MediaSessionCompat.QueueItem> queue,
                                           long queueId) {
        int index = 0;
        for (MediaSessionCompat.QueueItem item : queue) {
            if (queueId == item.getQueueId()) {
                return index;
            }
            index++;
        }
        return -1;
    }

    // MediaSession Callback: Transport Controls -> MediaPlayerAdapter
    public class MediaSessionCallback extends MediaSessionCompat.Callback {

        private int mQueueIndex = -1;
        private MediaMetadataCompat mPreparedMedia;

        @Override
        public void onAddQueueItem(MediaDescriptionCompat description) {
            Debugger.debugI(TAG, "onAddQueueItem: " + description.getTitle());

            mPlaylist.add(new MediaSessionCompat.QueueItem(description, description.hashCode()));
            mQueueIndex = (mQueueIndex == -1) ? 0 : mQueueIndex;
            mSession.setQueue(mPlaylist);

        }

        @Override
        public void onRemoveQueueItem(MediaDescriptionCompat description) {
            Debugger.debugI(TAG, "onRemoveQueueItem: ");
            mPlaylist.remove(new MediaSessionCompat.QueueItem(description, description.hashCode()));
            mQueueIndex = (mPlaylist.isEmpty()) ? -1 : mQueueIndex;
            mSession.setQueue(mPlaylist);
        }

        @Override
        public void onPrepare() {

            Debugger.debugI(TAG, "onPrepare: ");

            try {
                if (selectedStation != null) {

                    Debugger.debugI(TAG, "onPrepare MediaId --->>> " + selectedStation.ChannelId);
                    //here we add channel to history list
                    Channel station = selectedStation;
                    globals.AddStationToHistory(globals.getApplicationContext(), station);
                    setStationLabel(station.ChannelTitle);

                    lastPlayedStation = station.ChannelLink;

                    // update screen while user click on queue and back to the player
                    mQueueIndex = Utils.getMediaPosition(station.ChannelId);
                    PlaylistManager.setCurrentIndex(mQueueIndex);
                    Debugger.debugI(TAG, "wrong title - " + getAlbumTitle());
                    Debugger.debugI(TAG, "wrong album - " + getAlbumUris());

                    mPreparedMedia = new MediaMetadataCompat.Builder()
                            .putString(MediaMetadataCompat.METADATA_KEY_MEDIA_ID, station.ChannelLink)
                            .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, getAlbumTitle())
                            .putString(MediaMetadataCompat.METADATA_KEY_ALBUM_ART_URI, (String) getAlbumUris())
                            .putString(MediaMetadataCompat.METADATA_KEY_TITLE, (String) station.ChannelTitle)
                            .build();

                    mSession.setMetadata(mPreparedMedia);

                    if (!mSession.isActive()) {
                        mSession.setActive(true);
                    }
                }
            } catch (Exception ee) {
                Debugger.debugI(TAG, "onPrepare -> Error -> " + ee.getMessage());
            }

        }

        @Override
        public void onPlay() {

            Debugger.debugI(TAG, "onPlay: ");

            stopPlayerOfRecordFragmentBeforeAction();

            if (mPreparedMedia == null) {
                onPrepare();
            }

            if (selectedStation != null)
                isPLAY = true;
            mPlayback.playFromMedia(mPreparedMedia);

        }

        //when user click on queue item
        @Override
        public void onSkipToQueueItem(long id) {
            super.onSkipToQueueItem(id);

            // stop player of recordedFragment if it is ON
            stopPlayerOfRecordFragmentBeforeAction();

            //for default player set
            mPreparedMedia = new MediaMetadataCompat.Builder()
                    .putString(MediaMetadataCompat.METADATA_KEY_MEDIA_ID, PlaylistManager.getPlayingURL())
                    .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, getAlbumTitle())
                    .putString(MediaMetadataCompat.METADATA_KEY_ALBUM_ART_URI, null)
                    .putString(MediaMetadataCompat.METADATA_KEY_TITLE, (String) MM_Song_Info_Not_Found)
                    .build();

            mSession.setMetadata(mPreparedMedia);

            // for session refresh
            if (!mSession.isActive()) {
                mSession.setActive(true);
            }

            mQueueIndex = getMusicIndexOnQueue(mPlaylist, id);
            Debugger.debugI(TAG, "onSkipToQueueItem - " + mQueueIndex);

            // for session refresh
            if (!mSession.isActive()) {
                mSession.setActive(true);
            }

            int index = getMediaPosition(selectedStation.ChannelId);
            Utils.saveInt(globals.getApplicationContext(), "position", mQueueIndex);
            selectedStation = PlaylistManager.getStationList().get(mQueueIndex);
            playNow(index);
        }

        @Override
        public void onPlayFromSearch(String query, Bundle extras) {
            super.onPlayFromSearch(query, extras);


            Debugger.debugD(TAG, " searchable text is - " + query);
            boolean isArtistFocus, isAlbumFocus;

            if (TextUtils.isEmpty(query)) {
                Debugger.debugD(TAG, " searchable text is empty ");
                // The user provided generic string e.g. 'Play music'
                // Build appropriate playlist queue
            } else {
                // Build a queue based on songs that match "query" or "extras" param


              //  if (channelInPlayList != null && channelInPlayList.size() > 0) {

                    for (int i = 0; i < channelInPlayList.size(); i++) {

                        if (channelInPlayList.get(i).ChannelTitle.equalsIgnoreCase(query)) {

                            Channel searchChannel = channelInPlayList.get(i);

                            try {

                                mPreparedMedia = new MediaMetadataCompat.Builder()
                                        .putString(MediaMetadataCompat.METADATA_KEY_MEDIA_ID, searchChannel.ChannelLink)
                                        .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, (String) " ")
                                        .putString(MediaMetadataCompat.METADATA_KEY_ALBUM_ART_URI, "")
                                        .putString(MediaMetadataCompat.METADATA_KEY_TITLE, (String) searchChannel.ChannelTitle)
                                        .build();

                                mSession.setMetadata(mPreparedMedia);

                                mPlayback.playFromMedia(mPreparedMedia);

                            } catch (Exception e) {
                                Debugger.debugD(TAG, "onPlayFromSearch: " + e.getMessage());
                            }

                            break;

                        }

                    }

              //  }

                String mediaFocus = extras.getString(MediaStore.EXTRA_MEDIA_FOCUS);
                if (TextUtils.equals(mediaFocus,
                        MediaStore.Audio.Artists.ENTRY_CONTENT_TYPE)) {
                    isArtistFocus = true;
                    //artist = extras.getString(MediaStore.EXTRA_MEDIA_ARTIST);
                } else if (TextUtils.equals(mediaFocus,
                        MediaStore.Audio.Albums.ENTRY_CONTENT_TYPE)) {
                    isAlbumFocus = true;
                    //album = extras.getString(MediaStore.EXTRA_MEDIA_ALBUM);
                }

                // Implement additional "extras" param filtering
            }
        }

        @Override
        public void onPlayFromMediaId(String mediaId, Bundle extras) {
            super.onPlayFromMediaId(mediaId, extras);

            try {

                stopPlayerOfRecordFragmentBeforeAction();


                Debugger.debugD(TAG, extras.toString());
                String type = extras.getString(Constant.CHANNEL_TYPE);
                Channel channelData = new Gson().fromJson(extras.getString(Constant.CHANNEL_DATA), Channel.class);
                for (String key : extras.keySet()) {
                    Log.e(TAG, key + " : " + (extras.get(key) != null ? extras.get(key) : "NULL"));
                }
                Debugger.debugI(TAG, "onPlayFromMediaId: " + mediaId);
                Debugger.debugI(TAG, "onPlayFromMediaId Data: " + channelData);
                Debugger.debugI(TAG, "onPlayFromMediaId Type: " + type);

                if (type.equals("favorites")) {
                    if (tempFavArray == null) {

                        ArrayList<Channel> favouriteFetchArray = globals.fetchFavoriteList(globals.getApplicationContext());

                        //  sort array by language id
                        Collections.sort(favouriteFetchArray, new Comparator() {
                            @Override
                            public int compare(Object o1, Object o2) {
                                Channel p1 = (Channel) o1;
                                Channel p2 = (Channel) o2;
                                return p1.LanguageId.compareToIgnoreCase(p2.LanguageId);
                            }
                        });


                        ArrayList<HashMap<String, String>> ownFetchArray = globals.fetchUserAddedStationList(globals.getApplicationContext());

                        //change here
                        for (int i = 0; i < ownFetchArray.size(); i++) {
                            HashMap<String, String> ownStation = ownFetchArray.get(i);

                            Channel ownChannel = new Channel(ownStation.get(Constant.MM_OWN_STATION_RANDOM_ID).toString(), ownStation.get(Constant.MM_OWN_STATION_NAME).toString(), ownStation.get(Constant.MM_OWN_STATION_URL).toString(), ownStation.get(Constant.MM_OWN_STATION_URL).toString(), "", 0, "", "", "", 0);
                            Debugger.debugI(TAG, "Added channel == " + ownChannel.ChannelTitle);
                            favouriteFetchArray.add(ownChannel);

                        }
                        channelInPlayList = favouriteFetchArray;

                    } else {
                        channelInPlayList = tempFavArray;
                    }
                    //saveLastPlaylistNdStation();

                } else if (type.equals("history")) {
                    ArrayList<Channel> historyArray = globals.fetchHistoryList(globals.getApplicationContext());
                    if (historyArray != null && historyArray.size() > 0) {
                        Collections.reverse(historyArray);
                        channelInPlayList = historyArray;
                    } else {
                        Collections.reverse(tempHistoryArray);
                        channelInPlayList = tempHistoryArray;
                    }
                    //saveLastPlaylistNdStation();
                } else if (type.equals("search")) {
                    channelInPlayList = globals.getChannelList();
                    //saveLastPlaylistNdStation();
                } else if (type.equals("after_remove")) {
                    ArrayList<Channel> lastArray = Utils.getArrayList(globals.getApplicationContext(), "lastPlayedArray");
                    if (lastArray != null)
                        channelInPlayList = lastArray;
                    //saveLastPlaylistNdStation();
                } else {
                    channelInPlayList = getChannelItems(channelData.LanguageId);  // when user play
                    //saveLastPlaylistNdStation();
                }
                Utils.saveArrayList(globals.getApplicationContext(), channelInPlayList, "lastPlayedArray");
                Utils.saveString(globals.getApplicationContext(), "lastType", type);
                selectedStation = channelData;
                mStationArrayList = channelInPlayList;

                int currentIndex = 0;

                //  update playlist
                if (mediaId != null && !mediaId.equals("")) {

                    for (int i = 0; i < channelInPlayList.size(); i++) {
                        if (channelInPlayList.get(i).ChannelId.equals(channelData.ChannelId)) {
                            currentIndex = i;
                            PlaylistManager.setCurrentIndex(currentIndex);
                            Utils.saveInt(globals.getApplicationContext(), "position", currentIndex);
                            break;
                        }
                    }

                    //currentIndex = Utils.getMediaPosition(mediaId);
                    if (channelInPlayList != null && channelInPlayList.size() > 0) {
                        PlaylistManager.setStation_list(channelInPlayList, 1);
                        RadioPlayerActivity.loadPlaylist();
                    }

                }

                try {
                    setStationLabel(mStationArrayList.get(currentIndex).ChannelTitle);
                } catch (Exception e) {
                    Debugger.debugI(TAG, " onPlayFromMediaId -> error -> " + e.getMessage());
                }

                PlaylistManager.setCurrentIndex(currentIndex);
                playTune();

                //  add all channels in Queue List
                if (mediaController != null) {

                    mPlaylist.clear();

                    Debugger.debugI(TAG, "total items in list " + channelInPlayList.size());
                    for (Channel channel : channelInPlayList) {

                        MediaDescriptionCompat mediaDesc = new MediaDescriptionCompat.Builder()
                                .setMediaId(channel.ChannelId)
                                .setTitle(channel.ChannelTitle)
                                .build();
                        mediaController.addQueueItem(mediaDesc);

                    }

                    // call prepare now so pressing play just works.
                    mediaController.getTransportControls().prepare();

                    queueUpdateArray = channelInPlayList;
                }

                if (globals.radioServiceActivity != null && globals.radioServiceActivity instanceof MainActivity) {
                    Debugger.debugI(TAG, "onPlayFromMediaId: refresh MainActivity menu when play station");
                    ((MainActivity) globals.radioServiceActivity).invalidateMenu();
                }

            } catch (Exception e) {
                Debugger.debugE(TAG, "error playfrommediaid -> " + e.getMessage());
            }


        }

        public void saveLastPlaylistNdStation() {
            if (channelInPlayList != null && channelInPlayList.size() > 0) {
                Debugger.debugE(TAG, " last station list size - " + channelInPlayList.size());
                Utils.saveArrayList(mContext, channelInPlayList, "lastPlayedArray");
            }

            if (selectedStation != null) {
                String lastStation = new Gson().toJson(selectedStation);
                Debugger.debugE(TAG, " last station before save - " + lastStation);
                Utils.saveString(mContext, "lastStation", lastStation);
            }
        }

        @Override
        public void onPause() {
            Debugger.debugI(TAG, "onPause: ");
            mPlayback.pause();
        }

        @Override
        public void onStop() {

            stopPlayerOfRecordFragmentBeforeAction();

            if (PlaylistManager.isRecording()) {
                Debugger.debugI(TAG, "stop recording");
                //    stopRecording(globals.radioServiceActivity);

                PlaylistManager.setRecording(false);

                RecordingTimerHandler.removeCallbacks(mRecordingTimerTask);
                pause();
                Debugger.debugI(TAG, "onStop Recording");
                if (isTablet) {
                    RadioPlayerActivity.btn_record.setImageResource(R.drawable.player_tab_record_icon);
                } else {
                    RadioPlayerActivity.btn_record.setImageResource(R.drawable.player_layout_record_icon);
                }

                recordAsync.cancel(true);

                final String stationName = PlaylistManager.getStationList().get(PlaylistManager.getCurrentIndex()).ChannelTitle;
                String songName = currentPlayingName;

                startActivity(new Intent(globals.radioServiceActivity, showRecordingCompleteDialogActivity.class)
                        .putExtra("stationName", stationName)
                        .putExtra("songName", songName)
                        .putExtra("tempFilePath", tempFilePath)
                        .putExtra("duration", 0).addFlags(FLAG_ACTIVITY_NEW_TASK));

            }
            Debugger.debugI(TAG, "onStop: ");
            mPlayback.stop();
            mSession.setActive(false);
            ExoPlayerAdapter.stopPlayerChanges();

        }

        @Override
        public void onSkipToNext() {

            Debugger.debugI(TAG, "onSkipToNext: ");

            int index = getMediaPosition(selectedStation.ChannelId);
            selectedStation = nextStationModel(index);
            int currentIndex = index;
            if (currentIndex < PlaylistManager.getStationList().size() - 1) {
                currentIndex = currentIndex + 1;
            } else {
                currentIndex = 0;
            }
            Utils.saveInt(globals.getApplicationContext(), "position", currentIndex);
            playNow(index);

        }

        @Override
        public void onSkipToPrevious() {

            Debugger.debugI(TAG, "onSkipToPrevious: ");

            int index = getMediaPosition(selectedStation.ChannelId);
            selectedStation = previousStationModel(index);
            int currentIndex = index;
            if (currentIndex > 0) {
                currentIndex = currentIndex - 1;
            } else {
                currentIndex = PlaylistManager.getStationList().size() - 1;
            }
            Utils.saveInt(globals.getApplicationContext(), "position", currentIndex);
            playNow(index);

        }

        private void playTune() {

            mPreparedMedia = null;

            onPrepare();
            isPLAY = true;
            mPlayback.playFromMedia(mPreparedMedia);
            if (selectedStation != null)
                PlaylistManager.currentIndex = getMediaPosition(selectedStation.ChannelId);

        }

        public void playNow(int index) {
            stopPlayerOfRecordFragmentBeforeAction();

            // stop recording if is ON
            if (PlaylistManager.isRecording()) {
                stopRecording(globals.radioServiceActivity);
            }

            PlaylistManager.setCurrentIndex(index);
            playTune();
        }

        @Override
        public void onSeekTo(long pos) {
        }

        @SuppressLint("RestrictedApi")
        @Override
        public void onCustomAction(String action, Bundle extras) {
            super.onCustomAction(action, extras);
            if (action.equals("toggle_favorite")) {
                // Handle favorite action
                Debugger.debugD(TAG, "Custom action favorite");

                ArrayList<Channel> tempFevList = ((Globals) getApplicationContext()).fetchFavoriteList(globals.getApplicationContext());
                int index = favoriteIndex(tempFevList);

                isTablet = getResources().getBoolean(R.bool.isTablet);
                int favImage;
                if (checkIsFavourite(selectedStation)) {
                    if (btn_addToFavorite != null) {
                        if (isTablet) {
                            btn_addToFavorite.setImageResource(R.drawable.player_tab_favorite_icon);
                        } else {
                            btn_addToFavorite.setImageResource(R.drawable.player_layout_favorite_icon);
                        }
                    }
                    Utils.showToast(getApplicationContext(), "Station is remove from favourite");
                    favImage = R.drawable.player_layout_favorite_icon;
                    tempFevList.remove(index);
                    ((Globals) getApplicationContext()).saveFavoriteList(globals.getApplicationContext(), tempFevList);
                } else {
                    if (btn_addToFavorite != null) {
                        if (isTablet) {
                            btn_addToFavorite.setImageResource(R.drawable.player_tab_added_favorites_icon);
                        } else {
                            btn_addToFavorite.setImageResource(R.drawable.player_layout_favorite_added_icon);
                        }
                    }
                    Utils.showToast(getApplicationContext(), "Station is added in favourite");
                    favImage = R.drawable.player_layout_favorite_added_icon;
                    tempFevList.add(selectedStation);
                    ((Globals) getApplicationContext()).saveFavoriteList(globals.getApplicationContext(), tempFevList);
                }

                updateCategoryList(Constant.FAVOURITE); //for update favourite mediaItemList

                // for update device favourite adapter start
                if (adapter != null && fList != null) {
                    savedFevoList = globals.fetchFavoriteList(globals.getApplicationContext());
                    ownStationList = globals.fetchUserAddedStationList(globals.getApplicationContext());
                    if (savedFevoList.size() == 0 && ownStationList.size() == 0) {
                        switcher.setDisplayedChild(0);
                    } else {
                        switcher.setDisplayedChild(1);
                        LoadFavoriteList(globals.getApplicationContext(), globals);
                    }
                }
                updateItemAtPosition();
                // for update device favourite adapter end

                // for getting playbackState
                PlaybackStateCompat state = mSession.getController().getPlaybackState();

                changesWhilePlaybackStateChange(state, null, favImage, 0);

            } else if (action.equals("update_playlist")) {

                List<MediaSessionCompat.QueueItem> queue = new ArrayList<>();

                ArrayList<Channel> updatedList = (ArrayList<Channel>) extras.getSerializable("list");
                int currentPlaybackState = 0;
                float playbackSpeed = 0f;
                long capabilities = 0;
                @SuppressLint("RestrictedApi") long currentPosition = 0;

                if (updatedList != null) {
                    Debugger.debugE(TAG, " check it updated list " + updatedList.toString());

                    Gson gson = new Gson();
                    try {
                        for (int i = 0; i < updatedList.size(); i++) {

                            Bundle bundle = new Bundle();

                            String channelData = gson.toJson(updatedList.get(i));
                            String channelType = "after_remove";
                            String channelTitle = updatedList.get(i).ChannelTitle;
                            String channelId = updatedList.get(i).ChannelId;
                            PlaylistManager.setStationType(channelType);

                            saveString(globals.getApplicationContext(), "lastType", channelType);

                            bundle.putString(Constant.CHANNEL_DATA, channelData);
                            bundle.putString(Constant.CHANNEL_TYPE, channelType);

                            MediaDescriptionCompat.Builder descBuilder = new MediaDescriptionCompat.Builder();
                            descBuilder.setMediaId(channelId)
                                    .setTitle(channelTitle)
                                    .setExtras(bundle).build();
                            MediaSessionCompat.QueueItem item =
                                    new MediaSessionCompat.QueueItem(descBuilder.build(), i);
                            queue.add(item);

                        }
                    } catch (Exception e) {
                        Debugger.debugE(TAG, "error - >> " + e.getMessage());
                    }

                    saveArrayList(globals.getApplicationContext(), updatedList, "lastPlayedArray");

                    //  MediaControllerCompat.TransportControls transportControls = mediaController.getTransportControls();

// Step 4: Update the queue items
                    mSession.setQueue(queue);

                }

            }
        }

    }


    public static void stopPlayerOfRecordFragmentBeforeAction() {
        // stop recorded audio
        if (RecordedPlayerService.rPlayer != null && RecordedPlayerService.rPlayer.isPlaying()) {

            //RecordedManager.setIsPlayingFlag(false);
            RecordedPlayerService.stopPLaying();
            RecordedManager.init();
        }
    }

    // MediaPlayerAdapter Callback: MediaPlayerAdapter state -> MusicService.
    public class MediaPlayerListener implements PlayBackChangeListener {

        private final ServiceManager mServiceManager;

        MediaPlayerListener() {
            mServiceManager = new ServiceManager();
        }

        @Override
        public void onPlaybackStateChange(PlaybackStateCompat state) {
            // Report the state to the MediaSession.
            Debugger.debugI(TAG, "onPlaybackStateChange: " + state.getState());

            if (selectedStation != null) {

                Debugger.debugI(TAG, "selected station: " + selectedStation.ChannelTitle);

                // here we update both adapters of ChannelFragment and RadioPlayer
                RadioPlayerActivity.updateItemAtPosition();
                if (ChannelListFragment.adapter != null) {
                    ChannelListFragment.adapter.notifyDataSetChanged();
                }

                int favImage;

                if (checkIsFavourite(selectedStation))
                    favImage = R.drawable.player_layout_favorite_added_icon;
                else
                    favImage = R.drawable.player_layout_favorite_icon;


                UpdateFavBtnView(globals.getApplicationContext());
                changesWhilePlaybackStateChange(state, mServiceManager, favImage, 1);
            }
        }

        class ServiceManager {

            private void moveServiceToStartedState(PlaybackStateCompat state) {
                Debugger.debugI(TAG, "Notification part - moveServiceToStartedState: ");
                MediaControllerCompat controller = mSession.getController();
                MediaMetadataCompat mediaMetadata = controller.getMetadata();
                Notification notification =
                        mMediaNotificationManager.getNotification(
                                mediaMetadata, state, getSessionToken());


                try {
                    if (!mServiceInStartedState) {
                        stopSelf();

                        ContextCompat.startForegroundService(RMusicService.this,
                                new Intent(RMusicService.this, RMusicService.class));
                        mServiceInStartedState = true;
                    }
                } catch (Exception ee) {

                }


                startForeground(MediaNotificationManager.NOTIFICATION_ID, notification);
            }

            private void updateNotificationForPause(PlaybackStateCompat state) {
                Debugger.debugI(TAG, "Notification part - updateNotificationForPause: ");

                stopForeground(false);

                MediaControllerCompat controller = mSession.getController();
                MediaMetadataCompat mediaMetadata = controller.getMetadata();
                Notification notification =
                        mMediaNotificationManager.getNotification(
                                mediaMetadata, state, getSessionToken());
                mMediaNotificationManager.getNotificationManager()
                        .notify(MediaNotificationManager.NOTIFICATION_ID, notification);
            }

            private void moveServiceOutOfStartedState(PlaybackStateCompat state) {
                Debugger.debugI(TAG, "Notification part - moveServiceOutOfStartedState: ");

                stopForeground(false);//false
                //stopSelf();

                MediaControllerCompat controller = mSession.getController();
                MediaMetadataCompat mediaMetadata = controller.getMetadata();
                Notification notification =
                        mMediaNotificationManager.getNotification(
                                mediaMetadata, state, getSessionToken());
                mMediaNotificationManager.getNotificationManager()
                        .notify(MediaNotificationManager.NOTIFICATION_ID, notification);
                mServiceInStartedState = false;
            }
        }
    }

    public void changesWhilePlaybackStateChange(PlaybackStateCompat state, MediaPlayerListener.ServiceManager mServiceManager, int favImage, int flgOpen) {

        Debugger.debugI(TAG, " update favourite data ");
        int currentPlaybackState = state.getState();
        @SuppressLint("RestrictedApi") long currentPosition = state.getCurrentPosition(0L);
        float playbackSpeed = state.getPlaybackSpeed();

        long capabilities = PlaybackStateCompat.ACTION_SKIP_TO_NEXT | PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS;

        // Manage the started state of this service.
        switch (state.getState()) {
            case PlaybackStateCompat.STATE_PLAYING:
                if (mServiceManager != null) {
                    mServiceManager.moveServiceToStartedState(state);
                }
                capabilities |= PlaybackStateCompat.ACTION_STOP;
                break;
            case PlaybackStateCompat.STATE_PAUSED:
                if (mServiceManager != null) {
                    mServiceManager.updateNotificationForPause(state);
                }
                capabilities |= PlaybackStateCompat.ACTION_PLAY;
                break;
            case PlaybackStateCompat.STATE_STOPPED:
                if (mServiceManager != null) {
                    mServiceManager.moveServiceOutOfStartedState(state);
                }
                capabilities |= PlaybackStateCompat.ACTION_PLAY;
                break;
        }

        MediaSessionCompat.QueueItem item = null;
        /**  code for display indicator for current playing queueItem in QueueItemList */
        if (flgOpen == 1) {

            int index = getMediaPosition(selectedStation.ChannelId);
            Debugger.debugD(TAG, "Playing index: " + index);

            if (mediaController != null) {
                List<MediaSessionCompat.QueueItem> items = mediaController.getQueue();  //get current QueueList from mediaController
                Debugger.debugD(TAG, "Playing queue: " + items);
                if (items != null && items.size() > index) {
                    item = items.get(index);
                }
            }

        }

        PlaybackStateCompat.CustomAction favoriteAction = new PlaybackStateCompat.CustomAction.Builder(
                "toggle_favorite",
                "Toggle Favorite",
                favImage)
                .build();

        PlaybackStateCompat.Builder builder = new PlaybackStateCompat.Builder()
                .setState(currentPlaybackState, currentPosition, playbackSpeed)
                .setActions(capabilities)
                .addCustomAction(favoriteAction);
        if (flgOpen == 1) {
            if (item != null)
                builder.setActiveQueueItemId(item != null ? item.getQueueId() : 0); //for display indicator
        }
        PlaybackStateCompat newState = builder.build();

        mSession.setPlaybackState(newState);

    }

    private boolean checkIsFavourite(Channel channel) {
        Debugger.debugE(TAG, " current playing station is " + channel.ChannelTitle);
        return globals.fetchFavoriteList(globals.getApplicationContext()).stream().filter(o -> o.ChannelTitle.equals(channel.ChannelTitle)).findFirst().isPresent();
    }

    private ArrayList<Channel> getChannelItems(String lang) {
        ArrayList<Language> langList = globals.getLanguageList();

        if (langList != null && langList.size() > 0) {
            Language languageObj = null;
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                languageObj = langList.stream().filter(language -> lang.equals(language.LanguageId)).findFirst().orElse(null);
            }
            if (languageObj != null)
                return languageObj.channels;
        }
        return null;
    }
}
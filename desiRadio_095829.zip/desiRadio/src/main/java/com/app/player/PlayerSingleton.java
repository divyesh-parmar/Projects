package com.app.player;

import static com.app.utility.Constant.MM_Song_Info_Not_Found;
import static com.app.utility.Constant.mStationArrayList;
import static com.app.utility.Utils.isMyServiceRunning;
import static com.app.utility.Utils.selectedStation;
import static com.app.utility.Utils.setSongLabel;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.media.MediaBrowserCompat;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaControllerCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import android.util.Log;

import androidx.annotation.NonNull;

import com.app.auto.MediaBrowserHelper;
import com.app.auto.RMusicService;
import com.app.desiradio.MainActivity;
import com.app.parser.Channel;
import com.app.utility.Constant;
import com.app.utility.Debugger;
import com.google.gson.Gson;
import com.indianradio.R;

import java.util.List;

public class PlayerSingleton {

    private static PlayerSingleton playerInstance;
    private MediaBrowserHelper mMediaBrowserHelper;
    public static boolean mIsPlaying;
    public String TAG = getClass().getSimpleName();

    public static PlayerSingleton getInstance() {

        if (playerInstance == null) {
            playerInstance = new PlayerSingleton();
        }
        return playerInstance;
    }

    public MediaBrowserHelper getmMediaBrowserHelper() {
        return mMediaBrowserHelper;
    }

    public void setmMediaBrowserHelper(MediaBrowserHelper mMediaBrowserHelper) {
        this.mMediaBrowserHelper = mMediaBrowserHelper;
    }

    public void init(Context context){

        //establish connection
        mMediaBrowserHelper = new MediaBrowserConnection(context);

        //MediaControllerCompatListener register
        mMediaBrowserHelper.registerCallback(new MediaBrowserListener());
        setmMediaBrowserHelper(mMediaBrowserHelper);

        try {
            Intent radioService = new Intent(context, RMusicService.class);
            if (!isMyServiceRunning(context, RMusicService.class)) {
//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//                    context.stopService(new Intent(context, RMusicService.class));
//                    context.startForegroundService(radioService);
//                } else {
                    context.startService(radioService);
//                }
            }
        }catch (Exception e){

        }
    }

    public void playTrack(){
        mMediaBrowserHelper.getTransportControls().play();
    }

    public void stopTrack(){
        mMediaBrowserHelper.getTransportControls().stop();
    }

    public void playTrackById(String id, Bundle bundle){
        mMediaBrowserHelper.getTransportControls().playFromMediaId(id, bundle);
    }

    public void startConnection(){
        mMediaBrowserHelper.onStart();
    }

    public void favouriteTrack(){
        mMediaBrowserHelper.getTransportControls().sendCustomAction("toggle_favorite", null);
    }

    public void nextTrack(){
        mMediaBrowserHelper.getTransportControls().skipToNext();
    }

    public void previousTrack(){
        mMediaBrowserHelper.getTransportControls().skipToPrevious();
    }

    /**
     * Customize the connection to our {@link .MediaBrowserServiceCompat}
     * and implement our app specific desires.
     */
    private class MediaBrowserConnection extends MediaBrowserHelper {
        private MediaBrowserConnection(Context context) {
            super(context, RMusicService.class);
            Debugger.debugI(TAG, "MediaBrowserConnection: ");
        }

        @Override
        protected void onConnected(@NonNull MediaControllerCompat mediaController) {
            //   mSeekBarAudio.setMediaController(mediaController);
            Debugger.debugI(TAG, "onConnected: ");

//            if (mStationArrayList != null && mStationArrayList.size() > 0) {
//                if (PlaylistManager.getCurrentIndex() >= 0) {
//                    Channel currentChannel = mStationArrayList.get(PlaylistManager.getCurrentIndex());
//
//                    if (currentChannel != null) {
//                        Debugger.debugI(TAG, "media connected url ---" + currentChannel.ChannelLink);
//                        Debugger.debugI(TAG, "ui selected station  --  " + selectedStation);
//                        //selectedStation = currentChannel;
//
//                        Bundle bundle = new Bundle();
////                    bundle.putString(currentChannel.ChannelId, selectedStation);
//                        bundle.putString(Constant.CHANNEL_DATA, new Gson().toJson(selectedStation));
//                        bundle.putString(Constant.CHANNEL_TYPE, PlaylistManager.getStationType());
//                        mediaController.getTransportControls().playFromMediaId(currentChannel.ChannelId, bundle);
//
//                    }
//                }
//            }

        }

        @Override
        protected void onDisconnected() {
            super.onDisconnected();
        }

        @Override
        protected void onChildrenLoaded(@NonNull String parentId,
                                        @NonNull List<MediaBrowserCompat.MediaItem> children) {
            super.onChildrenLoaded(parentId, children);
            Debugger.debugI(TAG, "onChildrenLoaded: dvs");

        }
    }

    /**
     * Implementation of the {@link MediaControllerCompat.Callback} methods we're interested in.
     * <p>
     * Here would also be where one could override
     * {@code onQueueChanged(List<MediaSessionCompat.QueueItem> queue)} to get informed when items
     * are added or removed from the queue. We don't do this here in order to keep the UI
     * simple.
     */
    private class MediaBrowserListener extends MediaControllerCompat.Callback {
        @Override
        public void onPlaybackStateChanged(PlaybackStateCompat playbackState) {
            Log.e(TAG, "onPlaybackStateChanged: singleton" );
            mIsPlaying = playbackState != null &&
                    playbackState.getState() == PlaybackStateCompat.STATE_PLAYING;
            if (mIsPlaying) {
                if (RadioPlayerActivity.btn_play != null) {
                    RadioPlayerActivity.btn_play.setImageResource(R.drawable.player_layout_stop_icon);
                }
                if (MainActivity.ivPlayBottom != null){
                    MainActivity.ivPlayBottom.setImageResource(R.drawable.player_layout_stop_icon);
                }
                if (LockScreenPlayer.btn_play != null) {
                    LockScreenPlayer.btn_play.setImageResource(R.drawable.player_layout_stop_icon);
                }

            } else {


                setSongLabel(MM_Song_Info_Not_Found);

                if (RadioPlayerActivity.btn_play != null) {
                    RadioPlayerActivity.btn_play.setImageResource(R.drawable.player_layout_play_icon);
                }
                if (MainActivity.ivPlayBottom != null){
                    MainActivity.ivPlayBottom.setImageResource(R.drawable.player_layout_play_icon);
                }
                if (LockScreenPlayer.btn_play != null) {
                    LockScreenPlayer.btn_play.setImageResource(R.drawable.player_layout_play_icon);
                }
            }

        }

        @Override
        public void onMetadataChanged(MediaMetadataCompat mediaMetadata) {
            Log.e(TAG, "onMetadataChanged: singleton" );
            if (mediaMetadata == null) {
                return;
            }

        }

        @Override
        public void onSessionDestroyed() {
            super.onSessionDestroyed();
        }

        @Override
        public void onQueueChanged(List<MediaSessionCompat.QueueItem> queue) {
            super.onQueueChanged(queue);
        }
    }


}

package com.app.recorded;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.app.sqlite.Recording;
import com.indianradio.R;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class RecordingRAdapter extends RecyclerView.Adapter<RecordingRAdapter.MyHolder> {

    Context context;
    List<Recording> rowItems;
    OnItemRecordLongClickListener onItemLongClickListener;


    public RecordingRAdapter(Context context, OnItemRecordLongClickListener onItemLongClickListener) {
        this.context = context;

        this.onItemLongClickListener = onItemLongClickListener;

    }

    public void updateResults(Context context, List<Recording> new_items) {
        this.context = context;
        this.rowItems = new_items;
        notifyDataSet();
    }

    public void notifyDataSet() {
        //Triggers the list update
        notifyDataSetChanged();
    }

    public String getDuration(long millis) {
        if (millis > 60000 && millis <= 94000) {
            millis = 60000;
        }
        return String.format("%02d:%02d",
                TimeUnit.MILLISECONDS.toMinutes(millis),
                TimeUnit.MILLISECONDS.toSeconds(millis) -
                        TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millis))
        );
    }

    /**
     * Return date in specified format.
     *
     * @param milliSeconds Date in milliseconds
     * @param dateFormat   Date format
     * @return String representing date in specified format
     */
    public String getDate(long milliSeconds, String dateFormat) {
        // Create a DateFormatter object for displaying date in specified format.
        DateFormat formatter = new SimpleDateFormat(dateFormat);

        // Create a calendar object that will convert the date and time value in milliseconds to date.
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(milliSeconds);
        return formatter.format(calendar.getTime());
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.recorded_list_item,parent,false);

        MyHolder myHolder = new MyHolder(view);

        return myHolder;
    }

    public Recording getItem(int position) {
        return rowItems.get(position);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, int position) {

        final Recording rowItem = getItem(position);

        if (RecordedManager.getCurrent_rID() != -99 && rowItem.getID() == RecordedManager.getCurrent_rID()) {
            holder.container.setBackgroundColor(context.getResources().getColor(R.color.blue_color));

            holder.tv_rName.setTextColor(context.getResources().getColor(R.color.record_subtext));
            holder.tv_sName.setTextColor(context.getResources().getColor(R.color.record_subtext));
            holder.textView2.setTextColor(context.getResources().getColor(R.color.record_subtext));
            holder.textView3.setTextColor(context.getResources().getColor(R.color.record_subtext));
            holder.textView4.setTextColor(context.getResources().getColor(R.color.record_subtext));
            holder.tv_duration.setTextColor(context.getResources().getColor(R.color.record_subtext));
            holder.tv_date.setTextColor(context.getResources().getColor(R.color.record_subtext));

        } else {
            holder.container.setBackground(new ColorDrawable(Color.TRANSPARENT));
            holder.tv_rName.setTextColor(context.getResources().getColor(R.color.nav_icon_color));
            holder.tv_sName.setTextColor(context.getResources().getColor(R.color.gray_color));
            holder.textView2.setTextColor(context.getResources().getColor(R.color.gray_color));
            holder.textView3.setTextColor(context.getResources().getColor(R.color.gray_color));
            holder.textView4.setTextColor(context.getResources().getColor(R.color.gray_color));
            holder.tv_duration.setTextColor(context.getResources().getColor(R.color.gray_color));
            holder.tv_date.setTextColor(context.getResources().getColor(R.color.gray_color));
        }

        holder.tv_rName.setTag(rowItem.getID());
        holder.tv_rName.setText(rowItem.getName());
        holder.tv_date.setText(getDate(Long.parseLong(rowItem.getDate()), "dd MMM yyyy, hh:mm:ss a"));
        holder.tv_duration.setText(getDuration(Long.parseLong(rowItem.getDuration())));
        holder.tv_sName.setText(rowItem.getStationName());

        holder.container.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int currentPos = position;
                onItemLongClickListener.onItemClicker(holder.tv_rName,currentPos);
            }
        });

        holder.container.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                int currentPos = position;
                onItemLongClickListener.onItemLongClick(holder.tv_rName,currentPos);
                return true;
            }
        });
    }

    @Override
    public int getItemCount() {
        return rowItems.size();
    }

    public long getItemId(int position) {
        return rowItems.indexOf(getItem(position));
    }

    public class MyHolder extends RecyclerView.ViewHolder {

        TextView tv_rName;
        TextView tv_date;
        TextView tv_duration;
        TextView tv_sName;
        TextView textView2;
        TextView textView3;
        TextView textView4;

        LinearLayout container;

        public MyHolder(@NonNull View itemView) {
            super(itemView);

            tv_rName = (TextView) itemView.findViewById(R.id.tv_rName);
            tv_date = (TextView) itemView.findViewById(R.id.tv_date);
            tv_duration = (TextView) itemView.findViewById(R.id.tv_duration);
            tv_sName = (TextView) itemView.findViewById(R.id.tv_stationName);
            textView2 = (TextView) itemView.findViewById(R.id.textView2);
            textView3 = (TextView) itemView.findViewById(R.id.textView3);
            textView4 = (TextView) itemView.findViewById(R.id.textView4);
            container = (LinearLayout) itemView.findViewById(R.id.container);
        }
    }
}

package com.android.GoogleAnalytics;

public class AnalyticsConstant {

	//SCREEN_NAME for Google Analytics 
	public static final String SN_category = "Category";
	public static final String SN_subCategory = "CategoryList > ";
	public static final String SN_channel = "ChannelList > ";
	public static final String SN_player = "PlayerView";
	public static final String SN_videolist = "Video List";
	public static final String SN_video = "Video";
	public static final String SN_top100 = "Top 100";
	public static final String SN_search = "Search";
	public static final String SN_favorites = "Favorites";
	public static final String SN_more = "More";
	public static final String SN_lockplayer = "Lock screen";
	public static final String SN_history = "History";
	public static final String SN_recorded = "Recorded";
	
	//Event Category for Google Analytics
	public static final String EC_category = "CATEGORY";
	public static final String EC_subcategory = "SUBCATEGORY";
	public static final String EC_channel_list = "CHANNEL_LIST";
	public static final String EC_player = "PLAYER";
	public static final String EC_videolist = "VIDEO_LIST";
	public static final String EC_top100 = "TOP100";
	public static final String EC_search = "SEARCH";
	public static final String EC_favorites = "FAVORITES";
	public static final String EC_history = "HISTORY";
	public static final String EC_more = "MORE";
	public static final String EC_lockplayer = "LOCK_SCREEN";
	
	public static final String EC_START = "START";
	public static final String EC_APPLICATION_RATER = "APPLICATION_RATER";
	public static final String EC_BANNER_ADVT_SUCCESS = "BANNER_ADVT_SUCCESS";
	public static final String EC_BANNER_ADVT_FAIL = "BANNER_ADVT_FAIL";
	public static final String EC_REMOVE_ADS = "REMOVE_ADS";
	public static final String EC_RecordingUpgrade = "RECORDING_UPGRADE";
	public static final String EC_PURCHASE_fail = "PURCHASE_FAIL";
	public static final String EC_Recording_purchase_success = "RECORDING_PURCHASE_SUCCESS";
	public static final String EC_NoAds_purchase_success = "NO_ADS_PURCHASE_SUCCESS";

	//new added
	public static final String EC_BANNER_ADVT_TOUCH = "BANNER_ADVT_TOUCH";
	
	//new 2
	public static final String EC_NATIVE_ADVT_SUCCESS = "NATIVE_ADVT_SUCCESS";
	public static final String EC_NATIVE_ADVT_FAIL = "NATIVE_ADVT_FAIL";
	public static final String EC_NATIVE_ADVT_TOUCH = "NATIVE_ADVT_TOUCH";
	
	public static final String EC_STARTAPP_NATIVE_ADVT_SUCCESS = "STARTAPP_NATIVE_ADVT_SUCCESS";
	public static final String EC_STARTAPP_NATIVE_ADVT_FAIL = "STARTAPP_NATIVE_ADVT_FAIL";
	public static final String EC_STARTAPP_NATIVE_ADVT_TOUCH = "STARTAPP_NATIVE_ADVT_TOUCH";
	
	//Event Action for Google Analytics 
	public static final String EA_play = "NOW_PLAYING";
	public static final String EA_play_channel = "PLAY_CHANNEL";
	public static final String EA_stop_channel = "STOP_CHANNEL";
	public static final String EA_next_channel = "NEXT_CHANNEL";
	public static final String EA_select_channel = "SELECT_CHANNEL";
	public static final String EA_previous_channel = "PREVIOUS_CHANNEL";
	public static final String EA_add_favorite = "ADD_FAVORITE_STATION";
	public static final String EA_remove_favorite = "REMOVE_FAVORITE_STATION";
	public static final String EA_edit_playlist = "EDIT_PLAYLIST";
	public static final String EA_done_playlist = "DONE_PLAYLIST";
	public static final String EA_clear_playlist = "CLEAR_PLAYLIST";
	public static final String EA_video_button = "VIDEO_BUTTON";
	public static final String EA_set_timer = "SET_TIMER";
	public static final String EA_sharing_button = "ACTION_BUTTON";
	public static final String EA_facebook = "FACEBOOK_BUTTON";
	public static final String EA_twitter = "TWITTER_BUTTON";
	public static final String EA_mail = "EMAIL_BUTTON";
	public static final String EA_sms = "SMS_BUTTON";
	public static final String EA_select_video = "SELECT_VIDEO";
	public static final String EA_search_op = "SEARCH_STATION";
	public static final String EA_more_apps = "MORE_APPS";
	public static final String EA_about_us = "ABOUT_US";
	public static final String EA_conatct_us = "CONTACT_US";
	public static final String EA_tell_a_friend = "TELL_A_FRIENDS";
	public static final String EA_rate_app = "RATE_THIS_APP";
	public static final String EA_select_category = "SELECT_CATEGORY";
	public static final String EA_select_subcategory = "SELECT_SUBCATEGORY";
	
	public static final String EA_refresh = "REFRESH_BUTTON";
	public static final String EA_search = "SEARCH_BUTTON";
	
	public static final String EA_UPDATE_DIALOG = "UPDATE_DIALOG";
	public static final String EA_UPDATE_NOW_BUTTON = "UPDATE_NOW_BUTTON";
	
	public static final String EA_APP_RATER_DIALOG = "APP_RATER_DIALOG";
	public static final String EA_LATER_BUTTON = "LATER_BUTTON";
	public static final String EA_NO_THANKS_BUTTON = "NO_THANKS_BUTTON";
	public static final String EA_RATE_NOW_BUTTON = "RATE_NOW_BUTTON";
	
	public static final String EA_NOTIFICATION_DIALOG = "NOTIFICATION_DIALOG";
	public static final String EA_LINK_BUTTON = "LINK_BUTTON";
	
	public static final String EA_NOTIFICATION_ON = "NOTIFICATION_ON";
	public static final String EA_NOTIFICATION_OFF = "NOTIFICATION_OFF";
	
	public static final String EA_whatsapp = "WHATSAPP_BUTTON";
	public static final String EA_USER_ADDED_STATION = "USER_ADDED_STATION";
	
	public static final String EA_Record_button = "RECORD_BUTTON";
	
	//new added
}

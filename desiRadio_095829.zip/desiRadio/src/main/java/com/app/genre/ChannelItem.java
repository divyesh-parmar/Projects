package com.app.genre;

import com.app.parser.Channel;

public class ChannelItem {
	
	public Channel itemMap;

//	public NativeAdItem nativeAdItem;
//
//	public IMNative inMobiNativeAd;

	public boolean isDisplayed = false;
//	public NativeAdDetails nativeAdDetails;

	public ChannelItem() {
		super();
	}

	public ChannelItem(Channel channelMap) {
		super();
		this.itemMap = channelMap;
	}

	public Channel getChannelMap() {
		return itemMap;
	}
	
/*
	public IMNative getInMobiNativeAd() {
		return inMobiNativeAd;
	}
	
	public NativeAdDetails getStartAppNativeAd() {
		return nativeAdDetails;
	}

	public NativeAdItem getNativeAdItem() {
		return nativeAdItem;
	}
*/

	public void setChannelMap(Channel itemMap) {
		this.itemMap = itemMap;
	}

/*
	public void setInMobiNativeAd(IMNative nativeAd1) {
		this.inMobiNativeAd = nativeAd1;
	}
	
	public void setStartAppNativeAd(NativeAdDetails nativeAdDetails) {
		this.nativeAdDetails = nativeAdDetails;
	}
	
	public void setNativeAdItem(NativeAdItem nativeAdItem) {
		this.nativeAdItem = nativeAdItem;
	}
*/

	public boolean isDisplayed() {
		return isDisplayed;
	}

	public void setDisplayed(boolean isDisplayed) {
		this.isDisplayed = isDisplayed;
	}
}

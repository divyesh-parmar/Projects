package com.app.auto.apicall;

import static com.app.genre.LanguageListFragment.rv_language;
import static com.app.utility.Utils.generateRandomNumber;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.AsyncTask;

import com.app.parser.Parser;
import com.app.utility.Constant;
import com.app.utility.Debugger;
import com.app.utility.Globals;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class DataProvider extends AsyncTask<Void, Void, Void> {

    public static String TAG = "DataProvider";
    OnApiCallListener callListener;
    String responseStr;
    String msg = "";
    @SuppressLint("StaticFieldLeak")
    Context context;
    Globals globals;

    public DataProvider(Globals context,OnApiCallListener callListener) {
        this.callListener = callListener;
        this.globals = context;
    }

    @Override
    protected Void doInBackground(Void... voids) {

        OkHttpClient client = new OkHttpClient();

        try {

            Response response = client.newCall(new Request.Builder()
                    .url(Constant.URL_RadioListUrl)
                    .build()).execute();
            responseStr = response.body().string();

            try {

                JSONObject main = new JSONObject(responseStr.trim());
                if (main.get("result").toString().trim().equals("true")) {
                    //set languageList
                    JSONArray data = main.getJSONArray("data");
                    globals.setLanguageList(Parser.getGenreList(globals, data));

                } else {
                    msg = "Oops!";
                }

            } catch (JSONException e) {
                e.printStackTrace();
                Debugger.debugI(TAG, e.getMessage());
            }

        } catch (IOException e) {
            Debugger.debugI(TAG, "API error : " + e.getMessage());
            responseStr = null;
            msg = e.getMessage();
        }

        return null;
    }

    @Override
    protected void onPostExecute(Void unused) {
        super.onPostExecute(unused);

        if (responseStr != null) {
            callListener.onSuccessListener(responseStr);
        } else {
            callListener.onFailListener(msg);
        }
    }
}

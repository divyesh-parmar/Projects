package io.agora.rtc.ss.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.util.Log;
import android.util.Xml;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;

import io.agora.rtc.IRtcEngineEventHandler;
import io.agora.rtc.RtcEngine;
import io.agora.rtc.Constants;
import io.agora.rtc.ss.ScreenSharingClient;
import io.agora.rtc.video.VideoCanvas;
import io.agora.rtc.video.VideoEncoderConfiguration;

import static io.agora.rtc.ss.app.Constant.GEN_DIGIT;

public class BroadcasterActivity extends Activity {

    private static final String LOG_TAG = BroadcasterActivity.class.getSimpleName();
    private RtcEngine mRtcEngine;
    private FrameLayout mFlCam;
    private FrameLayout mFlSS;
    private boolean mSS = false;
    private VideoEncoderConfiguration mVEC;
    int volume = 200;
    private ScreenSharingClient mSSClient;
    ArrayList<String> ListOfSave = new ArrayList<>();

    private final ScreenSharingClient.IStateListener mListener = new ScreenSharingClient.IStateListener() {
        @Override
        public void onError(int error) {
            Log.e(LOG_TAG, "Screen share service error happened: " + error);
        }

        @Override
        public void onTokenWillExpire() {
            Log.d(LOG_TAG, "Screen share service token will expire");
            mSSClient.renewToken(null); // Replace the token with your valid token
        }
    };

    private final IRtcEngineEventHandler mRtcEventHandler = new IRtcEngineEventHandler() {

        @Override
        public void onUserOffline(int uid, int reason) {
            Log.d(LOG_TAG, "onUserOffline: " + uid + " reason: " + reason);
        }

        @Override
        public void onJoinChannelSuccess(String channel, int uid, int elapsed) {
            Log.d(LOG_TAG, "onJoinChannelSuccess: " + channel + " " + elapsed);
        }

        @Override
        public void onUserJoined(final int uid, int elapsed) {
            Log.d(LOG_TAG, "onUserJoined: " + (uid & 0xFFFFFFL));
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (uid == Constant.SCREEN_SHARE_UID) {
                        setupRemoteView(uid);
                    }
                }
            });
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_broadcaster);
        getWindow().addFlags(1024);

        mFlCam = (FrameLayout) findViewById(R.id.camera_preview);
        mFlSS = (FrameLayout) findViewById(R.id.screen_share_preview);

        TextView tvrandom = (TextView) findViewById(R.id.tvrandom);
        ImageView btnshare = (ImageView) findViewById(R.id.btnshare);
        ImageView start_screen_share = (ImageView) findViewById(R.id.start_screen_share);

        Utl.SetUILinear(this, start_screen_share, 996, 294);
        Utl.SetUILinear(this, findViewById(R.id.patto), 964, 363);

        findViewById(R.id.backbtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        tvrandom.setText("Generated Channel ID:" + GEN_DIGIT);

        if (Constant.getArrayList(BroadcasterActivity.this, "key1") == null) {

        } else {
            ListOfSave.addAll(Constant.getArrayList(BroadcasterActivity.this, "key1"));
        }

        ListOfSave.add(GEN_DIGIT);

        for (int i = 0; i < ListOfSave.size(); i++) {
            for (int j = i + 1; j < ListOfSave.size(); j++) {
                if (ListOfSave.get(i).equals(ListOfSave.get(j))) {
                    ListOfSave.remove(j);
                    j--;
                }
            }
        }

        Constant.saveArrayList(BroadcasterActivity.this, ListOfSave, "key1");

        btnshare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                sharingIntent.setType("text/plain");
                sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Subject Here");
                sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, "Hello I Am Using Mobile Screen Sharing-Live Screen Talk App.\n" +
                        "And To join Me You can Connect with me Via below Id.\n" +
                        "Screen Share ID:-" + GEN_DIGIT);
                startActivity(Intent.createChooser(sharingIntent, "Share Digit Using"));
            }
        });

        mSSClient = ScreenSharingClient.getInstance();
        mSSClient.setListener(mListener);

        mVEC = new VideoEncoderConfiguration(VideoEncoderConfiguration.VD_840x480,
                VideoEncoderConfiguration.FRAME_RATE.FRAME_RATE_FPS_24,
                VideoEncoderConfiguration.STANDARD_BITRATE,
                VideoEncoderConfiguration.ORIENTATION_MODE.ORIENTATION_MODE_ADAPTIVE);

    }

    private void initAgoraEngineAndJoinChannel() {
        initializeAgoraEngine();
        setupVideoProfile();
        setupLocalVideo();
        joinChannel();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (mRtcEngine != null) {
            leaveChannel();
            RtcEngine.destroy();
            mRtcEngine = null;
        }

        if (mSS) {
            mSSClient.stop(getApplicationContext());
        }
    }

    @Override
    public void onBackPressed() {
        final Dialog dialog1 = new Dialog(BroadcasterActivity.this);
        dialog1.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog1.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog1.setContentView(R.layout.share_dialog);

        ImageView yes = (ImageView) dialog1.findViewById(R.id.yes);
        ImageView no = (ImageView) dialog1.findViewById(R.id.no);
        RelativeLayout mainpop = (RelativeLayout) dialog1.findViewById(R.id.mainpop);

        Utl.SetUILinearVivo(BroadcasterActivity.this, mainpop, 987, 1045);
        Utl.SetUILinear(BroadcasterActivity.this, yes, 357, 143);
        Utl.SetUILinear(BroadcasterActivity.this, no, 357, 143);
        Utl.SetUILinearVivo(BroadcasterActivity.this, dialog1.findViewById(R.id.pops), 987, 1015);

        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog1.dismiss();
            }
        });

        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog1.dismiss();
                onDestroy();
                startActivity(new Intent(BroadcasterActivity.this, MainActivity.class));
            }
        });

        dialog1.show();
    }

    public void onCameraSharingClicked(View view) {
        Button button = (Button) view;
        boolean selected = button.isSelected();
        button.setSelected(!selected);

        if (button.isSelected()) {
            initAgoraEngineAndJoinChannel();
            button.setText(getResources().getString(R.string.label_stop_camera));
        } else {
            leaveChannel();
            button.setText(getResources().getString(R.string.label_start_camera));
        }

        mRtcEngine.enableLocalVideo(button.isSelected());
    }

    public void onScreenSharingClicked(View view) {
        ImageView button = (ImageView) view;
        boolean selected = button.isSelected();
        button.setSelected(!selected);

        if (button.isSelected()) {
            mSSClient.start(getApplicationContext(), getResources().getString(R.string.agora_app_id), null,
                    GEN_DIGIT, Constant.SCREEN_SHARE_UID, mVEC);
            button.setImageResource(R.drawable.stopu);
            mSS = true;
        } else {
            mSSClient.stop(getApplicationContext());
            button.setImageResource(R.drawable.startu);
            mSS = false;
        }
    }

    private void initializeAgoraEngine() {
        try {
            mRtcEngine = RtcEngine.create(getApplicationContext(), getString(R.string.agora_app_id), mRtcEventHandler);
        } catch (Exception e) {
            Log.e(LOG_TAG, Log.getStackTraceString(e));

            throw new RuntimeException("NEED TO check rtc sdk init fatal error\n" + Log.getStackTraceString(e));
        }
    }

    private void setupVideoProfile() {
        mRtcEngine.setChannelProfile(Constants.CHANNEL_PROFILE_LIVE_BROADCASTING);
        mRtcEngine.enableVideo();
        mRtcEngine.enableAudio();
        mRtcEngine.setVideoEncoderConfiguration(mVEC);
        mRtcEngine.adjustRecordingSignalVolume(volume);
        mRtcEngine.setAudioProfile(Constants.AUDIO_PROFILE_MUSIC_STANDARD, Constants.AUDIO_SCENARIO_CHATROOM_ENTERTAINMENT);
        mRtcEngine.setClientRole(Constants.CLIENT_ROLE_BROADCASTER);
    }

    private void setupLocalVideo() {
        SurfaceView camV = RtcEngine.CreateRendererView(getApplicationContext());
        camV.setZOrderOnTop(true);
        camV.setZOrderMediaOverlay(true);
        mFlCam.addView(camV, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        mRtcEngine.setupLocalVideo(new VideoCanvas(camV, VideoCanvas.RENDER_MODE_FIT, Constant.CAMERA_UID));
        mRtcEngine.enableLocalVideo(false);
    }

    private void setupRemoteView(int uid) {
        SurfaceView ssV = RtcEngine.CreateRendererView(getApplicationContext());
        ssV.setZOrderOnTop(true);
        ssV.setZOrderMediaOverlay(true);
        mFlSS.addView(ssV, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        mRtcEngine.setupRemoteVideo(new VideoCanvas(ssV, VideoCanvas.RENDER_MODE_FIT, uid));
    }

    private void joinChannel() {
        mRtcEngine.joinChannel(null, GEN_DIGIT, "Extra Optional Data", Constant.CAMERA_UID); // if you do not specify the uid, we will generate the uid for you
    }

    private void leaveChannel() {
        mRtcEngine.leaveChannel();
    }
}
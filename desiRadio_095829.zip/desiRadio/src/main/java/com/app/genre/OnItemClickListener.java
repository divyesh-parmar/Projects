package com.app.genre;

public interface OnItemClickListener {

    void onItemClick(int position);
}

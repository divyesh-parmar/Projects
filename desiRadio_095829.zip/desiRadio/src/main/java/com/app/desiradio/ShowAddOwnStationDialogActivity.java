package com.app.desiradio;

import java.util.ArrayList;
import java.util.HashMap;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.URLUtil;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import com.android.GoogleAnalytics.Analytics;
import com.android.GoogleAnalytics.AnalyticsConstant;
import com.app.utility.Constant;
import com.app.utility.Globals;
import com.app.utility.Utils;
import com.indianradio.R;

public class ShowAddOwnStationDialogActivity extends Activity {

    Activity activity;
    Globals globals;
    ArrayList<HashMap<String, String>> temp;
    AlertDialog alertDialog;

    //google Analytics obj
    Analytics analytics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.activity = this;
        globals = ((Globals) activity.getApplicationContext());
        analytics = new Analytics(ShowAddOwnStationDialogActivity.this);
        temp = globals.fetchUserAddedStationList(activity);

        show();
    }

    public void show() {
        // Create custom dialog object
        AlertDialog.Builder builder;

        builder = new AlertDialog.Builder(activity);

        View dialoglayout = activity.getLayoutInflater().inflate(R.layout.add_own_station_layout, null);
        builder.setView(dialoglayout);
        // Set dialog title
        builder.setTitle(PrepareDrawerList.dw_entry_Add_Station);
        builder.setCancelable(true);

        // set values for custom dialog components - text, image and button
        final EditText et_stationName = (EditText) dialoglayout.findViewById(R.id.et_stationName);
        final EditText et_stationURL = (EditText) dialoglayout.findViewById(R.id.et_stationURL);

//        alertDialog = builder.create();
        builder.setOnDismissListener(new OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                finish();
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                finish();
            }
        });

        builder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if (isValidFields(et_stationName, et_stationURL)) {
                    Utils.showToast(activity, et_stationName.getText().toString().trim() + " added under Favorites");
                    HashMap<String, String> station = new HashMap<String, String>();
                    station.put(Constant.MM_OWN_STATION_NAME, et_stationName.getText().toString().trim());
                    station.put(Constant.MM_OWN_STATION_URL, et_stationURL.getText().toString().trim());
                    temp.add(station);
                    globals.saveUserAddedStationList(activity, temp);

                    analytics.Event_Tracking(AnalyticsConstant.EC_START, AnalyticsConstant.EA_USER_ADDED_STATION,
                            et_stationName.getText().toString().trim() + " > " + et_stationURL.getText().toString().trim());
                    dialogInterface.dismiss();

                    finish();
                }
            }
        });

        builder.show();
        // show alert
      //  alertDialog.show();
    }

    public boolean isValidFields(EditText et_stationName, EditText et_stationURL) {

        boolean isValid = true;
        //Station name
        if (et_stationName.getText().toString().trim().length() == 0) {
            et_stationName.setError(Constant.MM_MSG_PLEASE_ENTER_STATION_NAME);
            isValid = false;
        } else
            et_stationName.setError(null);

        //Station URL
        if (et_stationURL.getText().toString().trim().length() == 0) {
            et_stationURL.setError(Constant.MM_MSG_PLEASE_ENTER_STATION_URL);
            isValid = false;
            return isValid;
        } else {
            et_stationURL.setError(null);
        }

        //URL validation
        if (!URLUtil.isValidUrl(et_stationURL.getText().toString().trim())) {
            et_stationURL.setError(Constant.MM_MSG_PLEASE_ENTER_VALID_STATION_URL);
            isValid = false;
            return isValid;
        } else {
            et_stationURL.setError(null);
        }

        //URL Exist
        if (isStationUrlAlreadyExist(et_stationURL.getText().toString().trim())) {
            et_stationURL.setError(Constant.MM_MSG_ENTERED_STATION_URL_ALREADY_EXIST);
            isValid = false;
        } else {
            et_stationURL.setError(null);
        }
        return isValid;
    }

    public boolean isStationUrlAlreadyExist(String URL) {
        int count = temp.size();
        for (int i = 0; i < count; i++) {
            if (temp.get(i).get(Constant.MM_OWN_STATION_URL).equalsIgnoreCase(URL))
                return true;
        }
        return false;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
//        if (alertDialog != null && alertDialog.isShowing())
//            alertDialog.dismiss();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}

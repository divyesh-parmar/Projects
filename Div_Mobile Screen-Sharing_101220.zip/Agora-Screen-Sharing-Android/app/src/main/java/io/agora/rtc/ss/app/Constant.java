package io.agora.rtc.ss.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class Constant {

    public static final int CAMERA_UID = 1;
    public static final int SCREEN_SHARE_UID = 2;
    public static final int AUDIENCE_UID = 3;
    public static String GEN_DIGIT;

    public static void saveArrayList(Context MC, ArrayList<String> list, String key) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(MC);
        SharedPreferences.Editor editor = prefs.edit();
        Gson gson = new Gson();
        String json = gson.toJson(list);
        editor.putString(key, json);
        editor.apply();     // This line is IMPORTANT !!!
    }

    public static ArrayList<String> getArrayList(Context MC, String key) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(MC);
        Gson gson = new Gson();
        String json = prefs.getString(key, null);
        Type type = new TypeToken<ArrayList<String>>() {
        }.getType();
        return gson.fromJson(json, type);
    }
}
package com.app.utility;

import android.app.Activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;

import com.app.desiradio.SplashScreenActivity;
import com.indianradio.R;

public class showErrorDialogActivity extends Activity {

	AlertDialog alert;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setCancelable(false);
		builder.setTitle("Sorry...!");
		builder.setMessage("Unfortunately,This application has stopped.");
		builder.setIcon(R.drawable.alert_icon);
		
		builder.setPositiveButton("Re-Open",
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						Intent i = new Intent(showErrorDialogActivity.this, SplashScreenActivity.class);
					    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB)
					        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK); // equal to Intent.FLAG_ACTIVITY_CLEAR_TASK which is only available from API level 11
					    startActivity(i);
						finish();
					}
				});
		
		builder.setNegativeButton("Close",
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						finish();
					}
				});

		AlertDialog alert = builder.create();
		alert.show();
	}
}
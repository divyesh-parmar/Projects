package io.agora.rtc.ss.app;

import android.Manifest;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.app.Activity;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

import static io.agora.rtc.ss.app.Constant.GEN_DIGIT;

public class MainActivity extends Activity implements View.OnClickListener {

    private static final String LOG_TAG = MainActivity.class.getSimpleName();
    private static final int PERMISSION_REQ_ID = 22;
    // permission WRITE_EXTERNAL_STORAGE is not mandatory for Agora RTC SDK, just incase if you wanna save logs to external sdcard
    private static final String[] REQUESTED_PERMISSIONS = {Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().addFlags(1024);

        if (checkSelfPermission(REQUESTED_PERMISSIONS[0], PERMISSION_REQ_ID) &&
                checkSelfPermission(REQUESTED_PERMISSIONS[1], PERMISSION_REQ_ID) &&
                checkSelfPermission(REQUESTED_PERMISSIONS[2], PERMISSION_REQ_ID)) {
            initView();
        }
    }

    private void initView() {

        Utl.SetUILinear(this,findViewById(R.id.btn_broadcaster),996,216);
        Utl.SetUILinear(this,findViewById(R.id.btn_savelist),996,216);
        Utl.SetUILinear(this,findViewById(R.id.btn_audience),996,216);
        Utl.SetUILinearVivo(this,findViewById(R.id.logo1),1080,1121);

        findViewById(R.id.btn_broadcaster).setOnClickListener(this);
        findViewById(R.id.btn_audience).setOnClickListener(this);
        findViewById(R.id.btn_savelist).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SavedActivity.class));
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finishAffinity();
    }

    @Override
    public void onClick(View view) {
        int vId = view.getId();
        if (vId == R.id.btn_broadcaster) {

            GEN_DIGIT = "" + GenerateRandomDigit(100000, 999999);
            startActivity(new Intent(MainActivity.this, BroadcasterActivity.class));

        } else if (vId == R.id.btn_audience) {

            final Dialog dialog1 = new Dialog(MainActivity.this);
            dialog1.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog1.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
            dialog1.setContentView(R.layout.connection_dialog);

            final EditText etdigit = (EditText) dialog1.findViewById(R.id.etdigit);
            ImageView btnconnect = (ImageView) dialog1.findViewById(R.id.btnconnect);
            LinearLayout pop1 = (LinearLayout) dialog1.findViewById(R.id.pop1);

            Utl.SetUILinearVivo(MainActivity.this,pop1,872,1079);
            Utl.SetUILinear(MainActivity.this,btnconnect,455,128);
            Utl.SetUILinear(MainActivity.this,etdigit,576,139);

            btnconnect.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog1.dismiss();

                    String str = etdigit.getText().toString();

                    if (str.equals("") || str.length() != 6) {
                        Toast.makeText(MainActivity.this, "Please Check Channel Connection", Toast.LENGTH_SHORT).show();
                    } else {
                        GEN_DIGIT = str;
                        startActivity(new Intent(MainActivity.this, AudienceActivity.class));
                    }
                }
            });

            dialog1.show();
        }
    }

    public static int GenerateRandomDigit(int min, int max) {
        Random r = new Random();
        return r.nextInt((max - min) + 1) + min;
    }

    private boolean checkSelfPermission(String permission, int requestCode) {
        Log.i(LOG_TAG, "checkSelfPermission " + permission + " " + requestCode);
        if (ContextCompat.checkSelfPermission(this, permission)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, REQUESTED_PERMISSIONS, requestCode);
            return false;
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[], @NonNull int[] grantResults) {
        Log.i(LOG_TAG, "onRequestPermissionsResult " + grantResults[0] + " " + requestCode);

        switch (requestCode) {
            case PERMISSION_REQ_ID: {
                if (grantResults[0] != PackageManager.PERMISSION_GRANTED || grantResults[1] != PackageManager.PERMISSION_GRANTED || grantResults[2] != PackageManager.PERMISSION_GRANTED) {
                    showLongToast("Need permissions " + Manifest.permission.RECORD_AUDIO + "/" + Manifest.permission.CAMERA + "/" + Manifest.permission.WRITE_EXTERNAL_STORAGE);
                    finish();
                    break;
                }
                initView();
                break;
            }
        }
    }

    private final void showLongToast(final String msg) {
        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
            }
        });
    }
}
package com.android.youtube;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.app.genre.OnItemClickListener;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.indianradio.R;

import java.util.ArrayList;
import java.util.HashMap;

public class YoutubeListRAdapter extends RecyclerView.Adapter<YoutubeListRAdapter.MyHolder> {


    private Activity activity;
    private ArrayList<HashMap<String, String>> data;
    Context context;
    OnItemClickListener onItemClickListener;

    public YoutubeListRAdapter(Activity a,OnItemClickListener onItemClickListener) {
        activity = a;
        data = new ArrayList<HashMap<String, String>>();
        this.onItemClickListener = onItemClickListener;
    }

    @NonNull
    @Override
    public YoutubeListRAdapter.MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(activity).inflate(R.layout.youtube_video_list_item, parent, false);

        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull YoutubeListRAdapter.MyHolder holder, int position) {

        holder.title.setText(data.get(position).get("title"));
        holder.description.setText(data.get(position).get("description"));
        holder.description.setText("Duration: " + data.get(position).get("duration"));
        //holder.duration.setText(data.get(position).get("duration"));
        //holder.image.setTag(data.get(position).get("big_thumbnail"));
        //imageLoader.DisplayImage(data.get(position).get("big_thumbnail"), activity, holder.image);
        Glide.with(activity.getApplicationContext())
                .load(data.get(position).get("big_thumbnail"))
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(holder.image);
        holder.layout1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onItemClickListener.onItemClick(position);
            }
        });

    }

    public void updateResults(ArrayList<HashMap<String, String>> newData) {
        this.data = newData;
        //Triggers the list update
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public Object getItem(int position) {
        return position;
    }

    public long getItemId(int position) {
        return position;
    }

    public class MyHolder extends RecyclerView.ViewHolder {

        public TextView title;
        public TextView description;
        //public TextView duration;
        public ImageView image, image1;
        LinearLayout layout1;

        public MyHolder(@NonNull View itemView) {
            super(itemView);

            title = (TextView) itemView.findViewById(R.id.txt_title);
            description = (TextView) itemView.findViewById(R.id.txt_description);
            //holder.duration=(TextView)vi.findViewById(R.id.txt_duration);
            image = (ImageView) itemView.findViewById(R.id.image);
            image1 = (ImageView) itemView.findViewById(R.id.image1);
            layout1 = itemView.findViewById(R.id.layout1);
        }
    }
}

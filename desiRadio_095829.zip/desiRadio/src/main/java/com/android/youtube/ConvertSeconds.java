package com.android.youtube;

import java.text.DecimalFormat;

public class ConvertSeconds {

	public static String getSimpleDuration(String formatedTime) {
		try {
			StringBuilder builder = new StringBuilder();
			
			String time = formatedTime.substring(formatedTime.indexOf("T")+1);
			int hr_index = time.indexOf("H");
			if(hr_index != -1) {
				int hrs = Integer.parseInt(time.substring(0, time.indexOf("H")).toString());
				if(hrs > 0) {
					builder.append(new DecimalFormat("00").format(hrs) + ":");
				}
				time = formatedTime.substring(formatedTime.indexOf("H")+1);
			}
			
			int min_index = time.indexOf("M");
			int min = 0;
			if(min_index != -1) {
				min = Integer.parseInt(time.substring(0, time.indexOf("M")).toString());
				time = formatedTime.substring(formatedTime.indexOf("M")+1);
			}
			builder.append(new DecimalFormat("00").format(min) + ":");
			
			int sec_index = time.indexOf("S");
			int sec = 0;
			if(sec_index != -1) {
				sec = Integer.parseInt(time.substring(0, time.indexOf("S")).toString());
			}
			builder.append(new DecimalFormat("00").format(sec));
			
			return builder.toString();
		} catch (Exception e) {
			e.printStackTrace();
			return "00:00";
		}
	}
}

package com.app.ads.interfaces;

public interface OpenAdLoadListener {

    void onOpenAdLoaded();

    void onOpenAdFailed();
}

package com.app.utility;

import com.app.parser.Channel;

import java.util.ArrayList;

public class Constant {
	
	public static final boolean isDeveloperVersion 		= false;
	
	public static final int MM_SplashTime				= 1800;
	
	//Activity request code
	public static final int MM_Recording_Playerview_Interrupt = 1;
	public static final int MM_Recording_YoutubeList_Interrupt = 2;
	public static final int MM_Recording_Station_list_Interrupt = 3;
	public static final int MM_Recording_Favorites_list_Interrupt = 4;
	public static final int MM_Recording_History_list_Interrupt = 5;
	public static final int MM_Recording_Lockscreen_Interrupt = 6;
	
	//Action request code
	public static final int MM_ActionID_PlayRecorded = 0;
	public static final int MM_ActionID_StopPlaying = 1;
	public static final int MM_ActionID_PlayNext = 2;
	public static final int MM_ActionID_PlayPrev = 3;
	public static final int MM_ActionID_Clear = 4;
	public static final int MM_ActionID_onClickPLStation = 5;
	public static final int MM_ActionID_onSelectVideo = 6;
	public static final int MM_ActionID_onSelectStation = 7;
	
	public static enum PlayingMode{
		HISTORY,
		FAVORITES,
		OTHER;
		
		public static PlayingMode toPlayingMode (String playingModeString) {
            try {
                return valueOf(playingModeString);
            } catch (Exception ex) {
                return OTHER;
            }
        }
    }

	//server api
//	public static final String AppServerName = "http://192.168.0.1/clients/MyRadio/desiradio/"; //local path
	public static final String AppServerName = "https://radio.ibollysongs.com/desiradio/"; //live path
	
	//GCM Push Notification
	public static final String GCM_REG_URL = AppServerName+"registerDevice.php";
	public static final String GCM_UN_REG_URL = AppServerName+"unRegisterDevice.php";

	public static final String URL_RadioListUrl  = AppServerName+"channelList.php";

	//Application details
	public static final String Web_Url = "https://radio.ibollysongs.com";
	public static final String AppLogLink = Web_Url+"/mobile_images/DesiRadioIcon.png";

	public static final String Link_IOS                         = "https://apps.apple.com/app/id909867505";
	public static final String Link_Android                     = "https://play.google.com/store/apps/details?id=";
	public static final String Privacy_Link                     = "https://radio.ibollysongs.com/mobile/privacy_desiradio.html";

	//Sharing keys
	//Actual Key for Desi Radio
	public static final String Twitter_Consumer_key = "cg8KHjirVpxWp1YksnOTA";
	public static final String Twitter_Secret_key = "LsT4pDZoTohGceaAmtYMAHRtu0IHnlSlawNaDdT6Dc";

	//Youtube API v2
//	public static final String Youtube_API = "https://gdata.youtube.com/feeds/api/videos?q=youStxt&orderby=relevance&start-index=1&max-results=25&v=2&format=1,6&alt=jsonc";
//	public static final String Youtube_Appkey = "AIzaSyCV0Qkoj3d0qqdUxiAHdQ8K7YvlSiquLJY";
	
	//Youtube API v3
	public static final String Youtube_GET_ID_API = "https://www.googleapis.com/youtube/v3/search?q=%s&key=%s&part=id&type=video&order=relevance&maxResults=25";
	public static final String Youtube_GET_VIDEO_DETAIL_API = "https://www.googleapis.com/youtube/v3/videos?id=%s&key=%s&part=snippet,contentDetails";
	public static final String Youtube_Appkey = "AIzaSyDcn43bZlkv8TIG11wD8BUIK_e9m2uL-2M";
	//public static final String Youtube_Appkey = "AIzaSyDdKRZ3wOWzDJTJ-NOdaPGwkpbfU6z8V9U";
	public static final String Browser_Appkey = "AIzaSyDcn43bZlkv8TIG11wD8BUIK_e9m2uL-2M";
	//public static final String Browser_Appkey = "AIzaSyDdKRZ3wOWzDJTJ-NOdaPGwkpbfU6z8V9U";

	//Ads Mediation ID and Size
	public static final int LAR_BANNER_WIDTH = 728;
	public static final int LAR_BANNER_HEIGHT = 90;
	public static final String LAR_TEST_mID = "be220dc62d454e56";
	public static final String LAR_LIVE_mID = "ca-app-pub-9950111571220617/7348206375";
	
	public static final int MED_BANNER_WIDTH = 468;
	public static final int MED_BANNER_HEIGHT = 60;
	public static final String MED_TEST_mID = "00e0ec2baf854e9f";
	public static final String MED_LIVE_mID = "ca-app-pub-9950111571220617/5871473177";

	public static final int NOR_BANNER_WIDTH = 320;
	public static final int NOR_BANNER_HEIGHT = 50;
	public static final String NOR_TEST_mID = "d2af90d2d3b14085"; 	//millen
	public static final String NOR_LIVE_mID = "ca-app-pub-9950111571220617/4394739972"; 	//admob
//	public static final String NOR_LIVE_mID = "ca629ac1da5146e6"; 	//inmobi
	
	public static final String MM_NO_NATIVE_ADS	 		="0";
	public static final String MM_INMOBI_NATIVE_ADS	 	="1";
	public static final String MM_STARTAPP_NATIVE_ADS	="2";
	
	public static final int MM_NATIVE_AFTER_NO_OF_ITEM	= 10;
	public static final int MM_MIN_ITEM_COUNT_TO_SHOW_NATIVE	= 3;
	
	public static final String StartApp_Developer_ID = "108056413";
	public static final String StartApp_App_ID = "201324555";
	
	public static final String NATIVE_AD_ID = "0345c10766fd41e1b879db06352f3087";
	
    // Google project id
    public static final String SENDER_ID = "376093564350"; 
    
    // In App Billing Secrets
    public static enum PurchaseType {
    	PremiumRecording,
    	RemoveAds;
    };
    public static int maxRecordingCount = 5;
	public static final String base64EncodedPublicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEApYxsTOztXQKf07PCJcj30cWpmjoQG4JNcmQuAnmC5+27cMDvjN41wl/nDG8f0HI7asMVQNjpFCL5+7AwIsPE6kmnMr97ZIeZ0RPDRmS+z3aPDv/8E5K/p9POgAZvEmgGalNShlapHSdkYt1ykPP4hKQrSQI6XVly+CLOzYnJt0egZAGcNyTFP4AG6V1DQiskjoeR2PELJtyvmkyQNJmXLbS09oCnrA/I+GjllSSfN2grOWmJ8jDHix1IXGNTmCk7v2NaiuEu4Oa3oR2fq3tHSEfgmt9HGFJTZXgGk4zCxo1XyvmM21+iD7+GpzVmTc8Zk8YOOwrod7gpsLIU7raqXQIDAQAB";
	public static final String SKU_noMoreAds = "com.indianradio.rmvads";
	public static final String SKU_PremiumRecording = "com.indianradio.recording";
//	public static final String SKU_test = "com.desiradio.test";
    
    //Playstore Links
    public static final String PUBLISHER_NAME = "MACYMIND PVT LTD";
    public static final String Link_Aboutus = "https://radio.ibollysongs.com/mobile/desiradio.php";
    public static final String ShortLink_Aboutus = "http://bit.ly/IndianRadio";
    public static final String ShortLink_IOS = "http://bit.ly/Indian_Radio";
    public static final String ShortLink_ANDROID = "http://bit.ly/Desi_Radio";
    public static final String LongLink = "https://play.google.com/store/apps/details?id=";
    public static final String APP_DETAIL = "market://details?id=";
    public static final String MORE_APPS = "market://search?q=pub:";
    public static final String MORE_APP_ID = "7419367632114794510";

    public static final String MAIL_ID = "info@ibollysongs.com";
    
    
    ////////////////////////////////////
    ////// Display messages
    ////////////////////////////////////
    
    public static final String Exit_message = "Please tap on BACK again to exit";
    
    public static final String MM_ALERT_TITLE_ERROR 						= "Ooops";
    
    public static final String MM_ACTION_FAIL_TITLE 						= "Unsupported action";
	public static final String MM_ACTION_FAIL_MSG							= "This action is not supported";

    public static final String MM_EMAIL_ACTION_FAIL_MSG						= "Your device is not configured to send email. Please check mail settings on your device.";
    public static final String MM_SMS_ACTION_FAIL_MSG						= "Your device is not configured to send sms. Please check sms settings on your device.";
    public static final String MM_WHATSAPP_ACTION_FAIL_MSG					= "Please install WhatsApp on your device.";
    
	public static final String MM_NO_INTERNET_TITLE 						= "No Internet Connection";
	public static final String MM_NO_INTERNET_MSG 							= "First make an Internet Connection!!";
	
	public static final String MM_NO_INTERNET_RESPOND_MSG  					= "Check your internet connection. May be its not responding..!";	
	public static final String MM_PARSING_FAILD 							= "Sorry, Parsing problem";
	
    public static final String genre_Loading_msg 							= "Loading Stations...";
    
    public static final String favorite_remove_success						= "Station removed from Favorite List.";
    public static final String favorite_add_success							= "Station added to Favorite List.";
    
    public static final String fevorite_remove_msg  						= "Do you want to remove this Station from favorites?";
    public static final String favorite_clear_all  							= "Are you sure want to delete all favorites & user added?";
    
    public static final String history_remove_msg  							= "Do you want to delete this Station from history?";
    public static final String history_clear_all  							= "Are you sure want to clear all history?";
    
    public static final String fb_success_msg								= "Your message post on your wall.";
    public static final String fb_error_msg									= "Sorry, there was an error with Facebook Sharing.";
    
	public static final String MM_MSG_UPDATE_ALERT							= "New updated version is available with more features.";                               
	
    public static final String notification_play_msg						= "Station is playing..";
    public static final String videoList_loading_msg						= "Loading Video List...";
    public static final String no_video_found								= "No any Video Found";
    
    public static final String MM_MSG_PLEASE_ENTER_STATION_NAME				= "Please enter station name";
    public static final String MM_MSG_PLEASE_ENTER_STATION_URL				= "Please enter station url";
    public static final String MM_MSG_PLEASE_ENTER_VALID_STATION_URL		= "Enter a valid URL starting with http:// or https://";
    public static final String MM_MSG_ENTERED_STATION_URL_ALREADY_EXIST		= "Entered station URL already exist";

    public static final String MM_LITE_VERSION_ALERT						= "With this version you can only record for 1 minute. \n\n"
			 																+"If you want to enjoy unlimited recording then purchase this feature !!!";
	public static final String MM_PURCHASE_RECORDING_ALERT					= "To enjoy more recordings you have to purchase this feature !!!"; // on playwer view  more the 5
	public static final String MM_CANT_RECORD_BEFOR_PLAY_ALERT				= "For Recording, first play radio.";
	
	public static final String MM_MSG_DELETE_RECORDED_ITME					= "Do you want to delete this recording?";
	public static final String MM_RECORDING_INTERRUPT_ALERT					= "Currently you are recording a station. This will stop your current recording. Do you want to continue?";	
	public static final String MM_RECORDING_PROBLEM							= "There is a problem with recording.";  // internal error while createing new file after name.
	
	public static final String MM_MSG_UNABLE_TO_PLAY						= "Unable to play Station.";
	public static final String MM_STATION_ALREADY_EXIST					    = "Station url already exist";
	public static final String MM_STOP_RECORDING_FIRST					    = "Please stop recording before changing the theme";


	public static final String SEARCH_ALBUM_ART_URL             = "https://itunes.apple.com/";
	public static final String SONG_ALBUM_ART_SEARCH_URL        = SEARCH_ALBUM_ART_URL+"search?term=stxt&media=music&limit=10";
	public static final String SONG_NAME_URL                    = "trackName";

	public static final String MM_RESULT_COUNT                  = "resultCount";
	public static final String MM_API_DATA                      = "results";
	public static final String MM_ARTWORKURL100                 = "artworkUrl100";

	////////////////////////////////////
    ////// db constants
    ////////////////////////////////////
    
    public static final String MM_FAVORITES = "FavoriteList";
    public static final String MM_FAVORITES_LIST = "favoList";
    
    public static final String MM_USER_ADDED_STATIONS = "user_added_stations";
    public static final String MM_OWN_STATION_LIST = "own_station_list";
    public static final String MM_OWN_STATION_NAME = "station_name";
    public static final String MM_OWN_STATION_URL = "station_url";
    public static final String MM_OWN_STATION_RANDOM_ID = "station_id";

    public static final String MM_STATION_HISTORY = "stations_history";
    public static final String MM_HISTORY_LIST = "history_list";
    
	public static final String MM_NOTIFICATIONS = "Notifications";
	public static final String MM_NOTIFICATION_LIST = "NotificationList";
	
    
    ////////////////////////////////////
    ////// Sharing Messages
    ////////////////////////////////////
    
	public static final String Sharing_Message = "Listen wide range of indian radio stations with more features. Enjoy it!";
	public static final String Local_Message = "We are missing you!!! Listen world's largest radio stations.";
	
	public static final String MM_IOS_APP							= "iOS app- ";
	public static final String MM_ANDROID_APP						= "Android app- ";




	//player view native ads flag code
	public static final String MM_PLAYER_NO_AD_MOB_NATIVE_ADS   = "0";
	public static final String MM_PLAYER_AD_MOB_NOR_NATIVE_ADS  = "1";
	public static final String MM_PLAYER_AD_MOB_LAR_NATIVE_ADS  = "2";
	public static final String MM_PLAYER_AD_MOB_UNIFIED_NATIVE_ADS  = "3";
	public static final int MM_NATIVE_ADS_RESHOW_TIME			= 240000;
	public static final int MM_NATIVE_ADS_FIRST_TIME            = 2000;

	public static final String MM_Song_Name_Required						= "Song Name Required.";
	public static final String MM_Notification_Play_Station					= "Station is playing..";
	public static final String MM_Song_Info_Not_Found    					= "Song information can't be found";
	public static final String MM_PLZ_SELECT_STATION    					= "Kindly choose a station from the stationlist for playback";
	public static final String MM_DEFAULT_TEXT_WHEN_CLEAR 					= "No Queued Stations";

	////////////////////////////////////
	////// Recording flag
	////////////////////////////////////

	public static int RECORDING_FLAG = 1; //todo for recording feature ON set flag 1 otherwise recording feature is OFF


	////////////////////////////////////
	////// Ads related new code constants
	////////////////////////////////////


	public static ArrayList<Integer> nativePlaceList = new ArrayList<>();

	//Ads constants

	public static int interstitialsAdsFailDelay = 10;
	public static String MM_ANDROID_INTERSTITIAL_INTERVAL = "android_interstitial_interval";   //For Default interstitial interval
	public static String MM_ANDROID_BANNER_TYPE = "android_banner_advt_type";   //For banner type
	public static String MM_ANDROID_INTERSTITIAL_TYPE = "android_interstitial_advt_type";   //For  interstitial type
	public static String MM_ANDROID_ADOPEN_TYPE = "android_app_open_advt_type";   //For ad open type
	public static String MM_ANDROID_NATIVE_TYPE = "android_native_ads";   //For native type
	public static String MM_ANDROID_ADMOB_BANNER_PLACEMENT = "android_admob_banner_placement";   //For admob banner
	public static String MM_ANDROID_ADMOB_INTERSTITIAL_PLACEMENT = "android_admob_interstitial_placement";   //For admob interstitial
	public static String MM_ANDROID_ADMOB_APPOPEN_PLACEMENT = "android_admob_appopen_placement";   //For admob app open ad
	public static String MM_ANDROID_ADMOB_NATIVE_ADVANCE_PLACEMENT = "android_admob_native_advanced_placement";   //For admob app open ad


	public static enum BannerEnum {

		INACTIVE,
		ADMOB

	}

	public static enum NativeEnum {

		INACTIVE,
		ADMOB

	}

	public static enum InterstitialEnum {

		INACTIVE,
		ADMOB

	}

	public static enum AdOpenEnum {

		INACTIVE,
		ADMOB
	}

	////////////////////////////////////
	////// Android auto constants
	////////////////////////////////////

	public static String BROWSE = "Browse";
	public static String FAVOURITE = "Favourite";
	public static String HISTORY = "History";
	public static String CHANNEL_DATA = "data";	//for passing data in android auto
	public static String CHANNEL_TYPE = "type";	//for passing type which is favourite,history or language
	public static ArrayList<Channel> mStationArrayList = new ArrayList<>();

}

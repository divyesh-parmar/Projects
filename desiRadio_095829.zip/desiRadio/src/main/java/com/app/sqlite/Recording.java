package com.app.sqlite;

public class Recording {

	// private variables
	int _id;
	String _name;
	String _sName;
	String _duration;
	String _path;
	String _date;

	//default constructor
	public Recording() { }
	
	public Recording(String _name, String _sName, String _duration, String _path, String _date) {
		this._name = _name;
		this._sName = _sName;
		this._duration = _duration;
		this._path = _path;
		this._date = _date;
	}
	
	// constructor
	public Recording(int _id, String _name, String _sName, String _duration, String _path, String _date) {
		this._id = _id;
		this._name = _name;
		this._sName = _sName;
		this._duration = _duration;
		this._path = _path;
		this._date = _date;
	}
	
	public int getID() {
		return _id;
	}

	public String getName() {
		return _name;
	}

	public String getStationName() {
		return _sName;
	}

	public String getDuration() {
		return _duration;
	}

	public String getPath() {
		return _path;
	}

	public String getDate() {
		return _date;
	}

	public void setID(int _id) {
		this._id = _id;
	}
	
	public void setName(String _name) {
		this._name = _name;
	}

	public void setStationName(String _sName) {
		this._sName = _sName;
	}

	public void setDuration(String _duration) {
		this._duration = _duration;
	}

	public void setPath(String _path) {
		this._path = _path;
	}

	public void setDate(String _date) {
		this._date = _date;
	}
}
